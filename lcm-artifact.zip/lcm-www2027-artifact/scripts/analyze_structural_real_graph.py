"""Post-hoc bound analysis of fixed, previously completed low-degree cells."""
import hashlib
import json
import sys
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from run_blockmatch_real_graph_audit import FullRetentionOracle
from audit_structural_bounds import audit, matching_value
from lcm.graph import load_edgelist
from blockmatch.exact import block_match_exact


def main():
    protocol = json.loads((ROOT / 'configs/BLOCKMATCH_REAL_GRAPH_PROTOCOL.json').read_text())
    raw_path = ROOT / 'results/blockmatch_real_graph.jsonl'
    raw = [json.loads(s) for s in raw_path.read_text().splitlines()]
    records = []
    for gr in protocol['graphs']:
        graph = load_edgelist(ROOT / gr['graph'])
        for target_record in gr['targets']:
            target = target_record['target']
            oracle = FullRetentionOracle(graph, target)
            items = oracle.candidates
            d = len(items)
            values = [oracle.integer([items[i] for i in range(d) if mask >> i & 1]) for mask in range(1 << d)]
            audit(values, d, oracle.scale, lcm=True)
            full = (1 << d) - 1
            h = values[full]
            p = [h - values[full ^ (1 << i)] for i in range(d)]
            mu = min(p)
            curvature_retained = min(Fraction(p[i], values[1 << i]) for i in range(d))
            for row in (r for r in raw if r['graph'] == gr['name'] and r['target'] == target):
                k = row['k']; q = max(1, k // 2); H = h - mu * (d - k)
                optimum = int(row['optimum_numerator'])
                bm = int(row['methods']['blockmatch']['objective_numerator'])
                sc = int(row['methods']['singleton_sort']['objective_numerator'])
                assert bm <= q * optimum - mu * k * (q - 1)
                assert sc <= k * optimum - mu * k * (k - 1)
                assert Fraction(sc, optimum) <= Fraction(k, 1 + (k - 1) * curvature_retained)
                exact_surrogate, _ = matching_value(values, d, k)
                actual_surrogate = sum(oracle.integer(block) for block in row['blockmatch_blocks'])
                assert exact_surrogate == actual_surrogate, (gr['name'], target, k)
                exact_backend = block_match_exact(items, k, oracle.integer)
                assert exact_backend.surrogate == exact_surrogate
                old = min(Fraction(q), Fraction(h, k * oracle.scale))
                bound = Fraction(q * H, H + mu * k * (q - 1))
                new = min(old, bound) if k > 3 else Fraction(1)
                assert Fraction(bm, optimum) <= new
                records.append({'graph':gr['name'], 'target':target, 'd':d, 'budget':row['budget'], 'k':k,
                                'mu':float(Fraction(mu,oracle.scale)), 'curvature':float(1-curvature_retained),
                                'blockmatch_observed_ratio':float(Fraction(bm,optimum)),
                                'blockmatch_old_bound':float(old), 'blockmatch_new_bound':float(new),
                                'structural_bound_fraction':str(bound),
                                'singleton_curvature_bound':float(Fraction(k, 1+(k-1)*curvature_retained)),
                                'singleton_structural_bound':float(Fraction(k*H,H+mu*k*(k-1))),
                                'exact_matching_surrogate_verified':True})
        print(json.dumps({'graph':gr['name'],'analyzed_cells':len(records)}),flush=True)
    path=ROOT/'results/structural_real_graph.jsonl'
    path.write_text(''.join(json.dumps(row,sort_keys=True)+'\n' for row in records))
    import statistics
    nontrivial=[r for r in records if r['k']>=4]
    summary={'status':'ok','scope':'post-hoc analysis; no target selection or algorithm tuning',
             'cells':len(records), 'nontrivial_k_at_least_4_cells':len(nontrivial),
             'strict_bound_improvements':sum(r['blockmatch_new_bound']<r['blockmatch_old_bound'] for r in nontrivial),
             'median_bound_reduction_percent':100*statistics.median(1-r['blockmatch_new_bound']/r['blockmatch_old_bound'] for r in nontrivial),
             'mu_min':min(r['mu'] for r in records),'mu_max':max(r['mu'] for r in records),
             'source_results_sha256':hashlib.sha256(raw_path.read_bytes()).hexdigest(),
             'analysis_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'exact_backend_sha256':hashlib.sha256((ROOT/'blockmatch/exact.py').read_bytes()).hexdigest(),
             'all_48_matching_surrogates_equal_exact_integer_DP':True,
             'all_48_exact_integer_blossom_surrogates_verified':True}
    (ROOT/'results/STRUCTURAL_REAL_GRAPH_SUMMARY.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,sort_keys=True),flush=True)

if __name__ == '__main__':
    main()
