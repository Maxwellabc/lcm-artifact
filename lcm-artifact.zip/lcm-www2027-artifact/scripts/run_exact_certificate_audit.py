"""Attempt exact cardinality-hit certificates on a declared target set."""
import argparse
import hashlib
import json
import sys
import traceback
from pathlib import Path
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lcm.flow import search_exact_cardinality_certificate  # noqa: E402
from lcm.graph import load_author_targets, load_edgelist  # noqa: E402
from lcm.objective import harmonic_after_deletions  # noqa: E402
from lcm.profile import build_budget_profile  # noqa: E402


def implementation_hash():
    digest = hashlib.sha256()
    for path in sorted((ROOT / "lcm").glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--graph", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--target-indices", type=int, nargs="+", required=True)
    parser.add_argument("--budget-ratios", type=float, nargs="+", default=[0.25, 0.5, 0.75])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument("--scale", type=int, default=10_000_000)
    parser.add_argument("--protocol", type=Path)
    args = parser.parse_args(argv)
    graph = load_edgelist(args.graph)
    graph_hash = hashlib.sha256(args.graph.read_bytes()).hexdigest()
    code_hash = implementation_hash()
    if args.protocol is not None:
        protocol = json.loads(args.protocol.read_text())
        if code_hash != protocol["implementation_hash"]:
            raise RuntimeError("implementation does not match frozen protocol")
    targets = load_author_targets(args.targets)
    completed = set()
    if args.output.exists():
        for line in args.output.read_text().splitlines():
            row = json.loads(line)
            if row.get("status") == "ok":
                completed.add((
                    row["target_index"], row["budget"], row.get("graph_sha256"),
                    row.get("implementation_hash"), row.get("search_iterations"),
                    row.get("search_scale"),
                ))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("a", encoding="utf-8") as handle:
        for target_index in args.target_indices:
            target = targets[target_index]
            degree = graph.indegree(target)
            for ratio in args.budget_ratios:
                budget = int(degree * ratio)
                key = (
                    target_index, budget, graph_hash, code_hash,
                    args.iterations, args.scale,
                )
                if key in completed:
                    continue
                started = perf_counter()
                context = {
                    "target_index": target_index,
                    "graph_sha256": graph_hash,
                    "implementation_hash": code_hash,
                    "n": graph.n,
                    "m": graph.m,
                    "target_internal_id": target,
                    "budget_ratio": ratio,
                    "budget": budget,
                    "indegree": degree,
                    "k": degree - budget,
                    "search_scale": args.scale,
                    "search_iterations": args.iterations,
                }
                try:
                    profile = build_budget_profile(graph, target, budget)
                    exact, numerical = search_exact_cardinality_certificate(
                        profile, scale=args.scale, iterations=args.iterations
                    )
                    record = {
                        **context,
                        "profile_accepted_labels": profile.accepted_labels,
                        "numerical_lower_bound": numerical.lower_bound,
                        "numerical_multiplier": numerical.multiplier,
                        "numerical_retained_count": numerical.retained_count,
                        "exact_cardinality_hit": exact is not None,
                        "seconds": perf_counter() - started,
                        "status": "ok",
                    }
                    if exact is not None:
                        deleted = set(profile.candidates) - set(exact.retained)
                        feasible_value = harmonic_after_deletions(graph, target, deleted)
                        record.update({
                            "exact_multiplier": str(exact.multiplier),
                            "exact_lower_bound": str(exact.lower_bound),
                            "exact_lower_bound_float": float(exact.lower_bound),
                            "exact_scale": exact.scale,
                            "exact_retained_count": exact.retained_count,
                            "feasible_value": feasible_value,
                            "absolute_float_residual": abs(
                                feasible_value - float(exact.lower_bound)
                            ),
                        })
                except Exception as error:
                    record = {
                        **context,
                        "status": "error",
                        "error": repr(error),
                        "traceback": traceback.format_exc(),
                        "seconds": perf_counter() - started,
                    }
                handle.write(json.dumps(record, sort_keys=True) + "\n")
                handle.flush()
                print(json.dumps(record, sort_keys=True))


if __name__ == "__main__":
    main()
