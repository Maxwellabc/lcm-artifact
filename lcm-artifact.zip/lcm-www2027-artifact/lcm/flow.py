"""Integer max-flow certificate for the budget-truncated prefix relaxation."""
from collections import deque
from dataclasses import dataclass
from fractions import Fraction
from math import lcm
from typing import List, Optional, Sequence, Tuple

from .profile import BudgetProfile


@dataclass
class _Edge:
    to: int
    reverse: int
    capacity: int


class Dinic:
    def __init__(self, n: int):
        self.graph: List[List[_Edge]] = [[] for _ in range(n)]

    def add_edge(self, source: int, target: int, capacity: int) -> None:
        if capacity < 0:
            raise ValueError("capacity must be nonnegative")
        forward = _Edge(target, len(self.graph[target]), capacity)
        backward = _Edge(source, len(self.graph[source]), 0)
        self.graph[source].append(forward)
        self.graph[target].append(backward)

    def max_flow(self, source: int, sink: int) -> int:
        total = 0
        n = len(self.graph)
        while True:
            level = [-1] * n
            level[source] = 0
            queue = deque([source])
            while queue:
                node = queue.popleft()
                for edge in self.graph[node]:
                    if edge.capacity and level[edge.to] < 0:
                        level[edge.to] = level[node] + 1
                        queue.append(edge.to)
            if level[sink] < 0:
                return total
            cursor = [0] * n

            def send(node: int, amount: int) -> int:
                if node == sink:
                    return amount
                while cursor[node] < len(self.graph[node]):
                    edge = self.graph[node][cursor[node]]
                    if edge.capacity and level[edge.to] == level[node] + 1:
                        pushed = send(edge.to, min(amount, edge.capacity))
                        if pushed:
                            edge.capacity -= pushed
                            self.graph[edge.to][edge.reverse].capacity += pushed
                            return pushed
                    cursor[node] += 1
                return 0

            while True:
                pushed = send(source, 10**30)
                if not pushed:
                    break
                total += pushed

    def source_side(self, source: int) -> Tuple[int, ...]:
        seen = {source}
        queue = deque([source])
        while queue:
            node = queue.popleft()
            for edge in self.graph[node]:
                if edge.capacity and edge.to not in seen:
                    seen.add(edge.to)
                    queue.append(edge.to)
        return tuple(sorted(seen))


@dataclass(frozen=True)
class LagrangianCertificate:
    multiplier: float
    lower_bound: float
    retained_count: int
    retained: Tuple[int, ...]
    scale: int
    flow_value: int
    nodes: int
    arcs: int


@dataclass(frozen=True)
class ExactLagrangianCertificate:
    multiplier: Fraction
    lower_bound: Fraction
    retained_count: int
    retained: Tuple[int, ...]
    scale: int
    flow_value: int
    nodes: int
    arcs: int


def lagrangian_certificate(
    profile: BudgetProfile,
    multiplier: float,
    *,
    scale: int = 1_000_000,
) -> LagrangianCertificate:
    """Return a rigorous quantized lower bound at one multiplier.

    All positive objective terms are rounded downward to integers.  The max
    flow is exact integer arithmetic, so the scaled result is a valid lower
    bound for the original floating objective at the quantized multiplier.
    """
    if multiplier < 0 or scale <= 0:
        raise ValueError("multiplier must be nonnegative and scale positive")
    lam = int(multiplier * scale)
    d = profile.d
    source = 0
    candidate_offset = 1
    next_node = candidate_offset + d
    row_nodes: List[List[Tuple[int, int]]] = []
    base_scaled = 0
    objective_capacity_sum = 0
    for row in profile.rows:
        values = list(row.values[:profile.budget + 1])
        values.extend([0.0] * (profile.budget + 1 - len(values)))
        base_scaled += int(values[profile.budget] * scale)
        active = []
        for rank in range(profile.budget):
            delta = int((values[rank] - values[rank + 1]) * scale)
            if delta > 0:
                active.append((rank, next_node, delta))
                objective_capacity_sum += delta
                next_node += 1
        row_nodes.append(active)
    sink = next_node
    network = Dinic(sink + 1)
    arc_count = 0
    for candidate_index in range(d):
        network.add_edge(source, candidate_offset + candidate_index, lam)
        arc_count += 1
    infinity = objective_capacity_sum + lam * d + 1
    for row, active in zip(profile.rows, row_nodes):
        if not active:
            continue
        # Active prefix nodes form a chain. Candidate at rank r points to the
        # first active prefix whose end rank is at least r.
        for left, right in zip(active, active[1:]):
            network.add_edge(left[1], right[1], infinity)
            arc_count += 1
        for rank, candidate_index in enumerate(row.candidate_indices[:profile.budget]):
            destination = next((node for active_rank, node, _ in active
                                if active_rank >= rank), None)
            if destination is not None:
                network.add_edge(candidate_offset + candidate_index, destination, infinity)
                arc_count += 1
        for _, node, delta in active:
            network.add_edge(node, sink, delta)
            arc_count += 1
    flow = network.max_flow(source, sink)
    source_side = set(network.source_side(source))
    retained_indices = [i for i in range(d) if candidate_offset + i in source_side]
    lower_scaled = base_scaled + flow - lam * d + lam * profile.k
    return LagrangianCertificate(
        multiplier=lam / scale,
        lower_bound=lower_scaled / scale,
        retained_count=len(retained_indices),
        retained=tuple(profile.candidates[i] for i in retained_indices),
        scale=scale,
        flow_value=flow,
        nodes=sink + 1,
        arcs=arc_count,
    )


def exact_lagrangian_certificate(
    profile: BudgetProfile,
    multiplier: Fraction,
) -> ExactLagrangianCertificate:
    """Solve one rational Lagrangian closure instance without rounding.

    Profile values originate as reciprocals of integer path lengths.  We
    recover those rationals with a denominator bound implied by the graph's
    vertex IDs, scale all capacities by their least common multiple, and run
    the same integer max-flow.  The returned Fraction is an exact lower bound.
    """
    multiplier = Fraction(multiplier)
    if multiplier < 0:
        raise ValueError("multiplier must be nonnegative")
    maximum_vertex = max(
        (profile.target, *profile.candidates,
         *(row.source for row in profile.rows)), default=profile.target
    )
    denominator_limit = maximum_vertex + 2

    def rational(value: float) -> Fraction:
        result = Fraction(value).limit_denominator(denominator_limit)
        if abs(float(result) - value) > 1e-14:
            raise ValueError("profile value is not a recoverable path reciprocal")
        return result

    rational_rows = []
    scale = multiplier.denominator
    for row in profile.rows:
        values = [rational(value) for value in row.values[:profile.budget + 1]]
        values.extend([Fraction(0)] * (profile.budget + 1 - len(values)))
        rational_rows.append(values)
        for value in values:
            scale = lcm(scale, value.denominator)

    d = profile.d
    source = 0
    candidate_offset = 1
    next_node = candidate_offset + d
    row_nodes: List[List[Tuple[int, int, int]]] = []
    base_scaled = 0
    objective_capacity_sum = 0
    for values in rational_rows:
        base_scaled += int(values[profile.budget] * scale)
        active = []
        for rank in range(profile.budget):
            delta = int((values[rank] - values[rank + 1]) * scale)
            if delta > 0:
                active.append((rank, next_node, delta))
                objective_capacity_sum += delta
                next_node += 1
        row_nodes.append(active)
    sink = next_node
    network = Dinic(sink + 1)
    arc_count = 0
    lam = int(multiplier * scale)
    for candidate_index in range(d):
        network.add_edge(source, candidate_offset + candidate_index, lam)
        arc_count += 1
    infinity = objective_capacity_sum + lam * d + 1
    for row, active in zip(profile.rows, row_nodes):
        for left, right in zip(active, active[1:]):
            network.add_edge(left[1], right[1], infinity)
            arc_count += 1
        for rank, candidate_index in enumerate(row.candidate_indices[:profile.budget]):
            destination = next((node for active_rank, node, _ in active
                                if active_rank >= rank), None)
            if destination is not None:
                network.add_edge(candidate_offset + candidate_index, destination, infinity)
                arc_count += 1
        for _, node, delta in active:
            network.add_edge(node, sink, delta)
            arc_count += 1
    flow = network.max_flow(source, sink)
    source_side = set(network.source_side(source))
    retained_indices = [i for i in range(d) if candidate_offset + i in source_side]
    lower_scaled = base_scaled + flow - lam * d + lam * profile.k
    return ExactLagrangianCertificate(
        multiplier=multiplier,
        lower_bound=Fraction(lower_scaled, scale),
        retained_count=len(retained_indices),
        retained=tuple(profile.candidates[i] for i in retained_indices),
        scale=scale,
        flow_value=flow,
        nodes=sink + 1,
        arcs=arc_count,
    )


def search_lagrangian_bound(
    profile: BudgetProfile,
    *,
    scale: int = 1_000_000,
    iterations: int = 12,
) -> LagrangianCertificate:
    """Binary-search a size transition and keep the best certified bound."""
    if profile.budget == profile.d:
        return LagrangianCertificate(0.0, 0.0, 0, tuple(), scale, 0, 0, 0)
    return max(lagrangian_sweep(
        profile, scale=scale, iterations=iterations
    ), key=lambda item: item.lower_bound)


def lagrangian_sweep(
    profile: BudgetProfile,
    *,
    scale: int = 1_000_000,
    iterations: int = 12,
) -> Tuple[LagrangianCertificate, ...]:
    """Return unique cuts visited while bisecting the target cardinality."""
    if profile.budget == profile.d:
        return (LagrangianCertificate(0.0, 0.0, 0, tuple(), scale, 0, 0, 0),)
    # Marginal objective values never exceed h(v), which is at most n-1.
    upper = sum(row.values[0] for row in profile.rows if row.values)
    lower = 0.0
    tried = []
    for _ in range(iterations):
        middle = (lower + upper) / 2.0
        certificate = lagrangian_certificate(profile, middle, scale=scale)
        tried.append(certificate)
        if certificate.retained_count < profile.k:
            lower = middle
        else:
            upper = middle
    tried.append(lagrangian_certificate(profile, lower, scale=scale))
    tried.append(lagrangian_certificate(profile, upper, scale=scale))
    # A whole interval of multipliers can induce the same cut.  Keep only the
    # strongest certificate for each retained set: repair needs one copy of
    # the cut, while the bound search must not lose the best dual value.
    unique = {}
    for certificate in tried:
        previous = unique.get(certificate.retained)
        if previous is None or certificate.lower_bound > previous.lower_bound:
            unique[certificate.retained] = certificate
    return tuple(sorted(
        unique.values(), key=lambda item: (item.retained_count, item.retained)
    ))


def search_exact_cardinality_certificate(
    profile: BudgetProfile,
    *,
    scale: int = 10_000_000,
    iterations: int = 20,
    denominator_limits: Sequence[int] = (1_000, 10_000, 1_000_000),
) -> Tuple[Optional[ExactLagrangianCertificate], LagrangianCertificate]:
    """Try to turn a visited size-k cut into an exact optimality proof.

    When an exact regularized min-cut retains exactly ``k`` candidates, weak
    duality and feasibility meet, so that retained set is globally optimal for
    the strict-budget problem.  Rational simplification is attempted only for
    multipliers whose quantized cut already has the target cardinality; every
    candidate is then resolved from scratch with exact integer capacities.
    """
    sweep = lagrangian_sweep(profile, scale=scale, iterations=iterations)
    best = max(sweep, key=lambda item: item.lower_bound)
    if profile.budget == profile.d:
        exact = exact_lagrangian_certificate(profile, Fraction(0))
        return exact, best
    for candidate in sweep:
        if candidate.retained_count != profile.k:
            continue
        decimal = Fraction(str(candidate.multiplier))
        multipliers = []
        for limit in denominator_limits:
            value = decimal.limit_denominator(limit)
            if value not in multipliers:
                multipliers.append(value)
        if decimal not in multipliers:
            multipliers.append(decimal)
        for multiplier in multipliers:
            exact = exact_lagrangian_certificate(profile, multiplier)
            if exact.retained_count == profile.k:
                return exact, best
    return None, best
