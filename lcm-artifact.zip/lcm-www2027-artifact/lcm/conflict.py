"""Cross-source conflict penalties that preserve a min-cut inner problem."""
from dataclasses import dataclass
from fractions import Fraction
from math import lcm
from typing import List, Optional, Sequence, Tuple

from .flow import Dinic, lagrangian_sweep
from .profile import BudgetProfile


def _popcount(value: int) -> int:
    return bin(value).count("1")


@dataclass(frozen=True)
class PrefixTrigger:
    row_index: int
    rank: int
    weight: Fraction
    prefix_mask: int


@dataclass(frozen=True)
class ConflictPenalty:
    left: int
    right: int
    multiplier: Fraction


@dataclass(frozen=True)
class ConflictCertificate:
    cardinality_multiplier: Fraction
    lower_bound: Fraction
    deleted_count: int
    deleted: Tuple[int, ...]
    conflict_count: int
    conflict_mass: Fraction
    scale: int
    nodes: int
    arcs: int


@dataclass(frozen=True)
class SeparatedConflictResult:
    base: ConflictCertificate
    best: ConflictCertificate
    separation_cut: Optional[ConflictCertificate]
    penalties: Tuple[ConflictPenalty, ...]
    strength: Fraction
    fixed_alpha_trials: int


def _rational_rows(profile: BudgetProfile):
    maximum_vertex = max(
        (profile.target, *profile.candidates,
         *(row.source for row in profile.rows)), default=profile.target
    )
    denominator_limit = maximum_vertex + 2

    def rational(value: float) -> Fraction:
        result = Fraction(value).limit_denominator(denominator_limit)
        if abs(float(result) - value) > 1e-14:
            raise ValueError("profile value is not a recoverable path reciprocal")
        return result

    result = []
    for row in profile.rows:
        values = [rational(value) for value in row.values[:profile.budget + 1]]
        values.extend([Fraction(0)] * (profile.budget + 1 - len(values)))
        result.append(tuple(values))
    return tuple(result)


def build_prefix_triggers(
    profile: BudgetProfile,
) -> Tuple[Tuple[PrefixTrigger, ...], Tuple[Tuple[int, ...], ...]]:
    """Return all positive budget-prefix rewards and their per-row chains."""
    rational_rows = _rational_rows(profile)
    triggers: List[PrefixTrigger] = []
    row_chains = []
    for row_index, (row, values) in enumerate(zip(profile.rows, rational_rows)):
        mask = 0
        chain = []
        for rank, candidate_index in enumerate(
                row.candidate_indices[:profile.budget]):
            mask |= 1 << candidate_index
            delta = values[rank] - values[rank + 1]
            if delta > 0:
                chain.append(len(triggers))
                triggers.append(PrefixTrigger(row_index, rank, delta, mask))
        row_chains.append(tuple(chain))
    return tuple(triggers), tuple(row_chains)


def select_conflict_matching(
    profile: BudgetProfile,
    triggers: Sequence[PrefixTrigger],
    *,
    pool_size: int = 500,
    max_pairs: int = 100,
    strength: Fraction = Fraction(1),
    active_deleted_indices: Optional[Sequence[int]] = None,
) -> Tuple[ConflictPenalty, ...]:
    """Greedily select a weight-disjoint matching of violated-budget pairs.

    A pair is valid when the union of its deletion prefixes has more than
    ``budget`` candidates.  Matching endpoints ensure that assigning at most
    each endpoint's reward keeps every residual closure reward nonnegative.
    """
    strength = Fraction(strength)
    if not 0 <= strength <= 1:
        raise ValueError("strength must lie in [0,1]")
    eligible = range(len(triggers))
    if active_deleted_indices is not None:
        deleted_mask = 0
        for index in active_deleted_indices:
            deleted_mask |= 1 << index
        eligible = [
            index for index in eligible
            if triggers[index].prefix_mask & ~deleted_mask == 0
        ]
    pool = sorted(
        eligible,
        key=lambda index: (
            -(triggers[index].weight
              * _popcount(triggers[index].prefix_mask)),
            -triggers[index].weight,
            -_popcount(triggers[index].prefix_mask),
            triggers[index].row_index,
            triggers[index].rank,
        ),
    )[:pool_size]
    candidates = []
    for left_position, left in enumerate(pool):
        first = triggers[left]
        for right in pool[left_position + 1:]:
            second = triggers[right]
            if first.row_index == second.row_index:
                continue
            union_size = _popcount(first.prefix_mask | second.prefix_mask)
            if union_size <= profile.budget:
                continue
            mass = min(first.weight, second.weight) * strength
            if mass > 0:
                candidates.append((mass, union_size, left, right))
    candidates.sort(key=lambda item: (-item[0], -item[1], item[2], item[3]))
    used = set()
    selected = []
    for mass, _, left, right in candidates:
        if left in used or right in used:
            continue
        selected.append(ConflictPenalty(left, right, mass))
        used.add(left)
        used.add(right)
        if len(selected) >= max_pairs:
            break
    return tuple(selected)


def conflict_lagrangian_certificate(
    profile: BudgetProfile,
    cardinality_multiplier: Fraction,
    penalties: Sequence[ConflictPenalty],
) -> ConflictCertificate:
    """Compute an exact lower bound with dualized cross-source conflicts."""
    alpha = Fraction(cardinality_multiplier)
    if alpha < 0:
        raise ValueError("cardinality multiplier must be nonnegative")
    triggers, row_chains = build_prefix_triggers(profile)
    residual = [trigger.weight for trigger in triggers]
    conflict_mass = Fraction(0)
    for penalty in penalties:
        if penalty.left == penalty.right or penalty.multiplier < 0:
            raise ValueError("invalid conflict penalty")
        left, right = triggers[penalty.left], triggers[penalty.right]
        if _popcount(left.prefix_mask | right.prefix_mask) <= profile.budget:
            raise ValueError("penalty pair is not a valid budget conflict")
        residual[penalty.left] -= penalty.multiplier
        residual[penalty.right] -= penalty.multiplier
        conflict_mass += penalty.multiplier
    if any(weight < 0 for weight in residual):
        raise ValueError("incident conflict mass exceeds a trigger reward")

    rational_rows = _rational_rows(profile)
    empty = sum((values[0] for values in rational_rows), Fraction(0))
    scale = alpha.denominator
    for value in (empty, conflict_mass, *residual):
        scale = lcm(scale, value.denominator)

    source = 0
    trigger_offset = 1
    candidate_offset = trigger_offset + len(triggers)
    sink = candidate_offset + profile.d
    network = Dinic(sink + 1)
    arcs = 0
    alpha_scaled = int(alpha * scale)
    residual_scaled = [int(value * scale) for value in residual]
    finite_sum = sum(residual_scaled) + alpha_scaled * profile.d
    infinity = finite_sum + 1
    for trigger_index, reward in enumerate(residual_scaled):
        if reward:
            network.add_edge(source, trigger_offset + trigger_index, reward)
            arcs += 1
    for row, chain in zip(profile.rows, row_chains):
        previous_rank = -1
        previous_trigger = None
        for trigger_index in chain:
            trigger = triggers[trigger_index]
            node = trigger_offset + trigger_index
            if previous_trigger is not None:
                network.add_edge(node, trigger_offset + previous_trigger, infinity)
                arcs += 1
            for rank in range(previous_rank + 1, trigger.rank + 1):
                candidate_index = row.candidate_indices[rank]
                network.add_edge(node, candidate_offset + candidate_index, infinity)
                arcs += 1
            previous_rank = trigger.rank
            previous_trigger = trigger_index
    if alpha_scaled:
        for candidate_index in range(profile.d):
            network.add_edge(candidate_offset + candidate_index, sink, alpha_scaled)
            arcs += 1
    flow = network.max_flow(source, sink)
    source_side = set(network.source_side(source))
    deleted_indices = [
        index for index in range(profile.d)
        if candidate_offset + index in source_side
    ]
    lower_scaled = (
        int(empty * scale) - sum(residual_scaled) + flow
        - alpha_scaled * profile.budget - int(conflict_mass * scale)
    )
    return ConflictCertificate(
        cardinality_multiplier=alpha,
        lower_bound=Fraction(lower_scaled, scale),
        deleted_count=len(deleted_indices),
        deleted=tuple(profile.candidates[index] for index in deleted_indices),
        conflict_count=len(penalties),
        conflict_mass=conflict_mass,
        scale=scale,
        nodes=sink + 1,
        arcs=arcs,
    )


def search_conflict_lagrangian_bound(
    profile: BudgetProfile,
    penalties: Sequence[ConflictPenalty],
    *,
    iterations: int = 16,
) -> ConflictCertificate:
    """Bisect a cardinality transition and keep the best exact bound."""
    return max(
        conflict_lagrangian_sweep(profile, penalties, iterations=iterations),
        key=lambda item: item.lower_bound,
    )


def conflict_lagrangian_sweep(
    profile: BudgetProfile,
    penalties: Sequence[ConflictPenalty],
    *,
    iterations: int = 16,
) -> Tuple[ConflictCertificate, ...]:
    """Return exact cuts visited while bisecting a cardinality transition."""
    rational_rows = _rational_rows(profile)
    lower = Fraction(0)
    upper = sum((values[0] for values in rational_rows), Fraction(0))
    tried = []
    for _ in range(iterations):
        middle = (lower + upper) / 2
        certificate = conflict_lagrangian_certificate(profile, middle, penalties)
        tried.append(certificate)
        if certificate.deleted_count > profile.budget:
            lower = middle
        else:
            upper = middle
    tried.append(conflict_lagrangian_certificate(profile, lower, penalties))
    tried.append(conflict_lagrangian_certificate(profile, upper, penalties))
    unique = {}
    for certificate in tried:
        key = (certificate.deleted, certificate.cardinality_multiplier)
        unique[key] = certificate
    return tuple(unique.values())


def separated_conflict_bound(
    profile: BudgetProfile,
    *,
    iterations: int = 20,
    pool_size: int = 500,
    max_pairs: int = 100,
    strengths: Sequence[Fraction] = (
        Fraction(1, 4), Fraction(1, 2), Fraction(1),
    ),
) -> SeparatedConflictResult:
    """Separate conflicts on the closest over-budget base cut and line-search.

    The zero-penalty certificate is always retained as a candidate, so the
    result cannot weaken the base bound.  Positive penalties are proposed only
    from trigger pairs jointly active in an optimal over-budget subproblem cut.
    """
    numerical_sweep = lagrangian_sweep(
        profile, scale=10_000_000, iterations=iterations
    )
    exact_sweep = []
    for numerical in numerical_sweep:
        alpha = Fraction(str(numerical.multiplier))
        exact_sweep.append(conflict_lagrangian_certificate(profile, alpha, ()))
    base = max(exact_sweep, key=lambda item: item.lower_bound)
    over_budget = [certificate for certificate in exact_sweep
                   if certificate.deleted_count > profile.budget]
    if not over_budget:
        return SeparatedConflictResult(base, base, None, tuple(), Fraction(0), 0)
    separation_cut = max(over_budget, key=lambda item: item.lower_bound)
    candidate_to_index = {
        vertex: index for index, vertex in enumerate(profile.candidates)
    }
    active_indices = [candidate_to_index[vertex] for vertex in separation_cut.deleted]
    triggers, _ = build_prefix_triggers(profile)
    full_penalties = select_conflict_matching(
        profile, triggers, pool_size=pool_size, max_pairs=max_pairs,
        active_deleted_indices=active_indices,
    )
    if not full_penalties:
        return SeparatedConflictResult(
            base, base, separation_cut, tuple(), Fraction(0), 0
        )
    best = base
    best_penalties: Tuple[ConflictPenalty, ...] = tuple()
    best_strength = Fraction(0)
    trials = len(exact_sweep)
    for strength in strengths:
        strength = Fraction(strength)
        penalties = tuple(
            ConflictPenalty(item.left, item.right, item.multiplier * strength)
            for item in full_penalties
        )
        maximum_penalty = max(item.multiplier for item in penalties)
        for shift in (maximum_penalty, maximum_penalty / 2, Fraction(0)):
            alpha = separation_cut.cardinality_multiplier - shift
            if alpha < 0:
                continue
            certificate = conflict_lagrangian_certificate(profile, alpha, penalties)
            trials += 1
            if certificate.lower_bound > best.lower_bound:
                best = certificate
                best_penalties = penalties
                best_strength = strength
    return SeparatedConflictResult(
        base=base,
        best=best,
        separation_cut=separation_cut,
        penalties=best_penalties,
        strength=best_strength,
        fixed_alpha_trials=trials,
    )
