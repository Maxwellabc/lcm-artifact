"""Compact reverse-CSR graph and reusable BFS kernels for million-scale audits."""
from array import array
import hashlib
import json
import mmap
import os
from pathlib import Path
import struct
import sys


MAGIC = b"LCMRCSR2"
HEADER = struct.Struct("<8sQQ")
FORMAT_VERSION = 2


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def iter_external_edges(path):
    """Yield positive external integer labels from a KONECT-style edge list."""
    with Path(path).open("rb") as handle:
        for line_number, line in enumerate(handle, 1):
            stripped = line.strip()
            if not stripped or stripped.startswith((b"%", b"#")):
                continue
            fields = stripped.split()
            if len(fields) < 2:
                raise ValueError("%s:%d: expected two columns" % (path, line_number))
            try:
                source = int(fields[0])
                target = int(fields[1])
            except ValueError as error:
                raise ValueError("%s:%d: non-integer endpoint" % (path, line_number)) from error
            if source <= 0 or target <= 0 or source > 0xFFFFFFFF or target > 0xFFFFFFFF:
                raise ValueError("%s:%d: endpoint is not a positive uint32" %
                                 (path, line_number))
            if source != target:
                yield source, target


def build_reverse_csr(source, cache, *, expected_sha256, expected_n, expected_m):
    """Build a native little-endian reverse CSR after validating simple-edge counts.

    The input is accepted only when the number of non-loop records equals the
    published simple-edge count. The KONECT inputs used by this extension have
    no duplicate non-loop records; any count discrepancy is a hard failure.
    """
    if sys.byteorder != "little":
        raise RuntimeError("compact cache currently requires a little-endian host")
    source = Path(source)
    cache = Path(cache)
    metadata_path = cache.with_suffix(cache.suffix + ".json")
    source_hash = sha256(source)
    if source_hash != expected_sha256:
        raise RuntimeError("graph hash mismatch: %s != %s" % (
            source_hash, expected_sha256))
    expected_metadata = {
        "format_version": FORMAT_VERSION,
        "graph_sha256": source_hash,
        "n": expected_n,
        "m": expected_m,
    }
    if cache.exists() and metadata_path.exists():
        metadata = json.loads(metadata_path.read_text())
        expected_bytes = (HEADER.size + 8 * (expected_n + 1) +
                          4 * expected_m + 4 * expected_n)
        if (all(metadata.get(key) == value
                for key, value in expected_metadata.items())
                and cache.stat().st_size == expected_bytes):
            return metadata

    external_counts = array("Q", [0])
    seen = bytearray(1)
    edge_count = 0
    previous = None
    for source_label, target_label in iter_external_edges(source):
        largest = max(source_label, target_label)
        if largest >= len(seen):
            extension = largest + 1 - len(seen)
            seen.extend(b"\0" * extension)
            external_counts.extend(array("Q", [0]) * extension)
        if previous == (source_label, target_label):
            raise RuntimeError("consecutive duplicate non-loop edge: %d %d" %
                               (source_label, target_label))
        previous = (source_label, target_label)
        external_counts[target_label] += 1
        seen[source_label] = 1
        seen[target_label] = 1
        edge_count += 1
    if edge_count != expected_m:
        raise RuntimeError(
            "non-loop record count %d differs from expected simple count %d; "
            "deduplication would be required" % (edge_count, expected_m)
        )

    labels = array("I", (label for label in range(1, len(seen)) if seen[label]))
    if len(labels) != expected_n:
        raise RuntimeError(
            "non-loop endpoint count %d differs from expected n %d" %
            (len(labels), expected_n)
        )
    external_to_internal = array("i", [-1]) * len(seen)
    counts = array("Q", [0]) * expected_n
    for internal_id, external_label in enumerate(labels):
        external_to_internal[external_label] = internal_id
        counts[internal_id] = external_counts[external_label]

    offsets = array("Q", [0]) * (expected_n + 1)
    running = 0
    for vertex, count in enumerate(counts):
        offsets[vertex] = running
        running += count
    offsets[expected_n] = running
    if running != expected_m:
        raise AssertionError("CSR prefix sum mismatch")
    cursor = array("Q", offsets[:-1])
    predecessors = array("I", [0]) * expected_m
    for source_label, target_label in iter_external_edges(source):
        source_id = external_to_internal[source_label]
        target_id = external_to_internal[target_label]
        if source_id < 0 or target_id < 0:
            raise AssertionError("dense mapping omitted an edge endpoint")
        position = cursor[target_id]
        predecessors[position] = source_id
        cursor[target_id] += 1

    cache.parent.mkdir(parents=True, exist_ok=True)
    temporary = cache.with_suffix(cache.suffix + ".partial")
    with temporary.open("wb") as handle:
        handle.write(HEADER.pack(MAGIC, expected_n, expected_m))
        offsets.tofile(handle)
        predecessors.tofile(handle)
        labels.tofile(handle)
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(cache)
    metadata_path.write_text(json.dumps({
        **expected_metadata,
        "edge_endpoint_vertices": len(labels),
        "maximum_external_label": len(seen) - 1,
        "source_path": str(source),
    }, indent=2, sort_keys=True) + "\n")
    # The cache-validating subset deliberately excludes local source_path.
    return expected_metadata


class ReverseCSR:
    """Read-only reverse CSR backed by mmap."""

    def __init__(self, path):
        self.path = Path(path)
        self._handle = self.path.open("rb")
        self._mmap = mmap.mmap(self._handle.fileno(), 0, access=mmap.ACCESS_READ)
        magic, self.n, self.m = HEADER.unpack_from(self._mmap, 0)
        if magic != MAGIC:
            raise ValueError("invalid reverse CSR magic")
        offset_start = HEADER.size
        offset_end = offset_start + 8 * (self.n + 1)
        predecessor_end = offset_end + 4 * self.m
        expected_bytes = predecessor_end + 4 * self.n
        if len(self._mmap) != expected_bytes:
            raise ValueError("reverse CSR size mismatch")
        self.offsets = memoryview(self._mmap)[offset_start:offset_end].cast("Q")
        self.predecessors = memoryview(self._mmap)[offset_end:predecessor_end].cast("I")
        self.labels = memoryview(self._mmap)[predecessor_end:].cast("I")

    def close(self):
        if getattr(self, "offsets", None) is not None:
            self.offsets.release()
            self.predecessors.release()
            self.labels.release()
            self.offsets = None
            self.predecessors = None
            self.labels = None
            self._mmap.close()
            self._handle.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

    def indegree(self, vertex):
        return self.offsets[vertex + 1] - self.offsets[vertex]

    def incoming(self, vertex):
        start = self.offsets[vertex]
        stop = self.offsets[vertex + 1]
        return self.predecessors[start:stop]

    def original_label(self, vertex):
        return int(self.labels[vertex])


class BFSWorkspace:
    """Reusable O(n)-memory BFS state; each traversal resets only reached nodes."""

    def __init__(self, graph):
        self.graph = graph
        self.seen = array("I", [0]) * graph.n
        self.distance = array("I", [0]) * graph.n
        self.stamp = 0

    def _next_stamp(self):
        self.stamp += 1
        if self.stamp >= 0xFFFFFFFF:
            self.seen = array("I", [0]) * self.graph.n
            self.stamp = 1
        return self.stamp

    def harmonic_without_target_inedges(self, destination, target):
        """Compute h_{G-rho(target)}(destination)."""
        stamp = self._next_stamp()
        queue = array("I", [destination])
        self.seen[destination] = stamp
        self.distance[destination] = 0
        total = 0.0
        head = 0
        while head < len(queue):
            current = queue[head]
            head += 1
            if current == target:
                continue
            next_distance = self.distance[current] + 1
            for predecessor in self.graph.incoming(current):
                if self.seen[predecessor] == stamp:
                    continue
                self.seen[predecessor] = stamp
                self.distance[predecessor] = next_distance
                queue.append(predecessor)
                total += 1.0 / next_distance
        return total

    def singleton_cost(self, destination, target):
        """Compute the exact retained-singleton LCM objective g({destination})."""
        stamp = self._next_stamp()
        queue = array("I", [destination])
        self.seen[destination] = stamp
        self.distance[destination] = 0
        total = 1.0
        head = 0
        while head < len(queue):
            current = queue[head]
            head += 1
            next_distance = self.distance[current] + 1
            for predecessor in self.graph.incoming(current):
                if predecessor == target or self.seen[predecessor] == stamp:
                    continue
                self.seen[predecessor] = stamp
                self.distance[predecessor] = next_distance
                queue.append(predecessor)
                total += 1.0 / (next_distance + 1)
        return total

    def lcm_objective(self, target, deleted_tails=()):
        """Compute target harmonic centrality after deleting selected in-edges."""
        deleted = set(deleted_tails)
        stamp = self._next_stamp()
        queue = array("I", [target])
        self.seen[target] = stamp
        self.distance[target] = 0
        total = 0.0
        head = 0
        while head < len(queue):
            current = queue[head]
            head += 1
            next_distance = self.distance[current] + 1
            for predecessor in self.graph.incoming(current):
                if current == target and predecessor in deleted:
                    continue
                if self.seen[predecessor] == stamp:
                    continue
                self.seen[predecessor] = stamp
                self.distance[predecessor] = next_distance
                queue.append(predecessor)
                total += 1.0 / next_distance
        return total
