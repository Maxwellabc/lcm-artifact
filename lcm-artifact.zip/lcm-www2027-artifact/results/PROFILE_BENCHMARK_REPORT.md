# Exact Profile Construction Benchmark

One isolated process was used per row. `tracemalloc` peak covers profile construction; process RSS also includes the loaded graph and Python runtime. The full reference performs one reverse BFS per in-neighbor. This is a mechanism benchmark on one fixed target per dataset, not an aggregate runtime claim.

| Dataset | b/d | d | Stored labels | Reduction vs full | Build sec | Full/compressed time | Python peak MiB | Reduction vs full |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| ciaodvd | 0.25 | 132 | 44268 | 74.0% | 0.342 | 1.49x | 8.3 | 53.1% |
| ciaodvd | 0.50 | 132 | 87234 | 48.9% | 0.695 | 0.73x | 16.4 | 7.2% |
| ciaodvd | 0.75 | 132 | 130200 | 23.7% | 1.275 | 0.40x | 21.1 | -19.6% |
| moreno | 0.25 | 200 | 52124 | 71.8% | 0.355 | 1.18x | 8.9 | 52.4% |
| moreno | 0.50 | 200 | 103224 | 44.2% | 0.796 | 0.53x | 17.4 | 7.2% |
| moreno | 0.75 | 200 | 154324 | 16.6% | 1.324 | 0.32x | 23.9 | -27.7% |
| polblogs | 0.25 | 120 | 37821 | 73.9% | 0.342 | 1.15x | 7.2 | 51.4% |
| polblogs | 0.50 | 120 | 74421 | 48.7% | 0.713 | 0.55x | 11.8 | 20.2% |
| polblogs | 0.75 | 120 | 111021 | 23.5% | 1.154 | 0.34x | 18.4 | -24.4% |
| twitter | 0.25 | 126 | 55267 | — | 0.550 | — | 38.4 | — |
| twitter | 0.50 | 126 | 110531 | — | 0.730 | — | 47.3 | — |
| twitter | 0.75 | 126 | 164068 | — | 0.975 | — | 58.2 | — |

At b/d=0.25 the compressed builder stores 71.8% fewer labels on Moreno, 74.0% fewer on CiaoDVD, and 73.9% fewer on Political Blogs. It is 1.18x, 1.49x, and 1.15x as fast as the full builder, respectively, while cutting traced construction peaks by 52.4%, 53.1%, and 51.4%.

At b/d=0.75 the current Python multi-label implementation is slower than repeated BFS and its hash/set queue overhead can exceed the full builder's traced peak. This is the predicted high-budget failure regime; the paper must report it and should recommend switching to the full builder when b is a large fraction of d.
