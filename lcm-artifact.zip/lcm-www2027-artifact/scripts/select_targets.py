"""Freeze a deterministic target set before evaluating algorithm outcomes."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lcm.graph import load_edgelist  # noqa: E402


def file_hash(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--graph", type=Path, required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--minimum-indegree", type=int, default=100)
    parser.add_argument("--count", type=int, default=20)
    parser.add_argument("--development-count", type=int, default=1)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-ids", type=Path, required=True)
    args = parser.parse_args(argv)
    graph = load_edgelist(args.graph)
    graph_sha256 = file_hash(args.graph)
    eligible = [vertex for vertex in range(graph.n)
                if graph.indegree(vertex) >= args.minimum_indegree]
    if len(eligible) < args.count:
        raise ValueError("only %d eligible targets" % len(eligible))
    maximum = min(eligible, key=lambda vertex: (-graph.indegree(vertex), graph.labels[vertex]))
    remaining = [vertex for vertex in eligible if vertex != maximum]
    remaining.sort(key=lambda vertex: (
        hashlib.sha256((args.dataset + ":" + graph_sha256 + ":" + graph.labels[vertex])
                       .encode()).hexdigest(),
        graph.labels[vertex],
    ))
    selected = [maximum] + remaining[:args.count - 1]
    records = []
    for index, vertex in enumerate(selected):
        records.append({
            "target_index": index,
            "split": "development" if index < args.development_count else "test",
            "internal_id": vertex,
            "original_label": graph.labels[vertex],
            "indegree": graph.indegree(vertex),
        })
    payload = {
        "dataset": args.dataset,
        "graph": str(args.graph),
        "graph_sha256": graph_sha256,
        "node_mapping": "lexicographic string labels",
        "minimum_indegree": args.minimum_indegree,
        "count": args.count,
        "selection_rule": "maximum indegree first; remaining eligible vertices ordered by SHA256(dataset:graph_sha256:original_label)",
        "selected_before_algorithm_evaluation": True,
        "targets": records,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_ids.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                encoding="utf-8")
    args.output_ids.write_text(" ".join(str(record["internal_id"]) for record in records) + "\n",
                               encoding="utf-8")
    print(args.output_json)


if __name__ == "__main__":
    main()

