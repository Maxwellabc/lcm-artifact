"""Build a deterministic, non-redistributing artifact archive and hash manifest."""
import argparse
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PACKAGE = "lcm-www2027-artifact"
WORKSPACE_TOKEN = b"<WORKSPACE>"
MACOS_USER_PATH_MARKER = b"/" + b"Users" + b"/"
DEFAULT_IDENTITY_MARKERS = ROOT / "private/release_identity_markers.txt"

PATTERNS = (
    "LICENSE",
    "THIRD_PARTY_NOTICES.md",
    "CITATION.cff",
    ".zenodo.json",
    "README.md",
    "ARTIFACT_README.md",
    "RESEARCH_PLAN.md",
    "STATUS.md",
    "pyproject.toml",
    "requirements-lp-lock.txt",
    "requirements-paper.txt",
    "lcm/*.py",
    "blockmatch/*.py",
    "scalability/*.py",
    "scripts/*.py",
    "tests/*.py",
    "configs/*.json",
    "data/README.md",
    "data/manifests/*.json",
    "data/targets/*",
    "notes/*.md",
    "notes/doi_metadata_2026-10-15.json",
    "notes/iyer2013curvature_official.bib",
    "planning/*.md",
    "results/raw/test-*.jsonl",
    "results/test_exact_certificate_*.jsonl",
    "results/test_conflict_sensitivity_*.jsonl",
    "results/profile_benchmarks.jsonl",
    "results/synthetic_overlap_family.jsonl",
    "results/structure_validation.json",
    "results/scalability-extension.jsonl",
    "results/blockmatch_real_graph.jsonl",
    "results/structural_real_graph.jsonl",
    "results/BLOCKMATCH_REAL_GRAPH_*.json",
    "results/STRUCTURAL_BOUND_AUDIT.json",
    "results/STRUCTURAL_REAL_GRAPH_SUMMARY.json",
    "results/SCALABILITY_EXTENSION_SUMMARY.json",
    "results/EXHAUSTIVE_SMALL_GRAPH_AUDIT.json",
    "results/BLOCK_MATCHING_CANDIDATE_AUDIT.json",
    "results/ARTIFACT_AUDIT.json",
    "results/RELEASE_SMOKE_AUDIT.json",
    "results/*_REPORT.md",
    "paper/main.tex",
    "paper/acmart.cls",
    "paper/ACM-Reference-Format.bst",
    "paper/acmart-source/*",
    "paper/TEMPLATE_PROVENANCE.md",
    "paper/references.bib",
    "paper/main.bbl",
    "paper/main.log",
    "paper/main.pdf",
    "paper/README.md",
    "paper/CLAIM_EVIDENCE.md",
    "paper/REVIEWER_PROOF_MAP.md",
    "paper/SUBMISSION_CHECKLIST.md",
    "paper/INDEPENDENT_REVIEW_PACKET.md",
    "paper/INTERNAL_COLD_REVIEW.md",
    "paper/generated/*.tex",
    "paper/figures/*.pdf",
    "paper/figures/*.png",
)

FORBIDDEN_PREFIXES = (
    "private/",
    "data/raw/",
    "data/cache/",
    "data/downloads/",
    "external/",
    ".venv/",
    "dist/",
)


def sha256_bytes(payload):
    return hashlib.sha256(payload).hexdigest()


def read_identity_markers(path):
    """Read private, case-insensitive byte markers without publishing them."""
    if path is None or not path.is_file():
        return ()
    markers = []
    for line in path.read_text(encoding="utf-8").splitlines():
        marker = line.strip()
        if marker and not marker.startswith("#"):
            markers.append(marker.encode("utf-8").lower())
    return tuple(markers)


def read_prior_transformation_records():
    """Read transformation provenance when rebuilding an extracted package.

    Extracted raw logs already contain the public <WORKSPACE> token, so their
    original private bytes are intentionally unavailable.  Carry forward an
    earlier source hash only when the existing manifest's packaged hash and
    size exactly match the current file.
    """
    path = ROOT / "ARTIFACT_MANIFEST.json"
    if not path.is_file():
        return {}
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest.get("package") != PACKAGE or manifest.get("format") != 2:
        raise RuntimeError("unsupported prior artifact manifest")
    records = {}
    for record in manifest.get("files", []):
        if record.get("transformation") == "redact_absolute_workspace_path":
            if "source_sha256" not in record:
                raise RuntimeError(
                    "prior transformed record lacks source hash: %s"
                    % record.get("path")
                )
            records[record["path"]] = record
    return records


def release_payload(relative):
    """Return publishable bytes without mutating the frozen source evidence.

    Early, non-frozen error records in the raw JSONL logs contain tracebacks from
    the development checkout.  Keep those records for protocol transparency but
    replace this checkout's absolute prefix in the packaged copy.  The manifest
    records both hashes whenever this transformation changes a file.
    """
    source = (ROOT / relative).read_bytes()
    payload = source
    if relative.parts[:2] == ("results", "raw") and relative.suffix == ".jsonl":
        payload = source.replace(str(ROOT).encode(), WORKSPACE_TOKEN)
    if MACOS_USER_PATH_MARKER in payload:
        raise RuntimeError(
            "artifact member contains an absolute macOS user path: %s"
            % relative.as_posix()
        )
    return source, payload


def selected_files():
    files = set()
    for pattern in PATTERNS:
        for path in ROOT.glob(pattern):
            if path.is_file():
                files.add(path.relative_to(ROOT))
    relative_files = sorted(files, key=lambda path: path.as_posix())
    if not relative_files:
        raise RuntimeError("artifact selection is empty")
    for relative in relative_files:
        name = relative.as_posix()
        if name.startswith(FORBIDDEN_PREFIXES) or "__pycache__" in relative.parts:
            raise RuntimeError("forbidden artifact member: %s" % name)
        if (ROOT / relative).is_symlink():
            raise RuntimeError("artifact members must not be symlinks: %s" % name)
    return relative_files


def tar_info(name, size, mode=0o644):
    info = tarfile.TarInfo(name=name)
    info.size = size
    info.mode = mode
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    return info


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "dist")
    marker_group = parser.add_mutually_exclusive_group()
    marker_group.add_argument(
        "--identity-markers-file",
        type=Path,
        help=(
            "private UTF-8 file with one case-insensitive marker per line; "
            "defaults to private/release_identity_markers.txt when present"
        ),
    )
    marker_group.add_argument(
        "--no-identity-marker-check",
        action="store_true",
        help=(
            "disable author-identity marker scanning only for an intentionally "
            "de-anonymized public release; absolute-path and forbidden-member "
            "checks still apply"
        ),
    )
    args = parser.parse_args(argv)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    marker_path = None if args.no_identity_marker_check else args.identity_markers_file
    if (not args.no_identity_marker_check and marker_path is None
            and DEFAULT_IDENTITY_MARKERS.is_file()):
        marker_path = DEFAULT_IDENTITY_MARKERS
    markers = read_identity_markers(marker_path)
    prior_transformed = read_prior_transformation_records()

    files = selected_files()
    records = []
    payloads = []
    transformed = []
    for relative in files:
        source, payload = release_payload(relative)
        lowered = payload.lower()
        if any(marker in lowered for marker in markers):
            raise RuntimeError(
                "artifact member matches a private identity marker: %s"
                % relative.as_posix()
            )
        payloads.append((relative, payload))
        record = {
            "path": relative.as_posix(),
            "bytes": len(payload),
            "sha256": sha256_bytes(payload),
        }
        if source != payload:
            record["source_sha256"] = sha256_bytes(source)
            record["transformation"] = "redact_absolute_workspace_path"
            transformed.append(relative.as_posix())
        elif relative.as_posix() in prior_transformed:
            prior = prior_transformed[relative.as_posix()]
            if (WORKSPACE_TOKEN not in payload
                    or prior.get("bytes") != len(payload)
                    or prior.get("sha256") != record["sha256"]):
                raise RuntimeError(
                    "cannot verify prior transformation provenance: %s"
                    % relative.as_posix()
                )
            record["source_sha256"] = prior["source_sha256"]
            record["transformation"] = "redact_absolute_workspace_path"
            transformed.append(relative.as_posix())
        records.append(record)

    manifest = {
        "package": PACKAGE,
        "format": 2,
        "file_count": len(records),
        "files": records,
        "excluded": ["private", "data/raw", "data/cache", "data/downloads",
                     "external", ".venv", "dist", "tmp", "__pycache__"],
        "transformations": {
            "redact_absolute_workspace_path": {
                "replacement": WORKSPACE_TOKEN.decode(),
                "files": transformed,
                "note": (
                    "Only packaged copies are changed; source_sha256 preserves "
                    "the identity of each frozen source log. Extracted-package "
                    "rebuilds reverify the packaged hash and carry that original "
                    "source hash forward from ARTIFACT_MANIFEST.json."
                ),
            },
        },
    }
    manifest_payload = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()

    archive = output_dir / (PACKAGE + ".tar.gz")
    with archive.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as tar:
                for relative, payload in payloads:
                    name = "%s/%s" % (PACKAGE, relative.as_posix())
                    mode = 0o755 if relative.parts[0] == "scripts" else 0o644
                    tar.addfile(tar_info(name, len(payload), mode), io.BytesIO(payload))
                name = "%s/ARTIFACT_MANIFEST.json" % PACKAGE
                tar.addfile(tar_info(name, len(manifest_payload)),
                            io.BytesIO(manifest_payload))

    archive_hash = sha256_bytes(archive.read_bytes())
    checksum = output_dir / (archive.name + ".sha256")
    checksum.write_text("%s  %s\n" % (archive_hash, archive.name))
    print(json.dumps({
        "archive": str(archive),
        "archive_sha256": archive_hash,
        "files": len(records),
        "private_identity_markers_checked": len(markers),
        "uncompressed_bytes": sum(record["bytes"] for record in records),
        "checksum": str(checksum),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
