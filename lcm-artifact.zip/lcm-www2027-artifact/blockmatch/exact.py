"""BlockMatch with exact nonnegative integer oracle values and blossom weights.

A common denominator turns reciprocal-distance costs into integers. Keeping
these integers through matching avoids float priority errors near ties. The
frozen float implementation remains untouched for historical comparisons.
"""
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations
import networkx as nx


@dataclass(frozen=True)
class ExactResult:
    selected: frozenset
    blocks: tuple
    surrogate: int
    objective: int
    oracle_calls: int


def block_match_exact(items, k, integer_value):
    items = tuple(items)
    if len(set(items)) != len(items) or not 1 <= k <= len(items):
        raise ValueError('distinct items and 1 <= k <= len(items) required')
    calls = 0
    @lru_cache(None)
    def value(selected):
        nonlocal calls
        calls += 1
        answer = integer_value(selected)
        if not isinstance(answer, int) or answer < 0:
            raise ValueError('oracle must return nonnegative Python integers')
        return answer
    if k == 1:
        i = min(range(len(items)), key=lambda i: (value(frozenset([items[i]])), i))
        blocks = ((items[i],),)
    else:
        triple = ()
        if k % 2:
            triple_positions = min(combinations(range(len(items)), 3),
                key=lambda c: (value(frozenset(items[i] for i in c)), c))
            triple = tuple(items[i] for i in triple_positions)
        outside = tuple(i for i in range(len(items)) if items[i] not in triple)
        r = (k - len(triple)) // 2
        pairs = []
        if r:
            graph = nx.Graph()
            graph.add_nodes_from(outside)
            for i, j in combinations(outside, 2):
                graph.add_edge(i, j, weight=value(frozenset([items[i], items[j]])))
            # Disjoint integer dummy IDs make the fixed-cardinality reduction.
            dummy = tuple(range(len(items), len(items) + len(outside) - 2 * r))
            graph.add_nodes_from(dummy)
            for z in dummy:
                for i in outside:
                    graph.add_edge(z, i, weight=0)
            matching = nx.min_weight_matching(graph, weight='weight')
            if len(matching) != (len(outside) + len(dummy)) // 2:
                raise AssertionError('matching must be perfect after dummy reduction')
            pairs = sorted(tuple(sorted((i, j))) for i, j in matching
                           if i < len(items) and j < len(items))
            if len(pairs) != r:
                raise AssertionError('wrong exact matching cardinality')
        blocks = ((triple,) if triple else ()) + tuple((items[i], items[j]) for i, j in pairs)
    selected = frozenset(u for block in blocks for u in block)
    surrogate = sum(value(frozenset(block)) for block in blocks)
    objective = value(selected)
    return ExactResult(selected, blocks, surrogate, objective, calls)
