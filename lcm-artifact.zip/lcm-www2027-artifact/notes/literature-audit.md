# 文献与新颖性初审

检索日期：2026-09-25--10-01。用途：WWW 2027 选题与实验规划；本文件是有界初审，不是完整系统综述，也不证明“首次”或“无人研究”。以下技术判断区分已核实的文献事实与待验证的研究推断。

## 1. 优先结论

1. 原论文已经正式发表于 **WWW 2024，410–421 页**，DOI `10.1145/3589334.3645382`。应把它作为同会直接前作，而不只是 2024 年预印本。
2. 本轮题名、作者主页和邻域检索未确认 2024–2026 年针对完全相同模型的直接算法后续；检索不完备，不能据此写“没有后续工作”。
3. **“加权覆盖表示 + 正则化最小割 + 枚举参数 + 贪心补齐预算”已有非常接近的经典组合**，尤其是 Tatti 的 ECML PKDD 2021 论文。单独复用这一框架不宜宣称核心新算法。
4. 最有说服力的候选缺口是：在原问题严格预算下，设计利用距离/候选重叠结构的方法，使解质量、运行时间、内存和可核验最优性差距同时可用。能否构成论文贡献，取决于新的结构性结果与公平实验，不是方法名称。

## 2. 直接前作

**S1. Miyauchi, Severini, Bonchi. Local Centrality Minimization with Quality Guarantees. WWW 2024.**

- [ACM 正式页面](https://doi.org/10.1145/3589334.3645382)
- [作者所属机构记录](https://iris.imtlucca.it/handle/20.500.11771/33800)
- [作者预印本](https://arxiv.org/html/2402.07718v1)
- [作者论文目录](https://sites.google.com/view/miyauchi/publications)

已确认：原问题只删目标节点入边、最小化其谐波中心性。论文证明困难性与子模性，给出可扩展近似算法及基于 Lovász 扩展的双标准算法。作者明确把改进近似界、多目标节点列为后续方向。投稿时必须明确超越该文的贡献，不能把子模性或首次质量保证作为新结论。

正式发表时间已由 ACM 页面核实为 2024-05-13。正式 PDF 与 arXiv v1 是否有逐字差异未做全文 diff；本文实际使用的 A1 定理、实验数据集和后续问题已经交叉核对正式元数据、作者预印本与作者代码。公开引用网络的复核结果见第 8 节。作者主页列入 Graph Algorithms and Modeling for the Web 方向，但不应据此推定 WWW 2027 的分轨设置。

## 3. 必须处理的经典技术

| 来源 | 已核实结果或方法 | 对本项目的直接影响 |
|---|---|---|
| **S2. Chlamtáč et al., The Densest k-Subhypergraph Problem, APPROX 2016 / SIAM J. Discrete Math. 2018**；[原文](https://arxiv.org/abs/1605.04284)、[会议 PDF](https://drops.dagstuhl.de/storage/00lipics/lipics-vol060-approx-random2016/LIPIcs.APPROX-RANDOM.2016.6/LIPIcs.APPROX-RANDOM.2016.6.pdf) | 一般 Minimum p-Union 有 `O(sqrt(m))` 近似，文中的 `m` 为超边数；还研究 3-uniform 与 interval 特例。 | 入边候选数、原图节点数、覆盖宇宙大小要分开记号。移植近似比前必须核对加权情形、参数映射和输入膨胀。 |
| **S3. Chlamtáč, Dinitz, Makarychev, Minimizing the Union: Tight Approximations for Small Set Bipartite Vertex Expansion, SODA 2017**；[原文](https://arxiv.org/abs/1611.07866)、[出版社](https://epubs.siam.org/doi/10.1137/1.9781611974782.56) | 对以集合数计的参数 `n`，给出 `n^(1/4+ε)` 近似，并讨论依赖复杂性猜想的障碍及松弛间隙。 | “比平方根更好的 MkU 近似”不是空白；不能把条件性困难性写成无条件下界，也不能直接把无权结果套到本问题。 |
| **S4. Svitkina & Fleischer, Submodular approximation: sampling-based algorithms and lower bounds**；[作者原文](https://arxiv.org/abs/0805.1071) | 研究带基数下界的子模最小化及值查询模型中的近似上下界。 | 保留入边模型属于需审查的受限子模最小化语境；“子模所以贪心有 `1−1/e` 保证”是错误方向。Oracle 下界也不能不加说明转成显式图输入下界。 |
| **S5. Nagano, Kawahara, Aihara, Size-constrained Submodular Minimization through Minimum Norm Base, ICML 2011**；[会议原文](https://icml.cc/2011/papers/506_icmlpaper.pdf) | 能在多项式时间给出某些基数的精确解，不保证覆盖用户任意指定的基数。 | 参数化正则解可能跳过所需预算；“枚举参数就精确解决所有预算”不成立。 |
| **S6. Iyer, Jegelka, Bilmes, Fast Semidifferential-based Submodular Function Optimization, ICML 2013**；[会议页面和 PDF](https://proceedings.mlr.press/v28/iyer13.html) | 用离散半微分构造并优化模块界，覆盖有约束与无约束的子模优化。 | Majorization–minimization / 模块上界迭代应考虑作为便宜强基线，不能仅换名当新算法。 |
| **S7. Gallo, Grigoriadis, Tarjan, A Fast Parametric Maximum Flow Algorithm and Applications, 1989**；[作者技术报告](https://www.cs.princeton.edu/techreports/1987/105.pdf) | 参数化容量与相关最大流/最小割序列已有经典算法。 | 最小割表示、热启动、参数断点不能独立作为本项目理论创新；真正区别应落在专有图结构、复杂度或证书。 |

### 特别重要：Tatti 2021

**S8. Nikolaj Tatti. Approximation Algorithms for Confidence Bands for Time Series. ECML PKDD 2021, 437–452.**

- [原文 HTML](https://arxiv.org/html/2112.06225v1)
- [会议官方 PDF](https://ecmlpkdd-storage.s3.eu-central-1.amazonaws.com/former-websites/2021/wp-content/uploads/2021/07/sub_870.pdf)
- [出版社会议卷](https://link.springer.com/book/10.1007/978-3-030-86486-6?page=2)

已确认：该文将问题联系到加权 Minimum k-Union，用最小割解带线性规模奖励的正则问题，枚举嵌套解；目标基数缺失时，选择候选区间并贪心补齐，给出 `sqrt(n)+1` 保证。其原问题要求包含一条参考序列。

本项目动作：精读 §3–4，设计准确适配后的强基线；核验参考序列、权重与图距离表示的差异。只有证明可迁移的完整条件后，才能写本问题继承何种近似比。不能把该文结论直接声明为本项目已证定理。

## 4. 2024–2026 年邻近研究

| 文献与一手来源 | 已核实内容 | 与本项目关系 / 未决问题 |
|---|---|---|
| **S9. Li et al. Heavy Nodes in a Small Neighborhood: Exact and Peeling Algorithms With Applications, TKDE 37(4), 2025, 1853–1870**；[作者页](https://hildeverbeek.nl/publications/heavy-nodes-small-neighborhood/)、[机构存档 PDF](https://research.vu.nl/ws/portalfiles/portal/408550592/Heavy_Nodes_in_a_Small_Neighborhood_Exact_and_Peeling_Algorithms_With_Applications.pdf) | 加权、无固定基数的 MkU 密度比率变体；有 LP 精确算法、收缩与分解、peeling 算法。DOI `10.1109/TKDE.2024.3515875`，2024 年接收。 | 若用密度子程序、peeling、收缩，需要比较技术与适配成本。该无约束比率目标不能直接替代原问题严格预算。 |
| **S10. Dimant & Krumke. On approximating partial scenario set cover, TCS 1023, 2025, 114891**；[出版社全文](https://www.sciencedirect.com/science/article/pii/S0304397524005085) | LP rounding 加 greedy、密度子问题和最小流相关方法；与 MkU 近似有明确关系。DOI 含 2024，但卷期日期是 **2025-01-01**。 | 不能仅凭 DOI 年份引用作 2024 年卷期论文；通用“组合 LP 与贪心”的贡献需要进一步区分。 |
| **S11. Saha et al. Hide Exposures by Removing Mastermind’s External Sources on Social Network, AAAI 2025 Student Abstract**；[AAAI 原文](https://ojs.aaai.org/index.php/AAAI/article/download/35296/37451) | HERMES 是基于社区与多种中心性排序的隐藏启发式，属于相邻网络隐藏任务。 | 可以放相关工作；模型和指标不同，不能未经适配就当同问题 SOTA，也不宜照搬其应用叙事。 |
| **S12. Kangaslahti et al. Network-Based Interventions for HIV Prevention via Cascade-Aware Suppression of Transmission, arXiv 2605.20218, 2026**；[作者预印本](https://arxiv.org/abs/2605.20218)、[全文](https://arxiv.org/html/2605.20218v1) | CAST 将受限传播抑制联系到 MkU，用采样浓缩界处理随机传播，并给出近似分析。 | 若把项目扩展成随机传播或采样覆盖，需逐项区别。不是相同谐波中心性目标；本轮未核实正式会议版本。 |
| **S13. Miyauchi et al. A Survey on Algorithmic Interventions in Opinion Dynamics, arXiv 2603.10756, 2026**；[作者综述](https://arxiv.org/abs/2603.10756) | 按目标函数整理网络观点干预及理论、经验结果。 | 仅用作后续文献入口；中心性下降不能直接作为观点极化、真实曝光或扩散下降的实证证据。 |

本轮还搜到引用 S1 的大模型图算法评测预印本 [Exposing Weaknesses of Large Reasoning Models through Graph Algorithm Problems](https://arxiv.org/abs/2602.06319)。它不是已确认的相同优化问题算法改进，故不列为核心 baseline。

## 5. 初步新颖性矩阵（研究判断，不是已证明事实）

| 候选思路 | 单独作为贡献的风险 | 有意义的进一步问题 |
|---|---|---|
| 预计算到入邻居的距离，避免每次删边重新 BFS | 容易被视为自然工程改进；还可能爆内存 | 能否有严格正确的稀疏表示、增量更新和按图结构/预算给出的复杂度界？ |
| 写成加权 coverage / MkU | 是重要建模步骤，但邻域文献已成熟 | 能否证明利用真实距离矩阵额外结构得到比通用 MkU 更强的结果？ |
| 用 coverage LP / min-cut 替换次梯度 | 松弛或正则求解器的自然替换 | 能否给出新的紧化、廉价且强的下界、严格预算修复分析？ |
| 参数最小割 + 贪心补齐 + local search | 与 S8 高度邻近；只多 local search 通常不够 | 哪类参数跳跃造成失败？专门处理这些缺口能否有新保证和可复现实证？ |
| source sampling / truncation / sketch | 一般加速方法，S12 已有 MkU + 采样路线 | 能否同时给出所有可行解的误差控制，进而证明选择误差，而非仅对一个固定解估计无偏？ |
| 多目标、加权、鲁棒 | 原文已提 group target；通用求和扩展往往直接 | 是否真实改变了可解结构、提供新困难性/算法，而不是仅多一个输入参数？ |
| 证明严格预算下更好通用近似比 | 潜在贡献强，理论风险高 | 先检查与 MkU 现有近似、条件困难性及权重扩展的关系，避免承诺突破。 |

最适合先做的验证是：相同实例、相同预算、相同时间限制下，将原文 Algorithm 1、原文 Greedy 的公平加速版、S8 适配、模块上界迭代、精确 MIP/穷举小实例放到同一个框架，观察真正未解决的失败模式。拟议方法至少应在关键维度明显超出这些对手，而不只是优于原仓库 Python 的低效实现。

若主张“可认证”，应清楚区分可行解上界 `UB` 与有效下界 `LB`。`(UB-LB)/UB` 衡量证书差距；已知精确最优解时才能报告真实最优性差距。弱 LP 会给出合法但无用的证书，不能只展示存在一个下界。

## 6. 检索日志与剩余审查

检索方式：公开网页搜索并打开作者原文、会议/出版社页面、作者主页和机构稿件。聚合站只用于发现题名，结论依据一手来源。没有把搜索引擎显示的“抓取于几个月前”当作发表日期。

检索词（2026-09-25 执行）：

- `"Local Centrality Minimization with Quality Guarantees"`
- `"Local Centrality Minimization" 2025 2026`
- `"centrality minimization" "2025"`；`"centrality minimization" "2026"`
- `"harmonic centrality" "minimization" 2025 2026`
- `"Miyauchi" "Severini" "Bonchi" "2025" centrality`，以及 2026 变体
- `"Local Centrality Minimization" "coverage"`；`"Local Centrality Minimization" "min-cut"`
- `"Minimum k-Union" approximation submodular minimization`
- `"minimum k-union" "2024" "algorithm"`，以及 2025、2026 变体
- `"minimum k-union" "weighted" approximation algorithm`
- `"minimum k-union" "linear programming" relaxation`
- `"cardinality constrained" "coverage" "minimization" Lovasz linear programming`
- `"submodular minimization" cardinality approximation Svitkina Fleischer`
- `"Size-constrained Submodular Minimization" Nagano Kawahara Aihara 2011`
- `"Fast Semidifferential-based Submodular Function Optimization" Iyer Jegelka Bilmes`
- `"Fast parametric maximum flow algorithm" Gallo Grigoriadis Tarjan 1989`
- `"Approximation algorithms for confidence bands for time series" ECML PKDD 2021 2022`
- `"Hide Exposures by Removing Mastermind"`
- `"Network-Based Interventions for HIV Prevention" CAST authors`

已完成的后续动作：从 OpenAlex、OpenCitations、Crossref 和 Semantic
Scholar 交叉导出 S1 的公开被引记录并逐篇核对正文；精读 S8 的
minimum-union/参数割路线；检查 nearest-terminal、嵌套单项式凸包、
maximum closure with side constraints 与 precedence-conflict 前作。第 8 节记录
被引复核。S2/S3/S9/S10 的加权可迁移条件仍不够支持把其保证直接写进本文，
因此当前稿件没有移植这些比率或把它们当作可运行的等模型基线。

投稿前仍需再次检索 2026 年末与 2027 年初成果，并由熟悉
cardinality-constrained submodular optimization 的外部研究者审查新颖性。

### 侧约束 closure 与冲突图补充（2026-09-26）

在实现跨源冲突匹配后补做的定向检索确认：这条路线必须放进 precedence-constrained knapsack / maximum closure with side constraints 的既有脉络，不能把“冲突图 + closure + 拉格朗日松弛”整体宣称为新框架。

- **S17. Boland, Bley, Fricke, Froyland, Sotirov. Clique-based facets for the precedence constrained knapsack problem. Mathematical Programming 133:481–511, 2012. DOI 10.1007/s10107-010-0438-7.** [作者公开 PDF](https://web.maths.unsw.edu.au/~froyland/BBFFS12.pdf)。该文把两个 precedence items 的闭包并集超过容量定义为冲突边，使用 clique inequalities，并在 branch-and-cut 中实证强化。本文的两个前缀触发器若其候选并集超过 b，正是这一一般冲突图思想的特例；pair/clique 有效性不构成新颖性。
- **S18. Bienstock, Zuckerberg. A New LP Algorithm for Precedence Constrained Production Scheduling, 2009 technical manuscript.** [作者 PDF](https://www.columbia.edu/~dano/papers/lpprec.pdf)。该文把带少量侧约束的模型写成 maximum-weight closure，拉格朗日化侧约束后反复求 min-cut，并给出 LP 求解框架。因而“对偶化侧约束以保留 min-cut 内层”也是已有通用方法。

本项目尚可能区分的部分收缩为：LCM 的预算精确距离前缀构造；从参数割的超预算侧按真实触发状态分离前缀冲突；用奖励容量约束选取匹配，使每个候选对偶点仍能由 O(nb) closure 网络和有理整数流严格认证；以及这种受限对偶在 LCM 实例上的质量—资源证据。这仍需与 S17 的 clique separation、S18 的多侧约束 Lagrangian LP、PCKP cover/clique 文献逐项比较。若只能表述为直接适配，应作为强证书模块而非理论首创。

允许的研究表述：我们考虑并评估一个候选框架；在本轮检查范围内未发现完全相同方法。禁止直接表述：首次 coverage 转化、首次参数割、首次 MkU 采样、没有任何后续、保证 WWW 接收。

## 7. 针对“预算 b 的最近 b+1 入邻居 + 截断 LP”补充审查

本节针对规划过程中提出的具体候选思路：每个源节点只保存最近的 `b+1` 个目标入邻居，即可精确评价删除至多 `b` 条入边的任意方案；将每个源节点的距离排名展开成嵌套前缀触发项，并删除不可能被完整删除的、长度大于 `b` 的前缀项。以下仍是新颖性风险定位，不是穷尽性判断。

### 新找到的核心近邻

**S14. Sariel Har-Peled. Computing the k Nearest-Neighbors for all Vertices via Dijkstra. 2016.** [作者预印本](https://arxiv.org/abs/1607.07818)，[作者 PDF](https://sarielhp.org/p/14/k_nn/k_nn.pdf)。有向正权图上计算各点的 k 最近邻；Remark 3.4 明确允许指定 terminal 子集，时间 `O(k(n log n + m))`。因此多标签传播、达到 k 个不同标签即停止扩展是已知算法思想。无权图反向 BFS 的实现和正确性仍需精确给出，但不宜声称通用 k 最近源算法为原创。

**S15. Chen, Dash, Günlük. Convexifying Multilinear Sets with Cardinality Constraints: Structural Properties, Nested Case and Extensions. Discrete Optimization 50:100804, 2023.** [作者预印本](https://arxiv.org/abs/2007.15725)，[作者稿 PDF](https://optimization-online.org/wp-content/uploads/2020/07/7941.pdf)，[作者机构发表记录](https://research.ibm.com/publications/convexifying-multilinear-sets-with-cardinality-constraints-structural-properties-nested-case-and-extensions)。研究 `δ_i=∏_{j∈S_i} x_j` 和双侧基数约束，给出嵌套单项式的凸包描述、可多项式分离的不等式，并向一般集合推广。它与每个源节点的前缀触发变量高度相关。需要优先阅读，不能仅把基数用于删去不可能的高阶项就泛称新的强 LP。

**S16. Bao, Cai, Chen. Sparsify Submodular Functions under Cardinality Constraints. arXiv 2606.20777, 2026.** [作者预印本](https://arxiv.org/abs/2606.20777)。研究在基数约束范围内近似保持分解子模函数的值，通过分量重加权实现更小稀疏化。与精确保留每个源节点的有限距离前缀不同；但“首次预算感知稀疏化”一类笼统表述不可用。对源节点采样方案尤其需审查此作。

另外，基数约束强化子模 epigraph 的脉络还包括 [Yu & Ahmed, Polyhedral results for a class of cardinality constrained submodular minimization problems](https://doi.org/10.1016/j.disopt.2015.07.005)，以及 [Yu & Küçükyavuz, Strong valid inequalities for a class of concave submodular minimization problems under cardinality constraints](https://arxiv.org/abs/2103.04398)。两者的具体函数族不应未经证明就套用到 LCM；“利用预算比无约束 Lovász 松弛更强”这一思想本身已有先例。

**S19. Chen, Chen, Ye, Zhang. Approximation Algorithms for Two Extensions of Min-k-Union. Journal of Computer and System Sciences 157:103750, 2026.** [正式 DOI](https://doi.org/10.1016/j.jcss.2025.103750)，[出版社页面](https://www.sciencedirect.com/science/article/pii/S0022000025001321)，[COCOON 2024 会议版](https://doi.org/10.1007/978-981-96-1090-7_3)。该文把第二个问题明确定义为：给定 `d` 元 ground set、非负单调次模函数及基数 `k`，求大小恰为 `k` 的最小值集合；给出 `2 sqrt(d)` 近似，并称其在 Svitkina--Fleischer 值查询下界意义下相差对数因子。2026-09-27 通过华中科技大学机构访问阅读全文版会议稿：`k<=sqrt(d)` 时逐步选最小边际单点，得到 `k` 近似；`k>sqrt(d)` 时反复用无约束次模最小化求 `f(S)/|S|` 最小的密度块，到阈值后截断并以最小边际单点补足，得到 `2 sqrt(d)`。JCSS 页面明确称算法是这两种贪心的组合，并标明会议版为其 preliminary result。两版可见内容均未使用 pair/triple 或固定基数 matching。它仍是 SingletonSort 与 BlockMatch 的直接一般前作，论文必须说明算法区别并避免声称改进其一般值查询结果。

### 二元组/三元组匹配候选专项复查（2026-09-26）

针对 `notes/block-matching-candidate.md` 的候选定理，追加检索：`"submodular minimization" "minimum weight matching" cardinality`、`"minimum weight matching" "minimum k-union"`、`"pair" "monotone submodular minimization" approximation`、`"submodular" "k/2-approximation" minimization`，并核对 S19 的期刊页面、COCOON 全文、Crossref、OpenAlex、Semantic Scholar 与 Unpaywall 元数据。未检出把候选集合分成 pairs（奇数时一个 triple）并以 block 函数值做最小权固定基数匹配的相同结果。S19 完整会议版的算法和证明已核对，结构明确不同；期刊页面也确认同一两贪心框架。当前结论提升为：最直接前作对照已通过，候选证明通过内部审计，**仍需独立理论审稿与最终宽范围查新**，但不再等待 S19 全文索取。

### 应怎么审查和定位

下面是本项目的数学推断：令 `x_e=1` 表示删除入边，`δ_{uj}=∏_{e∈P_{uj}}x_e` 表示源节点 u 的前 j 个候选全部被删。在 `Σx_e≤b` 下，`j>b` 的单项式必为 0。因此新截断 LP 至少要与 **完整前缀 LP + 全部不可能触发变量固定为 0** 比较；若二者等价，就不能把证书变强归因为新凸包理论。截断仍可能是有价值的精确压缩与构建加速，但需分开叙述。

建议保留三个实际问题：

1. 精确前缀表示能否直接在原图上构建，避免完整 `|V|×入度` 距离表？记录 O((b+1)(n+m)) 的实现条件、标签去重成本、并列距离与不可达点处理。
2. 应用 S15 的单链凸包后还有多大差距？不同源节点之间共享入边造成的耦合是否需要新约束、分解或有效分离算法？这比仅固定高阶项更可能形成可辨别贡献。
3. 能否让计算下界的代价接近求可行解，并在预算比例小、入度大及大量并列距离的实例上稳定获益？当 `b≈入度` 时，前缀压缩可能不再节省资源，应预先报告失败范围。

补充检索词：`"minimum k-union" "cardinality" "inequalities"`、`"submodular" "cardinality" "truncation" "minimization"`、`"k nearest sources" algorithm BFS`、`"all vertices" "k nearest" "Dijkstra"`、`"cardinality" "monomial" "linearization" cover inequalities`、`"Convexifying multilinear sets with cardinality constraints"`、`"Sparsify Submodular Functions under Cardinality Constraints"`。本轮没有确认完全相同 LCM 预算截断方法的公开论文；这不等同于确认新颖性。

## 8. 投稿前直接后续工作复查（2026-09-26）

再次检索精确标题、`local/harmonic centrality minimization`、目标节点入边删除、作者 2025--2026 发表记录，以及 arXiv、ACM、OpenReview 和 DBLP 索引。arXiv API 对精确短语 `"local centrality minimization"` 只返回 S1；`"harmonic centrality" AND minimization` 没有返回后续条目。可确认的直接论文仍是 [WWW 2024 正式版本](https://doi.org/10.1145/3589334.3645382) 与 [arXiv 记录](https://arxiv.org/abs/2402.07718)。

### S1 的公开被引记录

索引在同一天并不一致：Crossref、OpenCitations 和 OpenAlex 各识别出两个带正式 DOI 的唯一后续作品；Semantic Scholar 返回五条记录，去重同一篇 GCoder 的预印本和 CIKM 版本后是四篇唯一作品。逐篇打开一手全文后的分类如下。

| 唯一后续作品 | 正文中使用 S1 的位置 | 判定 |
|---|---|---|
| [GCoder: Improving Large Language Model for Generalized Graph Reasoning, CIKM 2025](https://doi.org/10.1145/3746252.3761066)（含 [arXiv 前身](https://arxiv.org/abs/2410.19084)） | 引言把 S1 与其他 WWW 图问题并列为 Web mining 的应用例子。 | 背景引用；不研究 LCM，也没有算法或定理重叠。 |
| [Fast Percolation Centrality Approximation with Importance Sampling, ICDM 2025](https://doi.org/10.1109/ICDM65498.2025.00121)（[作者预印本](https://arxiv.org/abs/2509.11454)） | 相关工作用一句话把 S1 归为“删边以降低节点中心性”的修改问题。 | 邻接主题；主问题是估计 percolation centrality，不是选择目标入边。 |
| [Exposing Weaknesses of Large Reasoning Models through Graph Algorithm Problems, ICLR 2026](https://openreview.net/forum?id=HBXUC3YtP4)（[arXiv](https://arxiv.org/abs/2602.06319)） | 引言把 S1 作为图算法在 Web mining 中有现实用途的例子；九项 GrAlgoBench 任务不含 LCM。 | 背景引用；没有提出 LCM 算法。 |
| [A Survey on Algorithmic Interventions in Opinion Dynamics, 2026](https://arxiv.org/abs/2603.10756) | §5.2 把 S1 与 HERMES 一并列作“删边降低特定节点可见性”的邻近工作。 | 综述入口；没有新的 LCM 方法或保证。 |

OpenAlex 一度返回三条记录，是同一 ICDM 论文的 article/conference-paper 重复；不能把它计成两篇。聚合页显示的“四次引用”与上述四篇去重作品一致，而正式 DOI 索引只覆盖其中两篇。该差异说明引用数必须附索引和日期，不能直接拿聚合计数做新颖性结论。

本次复查没有找到 2025--2026 年直接覆盖“top-(b+1) 预算精确 profile + 严格预算 singleton 保证 + 实例 min-cut 证书”的工作。这个结论只是一轮有界检索，不能写成“首次”证明。投稿前仍应完成：

1. 在全文截止前再次刷新 Semantic Scholar、OpenAlex、arXiv 和作者主页，检查 2026 年 10 月新条目。
2. 请至少一名熟悉 cardinality-constrained submodular optimization 的研究者审查 singleton 界、profile 特化与 closure 证书是否属于明显已知推论。

因此当前论文措辞采用“we give / we instantiate / we specialize”，不采用“first”或把 nearest-terminal、nested-monomial、conflict graph、Lagrangian closure 声称为原创。

## 9. 最终宽范围更新（2026-09-27）

在完成 S19 全文对照后，又以算法结构而非论文题名为入口检索：
`monotone submodular minimization + minimum-weight matching + cardinality`、
`fixed-cardinality submodular minimization + pairs`、`Minimum k-Union +
matching`、`size-constrained submodular minimization 2025--2026`、
`Local Centrality Minimization 2025--2026`，以及预算失效下的
`k/f+1 nearest terminals` 与 fault-tolerant distance 文献。结果还用 S1 的
精确 DOI、DBLP 作者记录、OpenReview、arXiv 和出版社页面交叉检查。

本轮未确认与以下三项完全相同的公开结果：(i) 用 pair 权重和一个
minimum-value triple 构造固定基数 matching 的 BlockMatch；(ii) 针对只删除
目标入边这一结构、为所有 `|D|<=b` 同时精确保留每个源节点前 `b+1` 个候选；
(iii) 该 profile 上把基数命中的 Lagrangian closure cut 重构成精确最优性证书。
检索命中了 2026-09-18 的 *Submodular Maximization over Bipartite Perfect
Matchings and Matroid Intersection Bases*，但它是在 matching 可行域上最大化
子模函数，不是以 pair 子模值作为代理来最小化固定大小集合，因而不构成
BlockMatch 的同结果。多故障最短路 oracle 则处理一般边/点失效后的两点距离，
没有利用“失效只发生在进入同一目标的最后一条边”这一 LCM 特化。

这次更新关闭了内部的“最终宽范围查新”动作，但仍不能把有界检索当作新颖性
证明。投稿门槛仍保留一项：由至少一位熟悉基数约束子模最小化的独立研究者
检查 BlockMatch 证明与通用 block-partition 观点，并检查 profile/closure 结果
是否属于应引用的明显推论。论文继续避免 `first`、`novel framework` 和一般
value-oracle 改进等措辞。

## 10. 提交后结构复查（2026-10-01）

在 OpenReview 注册后再次执行精确模型和算法结构检索，查询包括
`"local centrality minimization" harmonic centrality graph 2025 2026`、
`"harmonic centrality" minimization incoming edges target vertex`、
`submodular minimization fixed cardinality pair matching approximation`、
`minimum k-union pair matching approximation submodular`、
`"monotone submodular" "fixed cardinality" minimization approximation` 和
`"minimum-weight matching" submodular minimization pairs`。检索结果逐项回到
一手材料核对，包括 [WWW 2024 作者稿](https://openreview.net/pdf/8688fb9d23132c8b2fe2baa6d960ad8106ee78ad.pdf)、
[Chlamtáč--Dinitz--Makarychev 的 Minimum k-Union 论文](https://arxiv.org/abs/1611.07866)、
[Hochbaum 的 submodular closure/cut 论文](https://arxiv.org/abs/1010.1945)，
以及 [Balcan--Harvey 关于子模函数和值查询下界的论文](https://www.cs.cmu.edu/~ninamf/papers/learning-submodular-2012.pdf)。

本轮没有确认 2026-09-27 以后出现的直接 LCM 算法后续，也没有发现以
`g({u,v})` 为边权、奇数基数先取全局最小 triple、再做固定基数最小权
matching 的同一构造。命中的 Minimum k-Union 和一般基数约束子模最小化
材料仍支持当前边界判断：BlockMatch 必须与通用 MkU 和值查询结果并列讨论，
但不能把现有检索转述为“首次”证明。Hochbaum 的结果也再次说明 closure/cut
框架本身已有先例；本文只能把 Lagrangian network 定位为针对 LCM profile 的
专门实例化和证书机制。

这次复查还没有替代独立专家判断。外部审阅仍需检查：`floor(k/2)` 证明是否为
明显的通用 block-partition 推论、奇数情形选定 triple 后的可行 matching 论证，
以及当前引用是否覆盖该观点最接近的已发表来源。

## 11. 全参考文献与最新相邻工作复核（2026-10-04）

对稿件引用的每一条文献重新核对作者、题名、载体、年份、卷期、页码或
文章号及 DOI/稳定页面。12 条 DOI 记录与 Crossref 和出版社元数据一致；
Har-Peled 的条目与 arXiv `1607.07818` 一致，Iyer--Jegelka--Bilmes 的条目
与 PMLR 28(3):855--863 一致，Bienstock--Zuckerberg 的 2009 技术稿与作者
公开 PDF 及 Optimization Online 记录一致。核验发现并修正一处实质书目
错误：Boland 等人论文的第三位作者是 **Christopher Fricke**，不是
“Christoph Fricke”。同时补齐 Tatti 的正式卷名、Iyer 的 PMLR 卷信息，
以及 Guo、Veremyev 和两篇 Waniek 论文中原先遗漏的 DOI。

本轮还确认了 Marcin Waniek 的 *Sybil Attacks on Centrality Measures*，
正式发表于 WWW 2026，页 3311--3322，DOI
`10.1145/3774904.3792561`。该文通过 Sybil 身份重构降低被测中心性，属于
相邻的中心性规避模型，不允许把它写成同一 LCM 入边删除问题；稿件已在
相关工作中以这一边界加入。精确模型、`BlockMatch` 结构和 2024 前作的
2025--2026 直接后续检索仍未确认同一算法结果。这仍是截至本日的一轮有界
检索，不能替代独立专家的新颖性判断，也不支持 “first” 表述。

## 12. October 15 update

See `REFERENCE_AUDIT_2026-10-15.md` for the 12 added primary-source records,
21 fresh DOI metadata checks, recent model comparison, and MUB/curvature
positioning correction. The paper now explicitly treats SingletonSort as an
MUB specialization and proves its LCM marginal-floor refinement separately.
