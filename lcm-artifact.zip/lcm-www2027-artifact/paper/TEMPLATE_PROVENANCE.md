# ACM template provenance

The working submission is pinned to the production `acmart` package published
by CTAN, version **2.20 (2026-08-16)**, retrieved on 2026-09-26 from:

`https://mirrors.ctan.org/macros/latex/contrib/acmart.zip`

SHA256 values:

- downloaded CTAN archive:
  `93933ce58fbeffa13e23398bb523fcb68275ecc73369c6bc73b421eeef2c10de`
- generated `acmart.cls`:
  `784c4f2fb07a70d8a797ee9d1c63f441c10fbd2f915c9c615d28cda35c0b742a`
- `ACM-Reference-Format.bst`:
  `4342d27456645567ef1a027f6474e894715bc31d468f040142fa54540440ad04`

`acmart.cls` was generated without modification from the included
`acmart-source/acmart.dtx` using `acmart-source/acmart.ins`. The source files
are retained with the generated class to comply with the package's LPPL
distribution notice. The class and bibliography style remain upstream ACM
template files; research-project source files do not inherit their authorship.

The pinned copy makes local and artifact builds reproducible. Immediately
before submission, compare it with the version linked by the WWW 2027 CFP and
rerun the PDF and visual audits if the official version has changed.
