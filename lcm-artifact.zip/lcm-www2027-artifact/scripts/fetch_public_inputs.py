"""Fetch or verify public graph inputs without redistributing raw datasets."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import shutil
import subprocess
import tarfile
import tempfile
import urllib.parse
import urllib.request
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[1]
MANIFEST_DIR = ROOT / "data/manifests"
CORE_DATASETS = (
    "moreno-blogs", "librec-ciaodvd-trust",
    "dimacs10-polblogs", "munmun-twitter-social",
)
SCALABILITY_DATASETS = (
    "citeseer", "youtube-links", "higgs-twitter-social",
    "soc-pokec-relationships",
)


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify(path, expected, description):
    if not path.exists():
        raise FileNotFoundError(f"missing {description}: {path}")
    actual = sha256(path)
    if actual != expected:
        raise RuntimeError(
            f"{description} hash mismatch: {actual} != {expected} ({path})"
        )
    print(f"verified {description}: {path.relative_to(ROOT)}")


def verify_konect_statistics(path, manifest):
    """Verify declared record/self-loop/simple-graph statistics in one pass."""
    if "raw_noncomment_records" not in manifest:
        return None
    records = 0
    self_loops = 0
    raw_nodes = set()
    nonloop_nodes = set()
    with path.open("rb") as handle:
        for line_number, line in enumerate(handle, 1):
            stripped = line.strip()
            if not stripped or stripped.startswith((b"%", b"#")):
                continue
            fields = stripped.split()
            if len(fields) < 2:
                raise RuntimeError(
                    "%s:%d: expected at least two columns" % (path, line_number)
                )
            try:
                source = int(fields[0])
                target = int(fields[1])
            except ValueError as error:
                raise RuntimeError(
                    "%s:%d: non-integer endpoint" % (path, line_number)
                ) from error
            records += 1
            raw_nodes.add(source)
            raw_nodes.add(target)
            if source == target:
                self_loops += 1
            else:
                nonloop_nodes.add(source)
                nonloop_nodes.add(target)
    statistics = {
        "raw_noncomment_records": records,
        "removed_self_loops": self_loops,
        "self_loop_only_nodes": len(raw_nodes - nonloop_nodes),
        "simple_edges": records - self_loops,
        "simple_nodes": len(nonloop_nodes),
    }
    expected_simple = manifest["published_simple_directed_statistics"]
    expected = {
        "raw_noncomment_records": manifest["raw_noncomment_records"],
        "removed_self_loops": manifest["removed_self_loops"],
        "self_loop_only_nodes": manifest.get("self_loop_only_nodes", 0),
        "simple_edges": expected_simple["edges"],
        "simple_nodes": expected_simple["nodes_with_nonloop_edge_endpoint"],
    }
    if statistics != expected:
        raise RuntimeError(
            "%s statistics mismatch: %s != %s"
            % (manifest["dataset"], statistics, expected)
        )
    print(
        "verified %s statistics: %d records, %d self-loops, %d nodes, %d edges"
        % (
            manifest["dataset"], records, self_loops,
            statistics["simple_nodes"], statistics["simple_edges"],
        )
    )
    return statistics


def download(url, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".partial")
    head = urllib.request.Request(
        url, method="HEAD", headers={"User-Agent": "lcm-artifact/1"})
    try:
        with urllib.request.urlopen(head, timeout=60) as response:
            size = int(response.headers.get("Content-Length", "0"))
            ranges = response.headers.get("Accept-Ranges", "").lower() == "bytes"
    except Exception:
        size, ranges = 0, False
    if size >= 16 * 1024 * 1024 and ranges:
        workers = min(8, max(2, (size + 16 * 1024 * 1024 - 1) // (16 * 1024 * 1024)))
        part_dir = path.with_suffix(path.suffix + ".parts")
        part_dir.mkdir(parents=True, exist_ok=True)

        def fetch_part(index):
            start = index * size // workers
            stop = (index + 1) * size // workers - 1
            part = part_dir / ("%02d.part" % index)
            expected = stop - start + 1
            if part.exists() and part.stat().st_size == expected:
                return part
            request = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "lcm-artifact/1",
                    "Range": "bytes=%d-%d" % (start, stop),
                },
            )
            with urllib.request.urlopen(request, timeout=120) as response:
                if response.status != 206:
                    raise RuntimeError("server ignored byte range for %s" % url)
                with part.open("wb") as out:
                    shutil.copyfileobj(response, out)
            if part.stat().st_size != expected:
                raise RuntimeError("short ranged download for %s" % url)
            return part

        with ThreadPoolExecutor(max_workers=workers) as executor:
            parts = list(executor.map(fetch_part, range(workers)))
        with temporary.open("wb") as out:
            for part in parts:
                with part.open("rb") as source:
                    shutil.copyfileobj(source, out)
        if temporary.stat().st_size != size:
            raise RuntimeError("assembled download has wrong size for %s" % url)
        shutil.rmtree(part_dir)
    else:
        request = urllib.request.Request(url, headers={"User-Agent": "lcm-artifact/1"})
        with urllib.request.urlopen(request, timeout=120) as response, temporary.open("wb") as out:
            shutil.copyfileobj(response, out)
    temporary.replace(path)


def safe_extract(archive, destination, expected_root):
    if destination.exists():
        raise FileExistsError(
            f"refusing to replace existing directory: {destination}; remove it explicitly"
        )
    with tempfile.TemporaryDirectory(dir=destination.parent) as temporary_name:
        temporary = Path(temporary_name)
        with tarfile.open(archive, "r:bz2") as handle:
            members = handle.getmembers()
            for member in members:
                name = PurePosixPath(member.name)
                if name.is_absolute() or ".." in name.parts:
                    raise RuntimeError(f"unsafe archive member: {member.name}")
                if member.issym() or member.islnk():
                    raise RuntimeError(f"archive links are not accepted: {member.name}")
            handle.extractall(temporary)
        extracted = temporary / expected_root
        if not extracted.is_dir():
            raise RuntimeError(f"archive root {expected_root!r} not found")
        shutil.move(str(extracted), str(destination))


def ensure_archive_dataset(manifest, *, check_only):
    graph = ROOT / manifest["processed_graph"]
    if graph.exists():
        verify(graph, manifest["graph_sha256"], manifest["dataset"] + " graph")
        verify_konect_statistics(graph, manifest)
        return
    if check_only:
        raise FileNotFoundError(graph)
    url = manifest["archive_url"]
    archive = ROOT / "data/downloads" / Path(urllib.parse.urlparse(url).path).name
    if not archive.exists():
        print(f"downloading {url}")
        download(url, archive)
    verify(archive, manifest["archive_sha256"], manifest["dataset"] + " archive")
    expected_root = manifest.get(
        "archive_root", graph.parent.name.replace("-", "_"))
    # dimacs10-polblogs keeps its hyphenated archive root.
    if manifest["dataset"] == "dimacs10-polblogs":
        expected_root = "dimacs10-polblogs"
    safe_extract(archive, graph.parent, expected_root)
    verify(graph, manifest["graph_sha256"], manifest["dataset"] + " graph")
    verify_konect_statistics(graph, manifest)


def ensure_ciaodvd(manifest, *, check_only):
    graph = ROOT / manifest["graph_path"]
    if not graph.exists():
        if check_only:
            raise FileNotFoundError(graph)
        print(f"downloading {manifest['local_source_url']}")
        download(manifest["local_source_url"], graph)
    verify(graph, manifest["graph_sha256"], manifest["dataset"] + " graph")


def ensure_moreno(manifest, *, check_only):
    checkout = ROOT / "external/Local-Centrality-Minimization"
    if not checkout.exists():
        if check_only:
            raise FileNotFoundError(checkout)
        checkout.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            ["git", "clone", manifest["source_repository"], str(checkout)], check=True
        )
        subprocess.run(
            ["git", "checkout", manifest["source_commit"]], cwd=checkout, check=True
        )
    head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=checkout, text=True
    ).strip()
    if head != manifest["source_commit"]:
        raise RuntimeError(f"Moreno checkout is at {head}, expected {manifest['source_commit']}")
    verify(ROOT / manifest["graph_path"], manifest["graph_sha256"], "moreno graph")
    verify(ROOT / manifest["targets_path"], manifest["targets_sha256"], "moreno targets")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset", action="append",
        choices=CORE_DATASETS + SCALABILITY_DATASETS,
        help="dataset to fetch; repeat as needed (default: four core datasets)",
    )
    parser.add_argument(
        "--include-scalability", action="store_true",
        help="also fetch the four preregistered million-scale datasets",
    )
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args(argv)
    if args.dataset:
        selected = args.dataset
    else:
        selected = list(CORE_DATASETS)
        if args.include_scalability:
            selected.extend(SCALABILITY_DATASETS)
    for dataset in selected:
        manifest = json.loads((MANIFEST_DIR / f"{dataset}.json").read_text())
        if dataset == "moreno-blogs":
            ensure_moreno(manifest, check_only=args.check_only)
        elif dataset == "librec-ciaodvd-trust":
            ensure_ciaodvd(manifest, check_only=args.check_only)
        else:
            ensure_archive_dataset(manifest, check_only=args.check_only)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
