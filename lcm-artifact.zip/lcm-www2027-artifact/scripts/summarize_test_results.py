"""Summarize hash-matched frozen tests and generate the paper's main table."""
import argparse
import hashlib
import json
import random
import statistics
from collections import defaultdict
from pathlib import Path


DETERMINISTIC_BASELINES = (
    "algorithm1", "degree", "greedy", "singleton_sort",
    "parametric_repair", "multi_start_one_swap", "overlap_search",
)
TOLERANCE = 1e-10


def fmt(value, digits=4):
    return "—" if value is None else ("%%.%df" % digits) % value


def percentile(sorted_values, probability):
    if not sorted_values:
        return None
    position = probability * (len(sorted_values) - 1)
    low = int(position)
    high = min(low + 1, len(sorted_values) - 1)
    weight = position - low
    return sorted_values[low] * (1.0 - weight) + sorted_values[high] * weight


def bootstrap_mean_ci(values, *, seed, repetitions=5000):
    """Paired target bootstrap CI; one value corresponds to one target cell."""
    if not values:
        return None, None
    if len(values) == 1:
        return values[0], values[0]
    rng = random.Random(seed)
    n = len(values)
    estimates = sorted(
        statistics.mean(values[rng.randrange(n)] for _ in range(n))
        for _ in range(repetitions)
    )
    return percentile(estimates, 0.025), percentile(estimates, 0.975)


def load_frozen_design(protocol_path):
    protocol = json.loads(protocol_path.read_text())
    root = protocol_path.resolve().parents[1]
    suite_configs = {}
    expected_cell_keys = set()
    for relative in protocol["test_configs"]:
        config_path = root / relative
        data = config_path.read_bytes()
        actual_hash = hashlib.sha256(data).hexdigest()
        expected_hash = protocol["test_config_sha256"][relative]
        if actual_hash != expected_hash:
            raise RuntimeError(
                "frozen config hash mismatch for %s: %s != %s" % (
                    relative, actual_hash, expected_hash
                )
            )
        config = json.loads(data)
        config["config_hash"] = expected_hash
        suite_configs[config["name"]] = config
        for target in config["target_indices"]:
            for ratio in config["budget_ratios"]:
                expected_cell_keys.add((config["name"], target, ratio))
    return protocol, suite_configs, expected_cell_keys


def read_frozen_rows(paths, protocol, suite_configs):
    rows = []
    for path in paths:
        if not path.exists():
            continue
        rows.extend(
            json.loads(line) for line in path.read_text().splitlines()
            if line.strip()
        )
    frozen = []
    for row in rows:
        config = suite_configs.get(row.get("suite"))
        if config is None:
            continue
        if (row.get("implementation_hash") == protocol["implementation_hash"]
                and row.get("runner_version") == protocol["runner_version"]
                and row.get("config_hash") == config["config_hash"]):
            frozen.append(row)
    latest = {}
    for row in frozen:
        key = (
            row.get("suite"), row.get("graph_sha256"),
            row.get("target_index"), row.get("budget"),
            row.get("method"), row.get("trial"),
        )
        latest[key] = row
    return list(latest.values())


def build_cells(rows, suite_configs):
    errors = [row for row in rows if row.get("status") != "ok"]
    groups = defaultdict(list)
    for row in rows:
        if row.get("status") == "ok":
            groups[(
                row["suite"], row["graph_sha256"], row["n"], row["m"],
                row["target_index"], row["budget_ratio"], row["budget"],
            )].append(row)

    cells = []
    partial = []
    for key, group in groups.items():
        suite = key[0]
        config = suite_configs[suite]
        deterministic = {
            row["method"]: row for row in group if row.get("trial") is None
        }
        random_rows = [row for row in group if row["method"] == "random"]
        missing = [name for name in config["methods"] if name not in deterministic]
        expected_random = config.get("random_trials", 0)
        if missing or len(random_rows) != expected_random:
            partial.append({
                "suite": suite,
                "target_index": key[4],
                "budget_ratio": key[5],
                "missing_methods": missing,
                "random_rows": len(random_rows),
                "expected_random_rows": expected_random,
            })
            continue

        hybrid = deterministic["certified_hybrid"]
        available = [deterministic[name] for name in DETERMINISTIC_BASELINES]
        baseline = min(
            available,
            key=lambda row: (row["objective_exact"], row["method"]),
        )
        objective = hybrid["objective_exact"]
        baseline_objective = baseline["objective_exact"]
        if objective > baseline_objective + TOLERANCE * max(1.0, baseline_objective):
            raise RuntimeError(
                "fallback dominance violated in %s target %s ratio %s" % (
                    suite, key[4], key[5]
                )
            )

        pipeline_dependencies = (
            "algorithm1", "greedy", "singleton_sort", "parametric_repair",
            "overlap_search",
        )
        pipeline_seconds = hybrid["solve_seconds"] + hybrid["profile_seconds"]
        for name in pipeline_dependencies:
            pipeline_seconds += deterministic[name]["solve_seconds"]
        lower_bound = hybrid.get("diagnostics", {}).get("certified_lower_bound")
        if (lower_bound is not None
                and lower_bound > objective + TOLERANCE * max(1.0, objective)):
            raise RuntimeError(
                "certificate exceeds feasible objective in %s target %s ratio %s" % (
                    suite, key[4], key[5]
                )
            )
        cells.append({
            "suite": suite, "graph_sha256": key[1], "n": key[2], "m": key[3],
            "target_index": key[4], "budget_ratio": key[5], "budget": key[6],
            "hybrid": objective,
            "baseline": baseline_objective,
            "baseline_method": baseline["method"],
            "absolute_improvement": baseline_objective - objective,
            "relative_improvement": (
                (baseline_objective - objective) / baseline_objective
                if baseline_objective else 0.0
            ),
            "hybrid_incremental_seconds": hybrid["solve_seconds"],
            "hybrid_pipeline_seconds": pipeline_seconds,
            "profile_seconds": hybrid["profile_seconds"],
            "peak_process_rss_bytes": hybrid["peak_process_rss_bytes"],
            "random_median": statistics.median(
                row["objective_exact"] for row in random_rows
            ) if random_rows else None,
            "certificate_lower_bound": lower_bound,
            "selected_component": hybrid.get("diagnostics", {}).get(
                "selected_component"
            ),
            "component_objectives": {
                name: deterministic[name]["objective_exact"]
                for name in (*DETERMINISTIC_BASELINES, "certified_hybrid")
            },
        })
    return cells, partial, errors


def summarize_group(group, seed):
    relative = [cell["relative_improvement"] for cell in group]
    wins = sum(value > TOLERANCE for value in relative)
    losses = sum(value < -TOLERANCE for value in relative)
    ties = len(relative) - wins - losses
    gaps = []
    for cell in group:
        lower = cell["certificate_lower_bound"]
        if lower is not None and cell["hybrid"]:
            gaps.append(max(0.0, (cell["hybrid"] - lower) / cell["hybrid"]))
    ci_low, ci_high = bootstrap_mean_ci(relative, seed=seed)
    return {
        "wins": wins, "ties": ties, "losses": losses,
        "median_relative": statistics.median(relative),
        "mean_relative": statistics.mean(relative),
        "mean_ci_low": ci_low, "mean_ci_high": ci_high,
        "worst_relative": min(relative),
        "best_relative": max(relative),
        "median_gap": statistics.median(gaps) if gaps else None,
        "median_pipeline_seconds": statistics.median(
            cell["hybrid_pipeline_seconds"] for cell in group
        ),
        "peak_rss_mib": max(
            cell["peak_process_rss_bytes"] for cell in group
        ) / 2**20,
    }


def write_latex(path, cells, expected_count):
    path.parent.mkdir(parents=True, exist_ok=True)
    slash = chr(92)
    row_end = slash * 2
    percent = slash + "%"
    if len(cells) != expected_count:
        lines = [
            slash + "begingroup",
            slash + "scriptsize",
            slash + "setlength{" + slash + "tabcolsep}{3pt}",
            slash + "begin{tabular}{lrrrrr}",
            slash + "toprule",
            "Dataset & Cells & W/T/L & Mean gain & Best gain & Median gap "
            + row_end,
            slash + "midrule",
            (slash + "multicolumn{6}{c}{Frozen experiment incomplete: %d/%d cells} "
             + row_end) % (len(cells), expected_count),
            slash + "bottomrule",
            slash + "end{tabular}",
            slash + "endgroup",
        ]
        path.write_text("\n".join(lines) + "\n")
        return
    by_suite = defaultdict(list)
    for cell in cells:
        by_suite[cell["suite"]].append(cell)
    display_names = {
        "test-ciaodvd": "CiaoDVD",
        "test-moreno": "Moreno",
        "test-polblogs": "PolBlogs",
        "test-twitter": "Twitter",
    }
    lines = [
        slash + "begingroup",
        slash + "scriptsize",
        slash + "setlength{" + slash + "tabcolsep}{3pt}",
        slash + "begin{tabular}{lrrrrr}",
        slash + "toprule",
        "Dataset & Cells & W/T/L & Mean gain & Best gain & Median gap "
        + row_end,
        slash + "midrule",
    ]
    for index, suite in enumerate(sorted(by_suite)):
        group = by_suite[suite]
        stats = summarize_group(group, 27000 + index)
        label = display_names.get(suite, suite).replace("_", slash + "_")
        lines.append(
            ("%s & %d & %d/%d/%d & %.3f%s & %.3f%s & %.2f%s " % (
                label, len(group), stats["wins"], stats["ties"], stats["losses"],
                100.0 * stats["mean_relative"], percent,
                100.0 * stats["best_relative"], percent,
                100.0 * stats["median_gap"], percent,
            )) + row_end
        )
    lines += [slash + "bottomrule", slash + "end{tabular}", slash + "endgroup"]
    path.write_text("\n".join(lines) + "\n")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite", type=Path, action="append", required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--latex-output", type=Path)
    args = parser.parse_args(argv)

    protocol, suite_configs, expected_keys = load_frozen_design(args.protocol)
    rows = read_frozen_rows(args.suite, protocol, suite_configs)
    cells, partial, errors = build_cells(rows, suite_configs)
    complete_keys = {
        (cell["suite"], cell["target_index"], cell["budget_ratio"])
        for cell in cells
    }
    unexpected = complete_keys - expected_keys
    if unexpected:
        raise RuntimeError("unexpected frozen cells: %r" % sorted(unexpected))
    missing_count = len(expected_keys - complete_keys)

    by_dataset_ratio = defaultdict(list)
    for cell in cells:
        by_dataset_ratio[(
            cell["suite"], cell["n"], cell["m"], cell["budget_ratio"]
        )].append(cell)
    lines = [
        "# Frozen Test Results",
        "",
        "Protocol: `%s`; implementation hash `%s`; runner `%s`." % (
            args.protocol, protocol["implementation_hash"],
            protocol["runner_version"],
        ),
        "",
        "Complete cells: %d/%d. Missing or partial cells: %d. "
        "Logged error records: %d." % (
            len(cells), len(expected_keys), missing_count, len(errors)
        ),
        "",
        "| Dataset | n/m | b/d | Targets | Wins / ties / losses | Median gain | Mean gain [95% target-bootstrap CI] | Best gain | Worst gain | Median certified gap | Median pipeline sec | Peak RSS MiB |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for index, key in enumerate(sorted(by_dataset_ratio)):
        suite, n, m, ratio = key
        group = by_dataset_ratio[key]
        stats = summarize_group(group, seed=202700 + index)
        lines.append(
            "| %s | %d/%d | %.2f | %d | %d/%d/%d | %s%% | %s%% [%s%%, %s%%] | %s%% | %s%% | %s%% | %s | %s |" % (
                suite, n, m, ratio, len(group),
                stats["wins"], stats["ties"], stats["losses"],
                fmt(100.0 * stats["median_relative"], 4),
                fmt(100.0 * stats["mean_relative"], 4),
                fmt(100.0 * stats["mean_ci_low"], 4),
                fmt(100.0 * stats["mean_ci_high"], 4),
                fmt(100.0 * stats["best_relative"], 4),
                fmt(100.0 * stats["worst_relative"], 4),
                fmt(100.0 * stats["median_gap"], 2),
                fmt(stats["median_pipeline_seconds"], 2),
                fmt(stats["peak_rss_mib"], 1),
            )
        )
    if cells:
        relative = [cell["relative_improvement"] for cell in cells]
        selected = defaultdict(int)
        strongest = defaultdict(int)
        for cell in cells:
            selected[cell["selected_component"] or "unrecorded"] += 1
            strongest[cell["baseline_method"]] += 1
        positive = [value for value in relative if value > TOLERANCE]
        lines += [
            "",
            "Across complete cells: %d strict wins, %d ties, %d losses; median paired relative gain %s%% and mean %s%%. Among strict wins, the median gain was %s%% and the maximum was %s%%." % (
                sum(value > TOLERANCE for value in relative),
                sum(abs(value) <= TOLERANCE for value in relative),
                sum(value < -TOLERANCE for value in relative),
                fmt(100.0 * statistics.median(relative), 4),
                fmt(100.0 * statistics.mean(relative), 4),
                fmt(100.0 * statistics.median(positive), 4) if positive else "—",
                fmt(100.0 * max(positive), 4) if positive else "—",
            ),
            "",
            "Strongest baseline frequency: %s." % ", ".join(
                "%s=%d" % item for item in sorted(strongest.items())
            ),
            "",
            "Selected final components: %s." % ", ".join(
                "%s=%d" % item for item in sorted(selected.items())
            ),
            "",
            "Pipeline time includes profile construction plus A1, Greedy, singleton, parametric repair, overlap search, and hybrid polishing because those components are required by the frozen candidate. Graph load time is reported in raw records and is not multiplied into each cell.",
        ]
        lines += [
            "",
            "## Pairwise component comparisons",
            "",
            "| Comparator | Wins / ties / losses | Median improvement | Mean improvement | Maximum improvement |",
            "|---|---:|---:|---:|---:|",
        ]
        for method in DETERMINISTIC_BASELINES:
            values = []
            for cell in cells:
                comparator = cell["component_objectives"][method]
                values.append(
                    (comparator - cell["hybrid"]) / comparator
                    if comparator else 0.0
                )
            wins = sum(value > TOLERANCE for value in values)
            losses = sum(value < -TOLERANCE for value in values)
            ties = len(values) - wins - losses
            lines.append(
                "| %s | %d/%d/%d | %s%% | %s%% | %s%% |" % (
                    method, wins, ties, losses,
                    fmt(100.0 * statistics.median(values), 3),
                    fmt(100.0 * statistics.mean(values), 3),
                    fmt(100.0 * max(values), 3),
                )
            )
    if partial:
        lines += ["", "## Incomplete cells", ""]
        for cell in sorted(
                partial, key=lambda item: (
                    item["suite"], item["target_index"], item["budget_ratio"]
                )):
            lines.append(
                "- %s target %s ratio %s: missing deterministic %s; random %d/%d" % (
                    cell["suite"], cell["target_index"], cell["budget_ratio"],
                    cell["missing_methods"], cell["random_rows"],
                    cell["expected_random_rows"],
                )
            )
    if errors:
        lines += ["", "## Errors", ""]
        for row in errors:
            lines.append("- %s target %s budget %s method %s: `%s`" % (
                row.get("suite"), row.get("target_index"), row.get("budget"),
                row.get("method"), row.get("error"),
            ))

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n")
    if args.latex_output:
        write_latex(args.latex_output, cells, len(expected_keys))
    print(args.output)


if __name__ == "__main__":
    main()
