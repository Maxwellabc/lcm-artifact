# Research status

Last updated: 2026-10-15 Asia/Shanghai.

## October 15 local revision

- Added 12 verified references (27 cited works total) and an explicit model/novelty map.
- Proved the marginal-floor affine bound and refined LCM universal envelopes.
- Checked 49,152 coverage and 1,293 directed-graph cells with integer arithmetic.
- Exported and independently reverified the historical 48-cell low-degree study:
  BlockMatch is optimal in 47/48; overlap search in 48/48; the failure is reported.
- Added an exact integer blossom backend and two meaningful regression tests.
- Current paper is eight main pages, twelve total; new material is local only.

## Completed

- Audited and fixed the WWW 2024 author snapshot at commit
  `7d2ecb21f1d0f33fe44255171ece10a2a9fbabaa`; the upstream directory remains
  unmodified.
- Implemented and tested the exact top-`b+1` budget profile, an independent
  original-graph BFS oracle, strict-budget baselines, exact one-swap and
  prefix exchange, parametric min-cut repair, conservative integer lower
  bounds, and exact rational cardinality-hit certificates.
- Proved and exhaustively checked a singleton strict-budget guarantee of
  `min{k, h_G(v)/k} <= sqrt(h_G(v))`; the final hybrid inherits it by retaining
  and monotonically improving the singleton start.
- Derived BlockMatch, a polynomial pair/one-triple partition algorithm that is
  exact for `k<=3` and improves the LCM guarantee to
  `min{floor(k/2), h_G(v)/k} <= sqrt(h_G(v)/2)` for `k>=2`. Its cardinality
  branch is asymptotically tight on DAGs. A post-freeze independent reference
  program passed every cardinality of all 262,144 ordered six-set systems over
  a three-element universe (3,145,728 ordinary-plus-LCM audit cells), 1,476
  random weighted-coverage cells, 248 random LCM cells, and explicit tight
  families for `k=4,5,6,7`; the separate polynomial blossom implementation
  agrees with the reference on 120 further cells.
- Verified the profile/oracle equality and certificate validity by exhaustive
  and randomized small-graph tests.  The current suite has 11 passing tests,
  including compact-graph cross-checks for contiguous and gapped labels.
- Ran the development matrix on Moreno, CiaoDVD, Political Blogs, and Twitter.
  The hybrid improved the strongest component in 8 of 15 development cells
  before the fallback revision; three Moreno cells received exact optimality
  certificates.
- Audited LP levels L0--L4 on small instances.  Pair conflicts can strengthen
  independent source relaxations, but general conflict/clique and closure
  Lagrangian ideas have direct prior art and are not claimed as new.
- Frozen four strict-search data manifests, target files, algorithm parameters, code hash,
  runner version, and configuration hashes.  Every measured feasible solution
  is independently recomputed on the original graph.
- Revised and rendered an anonymous ACM paper under `paper/` with eight main
  pages and twelve pages total. It now includes a vector problem diagram,
  standard algorithm floats, a theory comparison table, complementary result
  views, graph--budget detail, resource tradeoffs, and complete appendix proofs.
- Completed all 198 revised blind target--budget cells with zero errors. The
  hybrid beats WWW 2024 A1 in 197 cells (2.985% median improvement), while its
  incremental gain over the strongest adapted component is small: 22 wins,
  176 ties, and 0 losses (0.012% mean improvement).
- Measured the exact-profile construction boundary. At quarter budgets the
  compressed profile cuts stored labels by about 72--74% and traced peak by
  about 51--53%; at three-quarter budgets the current Python multi-label
  implementation is slower and can use more memory than repeated BFS.
- Added a reproducible synthetic set-system graph family where prefix exchange
  escapes a 1-swap local optimum, reaches exhaustive OPT, and approaches a
  1/27 relative improvement over the local solution.
- Completed exact rational reconstruction on all 198 frozen cells. Nine cuts
  have exactly the required cardinality and therefore prove global optimality;
  the frozen hybrid matches all nine proved optima.
- Added a non-redistributing dataset acquisition policy and a fetch/check
  script for all eight public graph hashes.  For CiteSeer, YouTube, Higgs, and
  Pokec it also verifies raw records, removed self-loops, self-loop-only
  labels, and the published simple node/edge counts.
- Exhaustively enumerated all 4,096 directed simple graphs on four vertices:
  55,296 feasible deletion sets match the profile/oracle calculation, and
  98,304 rational Lagrangian checks satisfy the lower-bound and exact-hit
  conditions under the frozen implementation hash.
- Added a deterministic release builder with a file-level SHA256 manifest. Its
  candidate archive excludes raw inputs, downloaded archives, the upstream
  snapshot, virtual environments, caches, and prior distribution outputs.
- The deterministic release records all selected payloads in its file manifest and redacts
  absolute checkout prefixes only in four packaged historical traceback logs
  while preserving their source hashes. The adjacent checksum sidecar records
  the archive SHA256 without creating a self-reference inside the package.
- A rebuild from the extracted artifact preserves those original source
  hashes from the verified manifest and is byte-identical to the source
  archive.  Deterministic structure-validation evidence excludes wall time;
  elapsed time remains available on stdout.
- The builder reads private identity/linkage markers from an excluded
  private file and rejects any selected payload containing one. Positive and
  forced-negative checks verify that the scan runs without changing archive
  bytes or publishing the markers.
- Extracted that archive into a fresh directory, reacquired all public inputs,
  created a new Python environment from the lock file, and passed all 11 tests
  plus the full artifact audit; the machine-readable record is
  `results/RELEASE_SMOKE_AUDIT.json`.
- Rebuilt and visually inspected all twelve pages with the production CTAN
  `acmart` v2.20 class dated 2026-08-16; all fonts are embedded, references
  start on page 9, and the class, bibliography style, LPPL sources, and hashes
  are pinned under `paper/`.
- Added the four larger original-study graphs (CiteSeer, YouTube, Higgs, and
  Pokec) under a separate pre-result protocol.  All 144 method rows completed
  successfully; the 60 sealed pairs give SingletonSort versus A1 6 wins, 52
  ties, and 2 losses, with 0 median and 0.0359% mean relative improvement.
  Peak process RSS was 271.5 MiB and all pilot resource gates passed.
- Added hash-validated ranged downloads, a gapped-label-safe compact reverse
  CSR, deterministic target selection, strict result auditing, and generated
  paper/report tables for the scalability extension.
- Traced all four unique public works citing the WWW 2024 paper as of
  2026-09-26. They are background, adjacent-centrality, benchmark, or survey
  citations rather than direct LCM algorithm follow-ups; the dated,
  source-by-source classification is in `notes/literature-audit.md`.
- Used institutional access to compare BlockMatch line by line with the full
  COCOON 2024 version of Chen et al. and the JCSS 2026 algorithm description.
  Their construction uses marginal-singleton and minimum-density-set greedy
  routines, not pair/triple matching. A final 2026-09-27 structure- and
  citation-based sweep found no identical construction; this remains bounded
  evidence rather than proof of novelty.
- Repeated the structural and exact-model literature sweep on 2026-10-01 using
  the original WWW paper, Minimum k-Union, fixed-cardinality monotone
  submodular minimization, and matching/block-partition queries. No direct LCM
  follow-up or identical BlockMatch construction was confirmed. The search is
  recorded as bounded evidence and leaves the external novelty verdict open.
- Rechecked every one of the 15 bibliography entries on 2026-10-04 against
  Crossref, publisher records, arXiv, PMLR, or the authors' manuscript. Corrected
  Christopher Fricke's given name, completed the non-DOI report and PMLR
  metadata, added the verified WWW 2026 adjacent work, and checked every
  citation in context. No new citation was added in the 2026-10-14 revision;
  all bibliography keys remain cited and no unsupported or fabricated
  reference remains in the current source.
- Completed an adversarial internal cold review. It repaired the `k=1`
  boundary of the DAG tight family, strengthened the pruned multi-label proof,
  clarified exact move evaluation and zero padding, and added ACM CCS,
  keywords, accessibility descriptions, and complete bibliographic metadata.
  The rebuilt seven-page PDF has embedded fonts and no layout/reference
  diagnostics. An external novelty/proof review remains an optional risk check,
  not a WWW submission requirement.
- Repaired a boundary statement in the exact-profile proof on 2026-10-01:
  rows with fewer than `b+1` reachable candidates use zero padding when all
  reachable candidates are deleted. The construction proof now derives its
  tie order from ordered terminal initialization and FIFO layers. The revised
  seven-page anonymous PDF passes compilation, visual, font, metadata, and
  test audits. The revision was submitted to OpenReview on 2026-10-01, and its
  downloaded server PDF was byte-identical to that audited revision.
- Corrected the ACM Reference Format conference metadata so `acmart` no longer
  renders a duplicated “Proceedings of” phrase. Extracted-text comparison
  changes only that reference-format block; the current seven-page anonymous
  PDF again passes compilation, visual, font, metadata, and test audits.
  Authenticated server synchronization is tracked in the excluded private
  receipt rather than asserted by this anonymous status file.
- Registered the substantive manuscript in the WWW 2027 OpenReview long-paper
  venue. Server synchronization and byte-identity evidence for each revision
  are tracked in the excluded `private/` receipt rather than asserted by this
  anonymous status file.
- Prepared a deterministic anonymous independent-review bundle containing the
  exact current audited PDF, source, claim ledger, proof/novelty packet, theory and
  literature audits, computational audit summaries, and the reproduction
  artifact. Its identity-marker and absolute-path scans have zero hits.
- The 2026-10-14 local revision passes 11 tests, the full artifact audit,
  strict 164-file archive manifest verification, eight input-hash checks,
  fresh-extraction source compilation, page-boundary inspection, and
  embedded-font checks. The extraction reused the locked workspace virtual
  environment rather than reinstalling dependencies.
  The revised PDF, canonical abstract, and ordered author metadata were saved
  to the existing OpenReview record after explicit author confirmation on
  2026-10-14. The authenticated server download matches the local PDF byte for
  byte; the server viewer shows ten pages, the conclusion on page 8, references
  beginning on page 9, and the anonymous author label. The saved abstract was
  re-opened and compared character for character with the canonical worksheet.

## Running

No experiment process is running. The declared conflict sensitivity
audit completed all 12 cells: 6 bounds improved, but the median gap reduction
was only 0.050 percentage points for 67.6 seconds median audit time. The module
is therefore an appendix ablation rather than a main contribution.

## Next evidence checks

1. Optionally obtain an independent proof and novelty review as an additional
   risk check; this is not a WWW 2027 submission requirement. Choose an
   artifact license and archival DOI repository only before public artifact
   release, and revalidate the final PDF against the official submission
   template immediately before the final-paper freeze.
   The reviewer questions and dated submission gates are frozen in
   `paper/INDEPENDENT_REVIEW_PACKET.md` and `paper/SUBMISSION_CHECKLIST.md`.
   The reviewer should independently repeat the full-text comparison with
   Chen et al.; the internal comparison used the complete COCOON 2024 version
   and the JCSS 2026 algorithm description.
2. The author identity, OpenReview profile fields, submission identifiers, and
   receipt are checked in excluded private records. Resolve the CFP's
   OpenReview/EasyChair conflict-interface inconsistency and review the
   complete conflict set before the abstract freeze. The CFP has no EasyChair
   link; authenticated author pages expose no control; and official OpenReview
   documentation instead describes organizer-computed conflict edges, so the
   remaining chair question is whether and where authors separately submit
   private conflicts.
