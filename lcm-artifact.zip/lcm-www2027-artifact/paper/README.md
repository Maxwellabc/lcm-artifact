# Paper source

`main.tex` is the rendered evidence-first draft for the WWW 2027 research
track.  Its theorems match the implemented exact profile, SingletonSort,
BlockMatch reference audit, and certificate logic.  General nearest-terminal search, nested-monomial
convexification, closure conflicts, and Lagrangian side-constraint methods are
cited as prior art rather than claimed as new.

BlockMatch was derived after the frozen real-graph experiment. Its proof and
novelty gate are in `notes/block-matching-candidate.md`; the independent
small-instance audit is `scripts/validate_block_matching_candidate.py`, and
the executable polynomial implementation is `blockmatch/algorithm.py`. The
paper does not report BlockMatch as a frozen empirical comparator.

`INTERNAL_COLD_REVIEW.md` records the adversarial internal proof, claim, layout,
and citation check.  It is deliberately separate from
`INDEPENDENT_REVIEW_PACKET.md`, which supports an optional external
novelty/proof review and is not a WWW submission requirement.

The frozen experiment and exact-certificate audit are complete.  Tables,
bootstrap intervals, and the result figure are generated only from rows whose
implementation, runner, and configuration hashes match
`configs/FROZEN_TEST_PROTOCOL.json`.

The separate million-scale extension is frozen in
`configs/SCALABILITY_EXTENSION_PROTOCOL.json`; its strict audit generates
`generated/scalability_results.tex` from 144 raw rows:

```bash
python3 scripts/summarize_scalability_extension.py \
  --protocol configs/SCALABILITY_EXTENSION_PROTOCOL.json \
  --results results/scalability-extension.jsonl \
  --output-json results/SCALABILITY_EXTENSION_SUMMARY.json \
  --output-markdown results/SCALABILITY_EXTENSION_REPORT.md \
  --latex-output paper/generated/scalability_results.tex
```

Regenerate the paper assets with the bundled plotting runtime, or any Python
environment containing Matplotlib:

```bash
python3 scripts/generate_paper_assets.py \
  --protocol configs/FROZEN_TEST_PROTOCOL.json \
  --suite results/raw/test-moreno.jsonl \
  --suite results/raw/test-ciaodvd.jsonl \
  --suite results/raw/test-polblogs.jsonl \
  --suite results/raw/test-twitter.jsonl \
  --profile-benchmarks results/profile_benchmarks.jsonl \
  --paper-dir paper
```

If Matplotlib is unavailable, the ReportLab-only companion regenerates the
new comparison tables and figures:

```bash
python3 scripts/generate_extended_paper_assets.py \
  --protocol configs/FROZEN_TEST_PROTOCOL.json \
  --suite results/raw/test-moreno.jsonl \
  --suite results/raw/test-ciaodvd.jsonl \
  --suite results/raw/test-polblogs.jsonl \
  --suite results/raw/test-twitter.jsonl \
  --profile-benchmarks results/profile_benchmarks.jsonl \
  --paper-dir paper
```

Compile the ACM review PDF from this directory:

```bash
tectonic --keep-logs --keep-intermediates main.tex
```

The directory pins the production CTAN `acmart` v2.20 class and ACM reference
style; hashes and retained LPPL source files are documented in
`TEMPLATE_PROVENANCE.md`. The current `main.pdf` has eight main pages and twelve
pages total, with references starting on page 9. It was rebuilt under that
class on 2026-10-15. The official CFP allows 8 main pages and 12 total pages,
requires double-blind review, and requires explicit Web relevance on page 1.
Re-check those rules and the proceedings metadata before submission.

The October 15 revision adds the marginal-floor theorem, 27 verified references,
and a separately labeled 48-cell low-degree exact-optimum comparison.
`notes/REFERENCE_AUDIT_2026-10-15.md` records citation sources and limits.
The full proof is in the appendix; `blockmatch/exact.py` supplies exact integer
blossom weights without altering the frozen `lcm` or historical float backend.
See `ARTIFACT_README.md` for supplement and figure regeneration commands.
This is a local revision; earlier authenticated submission receipts are historical.
