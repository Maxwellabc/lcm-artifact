"""Run L1 and separated pair-cut LPs on selected real-graph instances."""
import argparse
import json
import sys
from pathlib import Path
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lcm.graph import load_author_targets, load_edgelist  # noqa: E402
from lcm.lp import solve_prefix_relaxation, solve_prefix_with_pair_cuts  # noqa: E402
from lcm.profile import build_budget_profile  # noqa: E402


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--graph", type=Path, required=True)
    parser.add_argument("--targets-file", type=Path, required=True)
    parser.add_argument("--target-indices", default="0,1")
    parser.add_argument("--budget-ratios", default="0.25,0.5,0.75")
    parser.add_argument("--cut-rounds", type=int, default=10)
    parser.add_argument("--cuts-per-round", type=int, default=200)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    graph = load_edgelist(args.graph)
    targets = load_author_targets(args.targets_file)
    indices = [int(value) for value in args.target_indices.split(",")]
    ratios = [float(value) for value in args.budget_ratios.split(",")]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as handle:
        for target_index in indices:
            target = targets[target_index]
            d = graph.indegree(target)
            for ratio in ratios:
                budget = int(d * ratio)
                profile_started = perf_counter()
                profile = build_budget_profile(graph, target, budget)
                profile_seconds = perf_counter() - profile_started
                l1 = solve_prefix_relaxation(profile, budget)
                pair = solve_prefix_with_pair_cuts(
                    profile, budget, max_rounds=args.cut_rounds,
                    max_cuts_per_round=args.cuts_per_round,
                )
                record = {
                    "target_index": target_index,
                    "target_internal_id": target,
                    "indegree": d,
                    "budget": budget,
                    "budget_ratio": ratio,
                    "profile_seconds": profile_seconds,
                    "l1": l1.__dict__,
                    "pair": pair.__dict__,
                    "improvement": pair.objective - l1.objective,
                }
                handle.write(json.dumps(record, sort_keys=True) + "\n")
                handle.flush()
    print(args.output)


if __name__ == "__main__":
    main()
