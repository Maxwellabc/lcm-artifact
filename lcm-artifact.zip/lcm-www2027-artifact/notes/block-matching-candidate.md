# BlockMatch candidate: proof and prior-art comparison

Date: 2026-09-26; evidence and prior-art comparison updated 2026-10-01. This note records a
candidate theorem discovered after the frozen experiment. It is now a paper
claim backed by an executable audit, but its proof and novelty should still be
independently reviewed.

Let `g` be a normalized, nonnegative, monotone submodular function on a ground
set of `d` candidates. LCM has

    g(R) = sum_s max_{u in R} a_su,

and seeks a retained set of exactly `k=d-b` candidates. For `k>=2`, partition
a size-`k` set into pairs when `k` is even, and into one triple plus pairs when
`k` is odd. Give every block `B` weight `g(B)`.

**Candidate algorithm (BlockMatch).** For even `k`, compute a minimum-weight matching of
cardinality `k/2` in the complete candidate graph with edge weight
`g({u,v})`. For odd `k`, first choose a global minimum-value triple `T`, then
compute one minimum-weight matching of cardinality `(k-3)/2` outside `T`.
The cases `k=1,2,3` are exact by singleton, pair, or triple minimization.
Fixed-cardinality minimum-weight matching is polynomial, so the whole
algorithm is polynomial in the value-oracle model. It makes one blossom call
and at most `binom(d,2)+binom(d,3)+1` distinct oracle calls. The direct
implementation is intended for small/medium degree because forming all triple
values is expensive.

Let the chosen blocks be `B_1,...,B_q`, where `q=floor(k/2)`. Normalized
submodularity implies subadditivity, hence

    g(union_i B_i) <= sum_i g(B_i).

For even `k`, partition an optimum `R*` into pairs. The minimum matching is no
larger than that partition's surrogate, and monotonicity gives
`g(B_i)<=g(R*)` for each pair. For odd `k`, the chosen minimum triple has value
at most that of any triple in `R*`, hence at most `OPT`. At most three optimum
elements lie in the chosen triple, so at least `k-3` elements of `R*` remain
outside it. They contain a feasible `(k-3)/2`-pair matching, each of whose
pairs costs at most `OPT`. Thus in both parities the returned surrogate, and
hence its objective, is at most `q OPT`. The result is exact for `k<=3` and is
a `floor(k/2)` approximation for `k>=4`.

For LCM, every retained in-neighbor contributes one as its own source, so
`OPT>=k`; monotonicity also gives `g(R)<=g(U)=h_G(v)`. The instance ratio is
therefore at most

    min{floor(k/2), h_G(v)/k} <= sqrt(h_G(v)/2),  k>=2.

The last inequality follows because `floor(k/2)/k<=1/2`. This is a factor-two
improvement over the WWW 2024 squared bound and a factor-`sqrt(2)` improvement
over SingletonSort's `sqrt(h_G(v))` bound, at a much higher polynomial cost.

The `floor(k/2)` analysis is asymptotically tight for this surrogate even on
DAGs. Split `2k` candidates into `A` and `B`. Partition `A` into pairs, plus
one triple if `k` is odd. Give each `A` block `M` private sources adjacent to
every member of that block, and give all `B` candidates `M+1` common sources.
All candidates point to the target. Each designated `A` block has surrogate
weight just below the corresponding `B` block, so the algorithm retains all
of `A`; its objective tends to `floor(k/2)` times the all-`B` optimum as
`M` grows. The reference audit constructs these graphs for `k=4,5,6,7`.

## Prior-art boundary

Chen, Chen, Ye, and Zhang, *Approximation Algorithms for Two Extensions of
Min-k-Union*, JCSS 157 (2026), DOI `10.1016/j.jcss.2025.103750`, gives a
`2 sqrt(d)` approximation for arbitrary nonnegative monotone submodular
minimization with a size-`k` constraint. On 2026-09-27, institutional access
allowed a line-by-line check of its complete COCOON 2024 version, *On
Extensions of Min-k-Union* (DOI `10.1007/978-981-96-1090-7_3`), while the JCSS
page confirmed the same algorithmic description. Their construction combines
two greedy routines: minimum-marginal singleton selection gives a
`k`-approximation; for large `k`, repeated minimum-density subset selection is
implemented through unconstrained submodular minimization and then completed
with singleton greedy, yielding `2 sqrt(d)`. The conference version contains
no pair, triple, or fixed-cardinality matching construction. Thus the most
direct known general predecessor is algorithmically distinct from BlockMatch.
The JCSS body remains behind Elsevier institutional authentication, so an
independent expert check remains an optional risk check after the 2026-10-01 broad update.
Minimum k-Union, submodular minimization under cardinality, and value-oracle
lower bounds remain the primary neighborhoods.

Run the independent small-instance reference audit with:

```bash
.venv/bin/python scripts/validate_block_matching_candidate.py
```

The executable polynomial implementation is `blockmatch/algorithm.py`. It
reduces a `q`-edge matching on `n` real vertices to a perfect matching by
adding `n-2q` dummy vertices, connecting real--dummy pairs at zero cost, and
omitting dummy--dummy edges. The audit compares this NetworkX 3.2.1 blossom
implementation against the exponential dynamic program on 120 additional
random coverage/LCM cells. In the odd case both implementations independently
select the global minimum triple before solving the one remaining matching.

The same audit also exhausts every ordered six-set system over a three-element
universe: `8^6 = 262,144` systems and all six positive cardinalities. It checks
1,572,864 ordinary coverage cells and another 1,572,864 LCM-shaped cells formed
by adding one private element per chosen candidate. The checks use integer
inequalities and a separate exhaustive matching enumerator; all SingletonSort,
BlockMatch, exact-`k<=3`, subadditive-surrogate, `h/k`, and square-root claims
passed. This finite audit is a regression and boundary test, not a substitute
for the general proof or an independent review.
