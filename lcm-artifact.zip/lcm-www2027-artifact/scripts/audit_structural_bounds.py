"""Exact integer audit of the marginal-floor refinement; no frozen code edits.

Exhausts all ordered six-set systems on a two-element universe with private
weights 1 and 3, then directed graphs with paths among candidates. Matching is
an independent subset dynamic program (not blossom); every inequality uses
integer arithmetic. Counts are proof checks, not statistical observations.
"""
import hashlib
import json
import math
import random
import sys
from collections import deque
from functools import lru_cache
from itertools import combinations, product
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def popcount(mask):
    return bin(mask).count("1")


def matching_value(values, d, k):
    full = (1 << d) - 1
    @lru_cache(None)
    def pairs(mask, count):
        if count == 0:
            return 0, 0
        if popcount(mask) < 2 * count:
            return None
        first = mask & -mask
        tail = mask ^ first
        options = []
        skipped = pairs(tail, count)
        if skipped is not None:
            options.append(skipped)
        rest = tail
        while rest:
            second = rest & -rest
            rest ^= second
            suffix = pairs(tail ^ second, count - 1)
            if suffix is not None:
                options.append((values[first | second] + suffix[0],
                                first | second | suffix[1]))
        return min(options) if options else None
    if k == 1:
        chosen = min((values[1 << i], 1 << i) for i in range(d))
        return chosen
    if k % 2 == 0:
        return pairs(full, k // 2)
    triple_value, triple = min((values[sum(1 << i for i in c)], sum(1 << i for i in c))
                              for c in combinations(range(d), 3))
    suffix_value, suffix = pairs(full ^ triple, (k - 3) // 2)
    return triple_value + suffix_value, triple | suffix


def audit(values, d, scale, lcm=False):
    full = (1 << d) - 1
    h = values[full]
    mu = min(h - values[full ^ (1 << i)] for i in range(d))
    assert mu >= 0
    if lcm:
        assert 2 * mu >= scale
    records = []
    for k in range(1, d + 1):
        optimum = min(v for mask, v in enumerate(values) if popcount(mask) == k)
        sc_mask = sum(1 << i for _, i in sorted((values[1 << i], i) for i in range(d))[:k])
        surrogate, bm_mask = matching_value(values, d, k)
        assert popcount(bm_mask) == k
        q = max(1, k // 2)
        H = h - mu * (d - k)
        for name, mask, t in [('singleton', sc_mask, k), ('blockmatch', bm_mask, q)]:
            v = values[mask]
            affine = t * optimum - mu * k * (t - 1)
            assert v <= affine, (name, d, k, v, affine)
            assert v <= H
            assert v * (H + mu * k * (t - 1)) <= optimum * t * H
        assert values[bm_mask] <= surrogate
        if k <= 3:
            assert values[bm_mask] == optimum
        if lcm:
            assert optimum >= k * scale
            if k >= 4:
                # q*h/[h+q(q-1)], a rational upper bound on the new envelope.
                assert values[bm_mask] * (h + scale * q * (q - 1)) <= optimum * q * h
        records.append({'k': k, 'mu_numerator': mu, 'scale': scale,
                        'h_numerator': h, 'optimum_numerator': optimum,
                        'singleton_numerator': values[sc_mask],
                        'blockmatch_numerator': values[bm_mask]})
    return records


def coverage_audit():
    count = 0
    for sets in product(range(4), repeat=6):
        coverage = [0] * 64
        for mask in range(1, 64):
            low = mask & -mask
            coverage[mask] = coverage[mask ^ low] | sets[low.bit_length() - 1]
        for weight in (1, 3):
            values = [popcount(mask) * weight + popcount(union)
                      for mask, union in enumerate(coverage)]
            count += len(audit(values, 6, 1))
    return count


def graph_values(n, edges, target):
    incoming = [[] for _ in range(n)]
    candidates = sorted(u for u, w in edges if w == target)
    for u, w in edges:
        if u != target and w != target:
            incoming[w].append(u)
    columns = []
    for u in candidates:
        distance = [-1] * n
        distance[u] = 0
        queue = deque([u])
        while queue:
            w = queue.popleft()
            for p in incoming[w]:
                if distance[p] < 0:
                    distance[p] = distance[w] + 1
                    queue.append(p)
        columns.append([r + 1 if r >= 0 else 0 for r in distance])
    scale = math.lcm(*(x for col in columns for x in col if x))
    weights = [[scale // x if x else 0 for x in col] for col in columns]
    values = [sum(max((weights[i][s] for i in range(len(candidates)) if mask >> i & 1), default=0)
                  for s in range(n)) for mask in range(1 << len(candidates))]
    return values, len(candidates), scale


def main():
    count = coverage_audit()
    print(json.dumps({'coverage_cardinality_cells': count}), flush=True)
    rng = random.Random(20261015)
    graph_count = 240
    graph_cells = 0
    minima = []
    for trial in range(graph_count):
        n = rng.randrange(6, 11)
        target = n - 1
        forced = set(rng.sample(range(target), rng.randrange(4, min(8, target) + 1)))
        probability = (0.15, 0.35, 0.65)[trial % 3]
        edges = {(u, w) for u in range(n) for w in range(n)
                 if u != w and w != target and rng.random() < probability}
        edges.update((u, target) for u in forced)
        values, d, scale = graph_values(n, edges, target)
        records = audit(values, d, scale, lcm=True)
        graph_cells += len(records)
        minima.append(records[0]['mu_numerator'] / scale)
    output = {'status': 'ok', 'coverage_systems': 4096,
              'private_weights': [1, 3], 'coverage_cardinality_cells': count,
              'directed_graphs': graph_count, 'directed_graph_cardinality_cells': graph_cells,
              'directed_graph_mu_min': min(minima), 'directed_graph_mu_max': max(minima),
              'integer_inequalities_only': True,
              'independent_matching': 'subset dynamic program',
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'seed': 20261015}
    path = ROOT / 'results/STRUCTURAL_BOUND_AUDIT.json'
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps(output, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
