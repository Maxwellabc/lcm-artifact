# External requests needed before the final-paper freeze

Status: retained only as an audit trail; **do not send**. The author declined
both the independent-review and COI-interface emails. The drafts below do not
authorize communication.

## 1. Retired full-text request

Do not send this request. On 2026-09-27 the complete COCOON 2024 version became
available through the author's institutional Springer access, and its
algorithm and proof were compared with BlockMatch. The draft below is retained
only as an audit trail.

Public recipient: Hua Chen, corresponding author of *On Extensions of
Min-k-Union* / *Approximation Algorithms for Two Extensions of Min-k-Union*.
The address is listed on the Springer conference-paper page. This short request
does not disclose the new BlockMatch construction.

Subject: Request for a research copy of your min-k-union paper

Dear Dr. Chen,

I am studying cardinality-constrained monotone submodular minimization and
would like to read your paper *Approximation Algorithms for Two Extensions of
Min-k-Union* (JCSS 157, 103750), including its full algorithm and proof. My
institution does not currently provide full-text access. Would you be willing
to share a research copy or point me to an author-hosted version?

Thank you,
[name and affiliation]

## 2. Request an independent theory and novelty review

Subject: Focused proof and novelty review for a WWW 2027 graph-algorithms draft

Dear [reviewer],

Could you independently review the attached anonymous ten-page draft (eight
main pages) and
the accompanying review packet by [date]? A deterministic anonymous bundle is
prepared locally as `dist/lcm-www2027-independent-review-bundle.tar.gz`; verify
its SHA-256 against the adjacent sidecar before review. The highest-priority
questions are:

1. Is the pair/one-triple BlockMatch proof valid for both parities, including
   the fixed-cardinality matching reduction and the tight DAG construction?
2. Does the exact top-`b+1` profile proof handle ties, unreachable candidates,
   cycles, and the multi-label FIFO stopping rule correctly?
3. Does the Lagrangian closure construction give a valid lower bound with the
   stated constant and rounding direction, and does a cardinality hit prove
   optimality?
4. Given that Chen--Chen--Ye--Zhang use minimum-density sets plus singleton
   greedy, is BlockMatch or its block-partition inequality already explicit or
   immediate in another predecessor?

Please record each section as valid, repairable, or blocking in
`paper/INDEPENDENT_REVIEW_PACKET.md`, with page/line references. Passing tests
should be treated only as supporting evidence, not as proof.

Thank you,
[name]

## Required return record

Save the completed review locally with reviewer name, date, conflicts, verdict
for Sections A--E, and the disposition of every repairable item. Do not insert
reviewer identity into the anonymous submission PDF or public artifact during
double-blind review.

## 3. Clarify the COI declaration interface

The authenticated submission and Author Console expose no declaration control
or author task.  The saved official CFP contains no EasyChair link, while the
public long-paper configuration exposes reviewer/AC/SAC conflict identifiers
but no author entry point.  OpenReview's official documentation describes a
venue-organizer workflow that computes and posts conflict edges from profiles,
publications, affiliations, and relations.  Send this request only from the
author's account; the populated private version is
`private/COI_INTERFACE_EMAIL.md`.

Subject: WWW 2027 research-track COI declaration interface

Dear WWW 2027 Research Track Chairs,

The current research-track call says that submissions and author profiles are
managed in OpenReview, while the COI policy says that all conflicts must be
declared in EasyChair, but it provides no EasyChair link. The submission and
Author Console expose no declaration control or outstanding author task.
OpenReview documentation describes venue-organizer conflict computation from
profiles, publications, and relations.

Could you confirm whether that automatic OpenReview process satisfies the
research-track requirement, or whether authors must separately declare
conflicts in EasyChair? If a separate declaration is required, please provide
its link or instructions, including how to report active collaborators and
co-PIs, employment candidacy, family or close personal relationships, and
personal animosity that may not appear in an OpenReview profile.

The submission is already registered in OpenReview; this question concerns
only completion of the required COI declaration before the abstract deadline.

Thank you,
[name and submission number]
