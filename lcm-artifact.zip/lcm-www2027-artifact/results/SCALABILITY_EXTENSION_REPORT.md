# Million-scale scalability extension

The four omitted large graphs contribute 20 sealed test targets and 60 paired target-budget cells. Development pilots are reported separately and excluded from the primary aggregate.

## Integrity and resource gates

- Raw results: `c21337888c54e6d47ea5f3dc63575d23d3965a51462a2364431b70737156eddd` (144/144 successful, unique cells).
- All frozen implementation, configuration, target, graph, budget, and deletion-set checks passed.

| Dataset | Pilot indegree | A1 score s | Singleton score s | Peak MiB | Gate |
|---|---:|---:|---:|---:|:---:|
| citeseer | 190 | 2.172 | 2.002 | 27.8 | pass |
| higgs-twitter-social | 708 | 581.453 | 752.537 | 82.4 | pass |
| soc-pokec-relationships | 185 | 473.107 | 583.132 | 262.4 | pass |
| youtube-links | 2158 | 1872.025 | 1741.377 | 56.6 | pass |

## Sealed test quality

SingletonSort versus Algorithm 1: **6 wins / 52 ties / 2 losses** over 60 paired cells. Relative improvement `(A1-SS)/A1` has median 0.000000%, mean 0.035884%, minimum -0.140935%, and maximum 1.554980%.

| Dataset | Cells | W/T/L | Median improvement | Mean improvement | Range |
|---|---:|---:|---:|---:|---:|
| citeseer | 15 | 2/13/0 | 0.000000% | 0.109235% | 0.000000% to 1.554980% |
| higgs-twitter-social | 15 | 3/12/0 | 0.000000% | 0.021168% | 0.000000% to 0.286664% |
| soc-pokec-relationships | 15 | 0/15/0 | 0.000000% | 0.000000% | 0.000000% to 0.000000% |
| youtube-links | 15 | 1/12/2 | 0.000000% | 0.013133% | -0.140935% to 0.370578% |

| Budget ratio | Cells | W/T/L | Median improvement | Mean improvement |
|---:|---:|---:|---:|---:|
| 0.25 | 20 | 2/17/1 | 0.000000% | 0.094645% |
| 0.5 | 20 | 2/17/1 | 0.000000% | -0.001982% |
| 0.75 | 20 | 2/18/0 | 0.000000% | 0.014989% |

## Timing

Across the 20 sealed targets, the SingletonSort/A1 score-time ratio has median 1.128 and mean 1.123 (range 0.993--1.266). Peak process RSS over all pilot and test runs is 271.5 MiB.

The extension compares only the two same-asymptotic sorting rules. It does not claim that the certificate or local-search components were run on these four large graphs.
