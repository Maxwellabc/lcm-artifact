"""Polynomial value-oracle implementation of the BlockMatch theorem."""

from .algorithm import BlockMatchResult, block_match, fixed_cardinality_matching

__all__ = ["BlockMatchResult", "block_match", "fixed_cardinality_matching"]
