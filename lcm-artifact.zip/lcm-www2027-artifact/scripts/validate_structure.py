"""Exact small-graph checks for research hypotheses; standard library only.

This does not reproduce the paper's experiments or establish novelty.
Run: python3 scripts/validate_structure.py
"""
import itertools
import json
import random
import time
from collections import deque
from fractions import Fraction as Q
from pathlib import Path


def distances(n, edges, target, deleted=frozenset(), omit_target=None):
    reverse = [[] for _ in range(n)]
    for a, b in edges:
        if (a, b) in deleted or a == omit_target or b == omit_target:
            continue
        reverse[b].append(a)
    dist = {target: 0}
    queue = deque([target])
    while queue:
        u = queue.popleft()
        for s in reverse[u]:
            if s not in dist:
                dist[s] = dist[u] + 1
                queue.append(s)
    return dist


def direct(n, edges, v, deleted):
    dist = distances(n, edges, v, deleted)
    return sum((Q(1, d) for s, d in dist.items() if s != v), Q(0))


def profile(n, edges, v):
    neighbors = sorted(a for a, b in edges if b == v)
    cols = [distances(n, edges, u, omit_target=v) for u in neighbors]
    rows = [[Q(1, col[s] + 1) if s in col else Q(0)
             for col in cols] for s in range(n) if s != v]
    return neighbors, rows


def objective(rows, deleted_mask):
    return sum((max((a for i, a in enumerate(row)
                     if not (deleted_mask >> i) & 1), default=Q(0))
                for row in rows), Q(0))


def hyperedges(rows):
    out = []
    for row in rows:
        previous = Q(0)
        for value in sorted(set(row) - {Q(0)}):
            mask = sum(1 << i for i, a in enumerate(row) if a >= value)
            out.append((value - previous, mask))
            previous = value
    return out


def nearest_labels(n, edges, v, neighbors, count):
    """Unweighted multi-label reverse BFS; accept at most count labels/node."""
    reverse = [[] for _ in range(n)]
    for a, b in edges:
        if a != v and b != v:
            reverse[b].append(a)
    accepted = [dict() for _ in range(n)]
    queue = deque((u, i, 0) for i, u in enumerate(neighbors))
    while queue:
        s, label, distance = queue.popleft()
        if label in accepted[s] or len(accepted[s]) >= count:
            continue
        accepted[s][label] = distance
        for predecessor in reverse[s]:
            queue.append((predecessor, label, distance + 1))
    return [[Q(1, accepted[s][i] + 1) if i in accepted[s] else Q(0)
             for i in range(len(neighbors))] for s in range(n) if s != v]


def budget_layers(rows, b):
    constant = Q(0)
    layers = []
    for row in rows:
        order = sorted(range(len(row)), key=lambda i: (-row[i], i))
        constant += row[order[b]]
        mask = 0
        for j in range(b):
            mask |= 1 << order[j]
            delta = row[order[j]] - row[order[j + 1]]
            if delta:
                layers.append((delta, mask))
    return constant, layers


def check_graph(n, edges, v, counter):
    neighbors, rows = profile(n, edges, v)
    d = len(neighbors)
    layers = hyperedges(rows)
    values = []
    for mask in range(1 << d):
        deleted = {(u, v) for i, u in enumerate(neighbors) if mask >> i & 1}
        f = objective(rows, mask)
        assert f == direct(n, edges, v, deleted)
        assert f == sum((weight for weight, subset in layers
                         if subset & mask != subset), Q(0))
        values.append(f)
        counter['deletion_sets'] += 1
    singleton = [sum((row[i] for row in rows), Q(0)) for i in range(d)]
    order = sorted(range(d), key=lambda i: (singleton[i], i))
    initial = values[0]
    for b in range(d + 1):
        k = d - b
        opt = min(f for mask, f in enumerate(values) if bin(mask).count('1') <= b)
        if not k:
            assert opt == 0
            continue
        compressed = nearest_labels(n, edges, v, neighbors, b + 1)
        const, short_layers = budget_layers(rows, b)
        truncated = [const + sum((w for w, subset in short_layers
                                 if subset & mask != subset), Q(0))
                     for mask in range(1 << d)]
        for mask, f in enumerate(values):
            if bin(mask).count('1') <= b:
                assert objective(compressed, mask) == f == truncated[mask]
                counter['budget_compression_checks'] += 1
        retained = sum(1 << i for i in order[:k])
        upper = values[((1 << d) - 1) ^ retained]
        lower = max(Q(k), singleton[order[k - 1]])
        assert lower <= opt <= upper
        assert upper <= k * opt
        assert upper * k <= initial * opt
        assert upper * upper <= initial * opt * opt  # ratio <= sqrt(H)
        # Exhaustively evaluated Lagrangian lower bound, not a min-cut solver.
        for lam in map(Q, [0, Q(1, 4), Q(1, 2), 1, 2, 4]):
            dual = min(f + lam * (bin(mask).count('1') - b)
                       for mask, f in enumerate(values))
            assert dual <= opt
            short_dual = min(f + lam * (bin(mask).count('1') - b)
                             for mask, f in enumerate(truncated))
            assert dual <= short_dual <= opt
        counter['budgets_checked'] += 1
    # Closed-form Lovasz extension agrees with threshold integration.
    if d:
        x = [Q(i + 1, d + 1) for i in range(d)]
        closed = initial - sum((weight * min(x[i] for i in range(d)
                                             if mask >> i & 1)
                                for weight, mask in layers), Q(0))
        integral = Q(0)
        previous = Q(0)
        for level in sorted(set(x)) + [Q(1)]:
            mid = (previous + level) / 2
            mask = sum(1 << i for i in range(d) if x[i] >= mid)
            integral += (level - previous) * values[mask]
            previous = level
        assert closed == integral
    counter['graphs'] += 1


def main():
    start = time.perf_counter()
    counter = dict(graphs=0, deletion_sets=0, budgets_checked=0,
                   budget_compression_checks=0)
    n = 4
    possible = [(a, b) for a in range(n) for b in range(n) if a != b]
    for mask in range(1 << len(possible)):
        edges = [e for i, e in enumerate(possible) if mask >> i & 1]
        check_graph(n, edges, 0, counter)
    rng = random.Random(20260925)
    for _ in range(160):
        n = rng.randrange(5, 10)
        p = rng.choice([0.15, 0.35, 0.7])
        edges = [(a, b) for a in range(n) for b in range(n)
                 if a != b and rng.random() < p]
        check_graph(n, edges, rng.randrange(n), counter)
    # Shared-budget example beyond separate exact-cardinality source hulls.
    # Candidates a,b,c,d,e are 1..5; sources 6 and 7 point to disjoint pairs.
    edges = [(u, 0) for u in range(1, 6)] + [(6, 1), (6, 2), (7, 3), (7, 4)]
    neighbors, rows = profile(8, edges, 0)
    mixtures = [[{1, 2, 3}, {1, 2, 4}, {3, 4, 5}],
                [{3, 4, 1}, {3, 4, 2}, {1, 2, 5}]]
    expected_x = [Q(2, 3)] * 4 + [Q(1, 3)]
    for sets, prefix in zip(mixtures, [{1, 2}, {3, 4}]):
        assert all(len(s) == 3 for s in sets)
        assert [Q(sum(u in s for s in sets), 3) for u in neighbors] == expected_x
        assert Q(sum(prefix <= s for s in sets), 3) == Q(2, 3)
    optimum = min(objective(rows, mask) for mask in range(32)
                  if bin(mask).count('1') == 3)
    fractional = Q(6) - sum(expected_x) - Q(1, 2) * (Q(2, 3) + Q(2, 3))
    strengthened_bound = Q(6) - 3 - Q(1, 2)
    assert optimum == strengthened_bound == Q(5, 2)
    assert fractional == Q(7, 3) < optimum
    result = {
        'status': 'all_checks_passed',
        'seed': 20260925,
        'enumeration': 'all 4096 simple directed graphs on 4 labeled vertices, target=0; 160 random graphs on 5-9 vertices',
        **counter,
        'checks': ['last-entry distance identity', 'weighted threshold coverage',
                   'singleton lower bound', 'singleton-sort min(k,H/k) guarantee',
                   'sqrt(H) guarantee', 'exhaustive Lagrangian lower bounds',
                   'closed-form Lovasz extension',
                   'multi-label BFS top-(b+1) exactness for every feasible set',
                   'budget-truncated Lagrangian bound dominates full bound at tested multipliers'],
        'arithmetic': 'exact rational',
        'cross_source_example': {'vertices': 8, 'budget': 3,
                                 'integer_optimum': str(optimum),
                                 'separate_source_hull_feasible_value': str(fractional),
                                 'with_conflict_cut_bound': str(strengthened_bound)},
        'limitations': 'Not a proof, novelty assessment, solver implementation, or real-data performance evaluation.',
    }
    root = Path(__file__).resolve().parents[1]
    path = root / 'results' / 'structure_validation.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    display = dict(result)
    display['elapsed_seconds'] = round(time.perf_counter() - start, 3)
    print(json.dumps(display, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
