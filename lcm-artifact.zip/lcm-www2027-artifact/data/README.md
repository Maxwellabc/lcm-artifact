# Dataset acquisition and release policy

The research artifact does not redistribute raw graph files, downloaded
archives, or the unlicensed upstream repository snapshot.  It distributes:

- source URLs, provenance notes, and SHA256 hashes in `data/manifests/`;
- the frozen target lists in `data/targets/`;
- the configurations and result logs needed to audit the paper; and
- `scripts/fetch_public_inputs.py`, which obtains inputs from their public
  sources and rejects any byte sequence that does not match the recorded hash.

Verify an existing local cache without network access:

```bash
python3 scripts/fetch_public_inputs.py --check-only
```

On a clean checkout, omit `--check-only` to fetch missing inputs.  The script
does not overwrite an existing graph directory.  Dataset terms remain those
of the respective source; successful download and hash verification do not
grant redistribution rights.

The default fetch covers the four strict-search datasets.  Reproduce or audit
the separately frozen million-scale extension with all eight inputs using:

```bash
python3 scripts/fetch_public_inputs.py --include-scalability
python3 scripts/fetch_public_inputs.py --include-scalability --check-only
```

Large KONECT archives are downloaded in validated byte ranges when the mirror
supports them.  CiteSeer, YouTube, Higgs, and Pokec are converted to a compact
reverse CSR at run time; this cache is derived, excluded from the release, and
rejected unless graph hashes and published simple node/edge counts match.
The fetch verifier also checks raw record counts, removed self-loops, and
self-loop-only labels.  This reconciles CiteSeer's 1,751,463 raw records and
384,413 raw labels with 1,744,590 non-loop edges and 384,054 non-loop endpoint
labels after removing 6,873 self-loops (359 labels occur only in those loops).
Likewise, removing 23 self-loops from Higgs' 14,855,842 raw records gives the
14,855,819 directed edges reported by the paper.

The CiaoDVD graph is fetched from the fixed public mirror recorded in its
manifest because bounded attempts to fetch the canonical KONECT archive did
not complete.  Its graph counts match the published benchmark, but the paper
and manifests label this provenance explicitly.
