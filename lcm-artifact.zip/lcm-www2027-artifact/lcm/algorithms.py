"""Strict-budget baselines and overlap-aware search procedures."""
from dataclasses import dataclass, field
from itertools import combinations
from random import Random
from time import perf_counter
from typing import Dict, FrozenSet, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

from .graph import DirectedGraph
from .objective import harmonic_after_deletions, harmonic_with_all_target_inedges_removed
from .profile import BudgetProfile, singleton_costs


@dataclass(frozen=True)
class AlgorithmResult:
    method: str
    deleted: Tuple[int, ...]
    objective: float
    solve_seconds: float
    diagnostics: Mapping[str, object] = field(default_factory=dict)


def _finish(
    method: str,
    profile: BudgetProfile,
    deleted: Iterable[int],
    started: float,
    diagnostics: Optional[Mapping[str, object]] = None,
) -> AlgorithmResult:
    answer = tuple(sorted(set(deleted)))
    if len(answer) != profile.budget:
        raise AssertionError("strict-budget algorithm returned wrong set size")
    return AlgorithmResult(
        method=method,
        deleted=answer,
        objective=profile.objective(answer),
        solve_seconds=perf_counter() - started,
        diagnostics=dict(diagnostics or {}),
    )


def random_deletion(profile: BudgetProfile, seed: int) -> AlgorithmResult:
    started = perf_counter()
    rng = Random(seed)
    deleted = rng.sample(list(profile.candidates), profile.budget)
    return _finish("random", profile, deleted, started, {"seed": seed})


def degree_deletion(graph: DirectedGraph, profile: BudgetProfile) -> AlgorithmResult:
    started = perf_counter()
    ranked = sorted(profile.candidates, key=lambda u: (-graph.indegree(u), u))
    return _finish("degree", profile, ranked[:profile.budget], started)


def algorithm1(graph: DirectedGraph, profile: BudgetProfile) -> AlgorithmResult:
    """WWW 2024 scalable algorithm, preserving its exact score definition."""
    started = perf_counter()
    scores = {
        u: harmonic_with_all_target_inedges_removed(graph, u, profile.target)
        for u in profile.candidates
    }
    ranked = sorted(profile.candidates, key=lambda u: (-scores[u], u))
    return _finish("algorithm1", profile, ranked[:profile.budget], started,
                   {"score_sum": sum(scores.values())})


def singleton_sort(
    graph: DirectedGraph, profile: BudgetProfile
) -> Tuple[AlgorithmResult, Tuple[float, ...]]:
    """Retain the k candidates with smallest exact singleton costs."""
    started = perf_counter()
    costs = singleton_costs(graph, profile.target, profile.candidates)
    keep_indices = set(sorted(range(profile.d), key=lambda i: (costs[i], i))[:profile.k])
    deleted = [u for i, u in enumerate(profile.candidates) if i not in keep_indices]
    sorted_costs = sorted(costs)
    kth_lower_bound = sorted_costs[profile.k - 1] if profile.k else 0.0
    result = _finish(
        "singleton_sort", profile, deleted, started,
        {"kth_singleton_lower_bound": kth_lower_bound,
         "singleton_cost_sum": sum(costs)},
    )
    return result, costs


def greedy_deletion(profile: BudgetProfile) -> AlgorithmResult:
    """Exact marginal greedy evaluated on the budget-exact profile."""
    started = perf_counter()
    deleted_indices: Set[int] = set()
    candidates = profile.candidates
    for _ in range(profile.budget):
        gains = [0.0] * profile.d
        for row in profile.rows:
            current_position = 0
            while (current_position < len(row.candidate_indices)
                   and row.candidate_indices[current_position] in deleted_indices):
                current_position += 1
            if current_position >= len(row.candidate_indices):
                continue
            current_candidate = row.candidate_indices[current_position]
            current_value = row.values[current_position]
            next_position = current_position + 1
            while (next_position < len(row.candidate_indices)
                   and row.candidate_indices[next_position] in deleted_indices):
                next_position += 1
            next_value = row.values[next_position] if next_position < len(row.values) else 0.0
            gains[current_candidate] += current_value - next_value
        available = (i for i in range(profile.d) if i not in deleted_indices)
        best = min(available, key=lambda i: (-gains[i], i))
        deleted_indices.add(best)
    deleted = [candidates[i] for i in deleted_indices]
    return _finish("greedy", profile, deleted, started)


def one_swap(
    profile: BudgetProfile,
    initial_deleted: Iterable[int],
    *,
    max_rounds: int = 10,
    tolerance: float = 1e-12,
) -> AlgorithmResult:
    """Best-improvement 1-for-1 local search with exact profile evaluation."""
    started = perf_counter()
    deleted_vertices = set(initial_deleted)
    if (len(deleted_vertices) != profile.budget
            or not deleted_vertices <= set(profile.candidates)):
        raise ValueError("initial set must contain exactly budget candidates")
    vertex_to_index = {vertex: i for i, vertex in enumerate(profile.candidates)}
    deleted = {vertex_to_index[vertex] for vertex in deleted_vertices}
    current = profile.objective(deleted_vertices)
    rounds = 0
    evaluations = 0
    for _ in range(max_rounds):
        kept = set(range(profile.d)) - deleted
        # base_total[r] is the objective after restoring deleted candidate r.
        # adjustment[(r,q)] accounts for subsequently deleting retained q.
        base_total = {restored: current for restored in deleted}
        adjustment: Dict[Tuple[int, int], float] = {}
        for row in profile.rows:
            positions = row.candidate_indices
            values = row.values
            retained_positions = [pos for pos, candidate in enumerate(positions)
                                  if candidate not in deleted]
            if not retained_positions:
                deleted_value = {candidate: value for candidate, value in zip(positions, values)
                                 if candidate in deleted}
                for restored in deleted:
                    base_total[restored] += deleted_value.get(restored, 0.0)
                continue
            first_position = retained_positions[0]
            first_candidate = positions[first_position]
            first_value = values[first_position]
            second_value = (values[retained_positions[1]]
                            if len(retained_positions) > 1 else 0.0)
            deleted_value = {candidate: value for candidate, value in zip(positions, values)
                             if candidate in deleted}
            for restored in deleted:
                restored_value = deleted_value.get(restored, 0.0)
                if restored_value > first_value:
                    base_total[restored] += restored_value - first_value
                delta = (max(second_value, restored_value)
                         - max(first_value, restored_value))
                if delta:
                    key = (restored, first_candidate)
                    adjustment[key] = adjustment.get(key, 0.0) + delta
        best_value = current
        best_pair = None
        for restored in sorted(deleted):
            for removed in sorted(kept):
                value = base_total[restored] + adjustment.get((restored, removed), 0.0)
                evaluations += 1
                if (value < best_value - tolerance
                        or (best_pair is not None and abs(value - best_value) <= tolerance
                            and (restored, removed) < best_pair)):
                    best_value = value
                    best_pair = (restored, removed)
        if best_pair is None:
            break
        restored, removed = best_pair
        deleted.remove(restored)
        deleted.add(removed)
        current = best_value
        rounds += 1
    return _finish(
        "one_swap", profile, (profile.candidates[i] for i in deleted), started,
        {"rounds": rounds, "evaluations": evaluations},
    )


def multi_start_one_swap(
    profile: BudgetProfile,
    starts: Sequence[AlgorithmResult],
    *,
    max_rounds: int = 100,
) -> AlgorithmResult:
    """Run exact 1-swap search from distinct strong starts and keep the best."""
    started = perf_counter()
    unique = {}
    for result in starts:
        unique.setdefault(tuple(sorted(result.deleted)), result)
    searched = []
    for start in unique.values():
        improved = one_swap(profile, start.deleted, max_rounds=max_rounds)
        searched.append((start.method, improved))
    start_best = min(starts, key=lambda result: (result.objective, result.method))
    searched.append((start_best.method + "_unmodified", start_best))
    selected_name, selected = min(
        searched, key=lambda item: (item[1].objective, item[0], item[1].deleted))
    diagnostics = {
        "selected_start": selected_name,
        "starts": {name: result.objective for name, result in searched},
        "search_diagnostics": {
            name: dict(result.diagnostics) for name, result in searched
        },
        "max_rounds": max_rounds,
    }
    return _finish("multi_start_one_swap", profile, selected.deleted, started, diagnostics)


def bundle_greedy(
    profile: BudgetProfile,
    *,
    max_prefix: int = 8,
    max_bundle_steps: int = 32,
) -> AlgorithmResult:
    """Complete high-weight prefixes, then fill remaining budget greedily.

    This is a strict-budget heuristic, not a claimed approximation algorithm.
    """
    started = perf_counter()
    deleted: Set[int] = set()
    candidate_vertices = profile.candidates
    current = profile.objective(deleted)
    bundle_steps = 0
    while len(deleted) < profile.budget and bundle_steps < max_bundle_steps:
        remaining = profile.budget - len(deleted)
        bundle_weights: Dict[FrozenSet[int], float] = {}
        for row in profile.rows:
            prefix: Set[int] = set()
            values = list(row.values[:max_prefix + 1])
            values.extend([0.0] * (max_prefix + 1 - len(values)))
            for rank, candidate_index in enumerate(row.candidate_indices[:max_prefix]):
                prefix.add(candidate_vertices[candidate_index])
                missing = frozenset(prefix - deleted)
                if missing and len(missing) <= remaining:
                    delta = values[rank] - values[rank + 1]
                    bundle_weights[missing] = bundle_weights.get(missing, 0.0) + delta
        if not bundle_weights:
            break
        bundle = max(bundle_weights, key=lambda item: (
            bundle_weights[item] / len(item), bundle_weights[item],
            -len(item), tuple(-vertex for vertex in sorted(item))))
        new_value = profile.objective(deleted | set(bundle))
        if new_value >= current - 1e-12:
            break
        deleted.update(bundle)
        current = new_value
        bundle_steps += 1
    if len(deleted) < profile.budget:
        # Finish with exact single-edge greedy from the current state.
        while len(deleted) < profile.budget:
            best_vertex = None
            best_value = current
            for vertex in candidate_vertices:
                if vertex in deleted:
                    continue
                value = profile.objective(deleted | {vertex})
                if (best_vertex is None or value < best_value - 1e-12
                        or (abs(value - best_value) <= 1e-12 and vertex < best_vertex)):
                    best_vertex, best_value = vertex, value
            deleted.add(best_vertex)
            current = best_value
    return _finish("bundle_greedy", profile, deleted, started,
                   {"max_prefix": max_prefix, "bundle_steps": bundle_steps})


def prefix_exchange(
    profile: BudgetProfile,
    initial_deleted: Iterable[int],
    *,
    max_prefix: int = 8,
    max_missing: int = 4,
    top_bundles: int = 30,
    restore_pool_size: int = 8,
    max_rounds: int = 10,
    tolerance: float = 1e-12,
) -> AlgorithmResult:
    """Complete promising prefixes while restoring the same number of edges.

    Prefix rewards nominate groups of 2--``max_missing`` new deletions. For
    each group, a small pool of currently deleted edges with the lowest exact
    restoration harm is enumerated. Every evaluated set has exactly b edges.
    The procedure is a heuristic and carries no guarantee beyond retaining the
    initial solution when no improvement is found.
    """
    started = perf_counter()
    deleted = set(initial_deleted)
    candidates = set(profile.candidates)
    if len(deleted) != profile.budget or not deleted <= candidates:
        raise ValueError("initial set must contain exactly budget candidates")
    current = profile.objective(deleted)
    rounds = 0
    evaluations = 0
    for _ in range(max_rounds):
        bundle_weights: Dict[FrozenSet[int], float] = {}
        bundle_prefixes: Dict[FrozenSet[int], FrozenSet[int]] = {}
        for row in profile.rows:
            values = list(row.values[:max_prefix + 1])
            values.extend([0.0] * (max_prefix + 1 - len(values)))
            prefix: Set[int] = set()
            for rank, candidate_index in enumerate(row.candidate_indices[:max_prefix]):
                prefix.add(profile.candidates[candidate_index])
                missing = frozenset(prefix - deleted)
                if 2 <= len(missing) <= max_missing:
                    delta = values[rank] - values[rank + 1]
                    if delta > 0.0:
                        bundle_weights[missing] = bundle_weights.get(missing, 0.0) + delta
                        # Keep the largest observed prefix for the same missing set;
                        # restoring inside it would undo its nominated trigger.
                        previous = bundle_prefixes.get(missing, frozenset())
                        if len(prefix) > len(previous):
                            bundle_prefixes[missing] = frozenset(prefix)
        if not bundle_weights:
            break
        nominated = sorted(
            bundle_weights,
            key=lambda bundle: (-bundle_weights[bundle] / len(bundle),
                                -bundle_weights[bundle], tuple(sorted(bundle))),
        )[:top_bundles]
        restoration_harm = []
        for restored in deleted:
            value = profile.objective(deleted - {restored})
            restoration_harm.append((value - current, restored))
        restoration_harm.sort()
        best_value = current
        best_deleted = None
        for bundle in nominated:
            forbidden = bundle_prefixes[bundle]
            pool = [vertex for _, vertex in restoration_harm
                    if vertex not in forbidden][:restore_pool_size]
            if len(pool) < len(bundle):
                continue
            for restored_group in combinations(pool, len(bundle)):
                trial = (deleted | set(bundle)) - set(restored_group)
                value = profile.objective(trial)
                evaluations += 1
                if value < best_value - tolerance:
                    best_value = value
                    best_deleted = trial
        if best_deleted is None:
            break
        deleted = best_deleted
        current = best_value
        rounds += 1
    return _finish(
        "prefix_exchange", profile, deleted, started,
        {"rounds": rounds, "evaluations": evaluations,
         "max_prefix": max_prefix, "max_missing": max_missing,
         "top_bundles": top_bundles, "restore_pool_size": restore_pool_size},
    )


def overlap_search(
    profile: BudgetProfile,
    starts: Sequence[AlgorithmResult],
    *,
    swap_rounds: int = 100,
    exchange_rounds: int = 10,
) -> AlgorithmResult:
    """Multi-start 1-swap followed by prefix-guided equal-budget exchange."""
    started = perf_counter()
    local = multi_start_one_swap(profile, starts, max_rounds=swap_rounds)
    grouped = prefix_exchange(profile, local.deleted, max_rounds=exchange_rounds)
    polished = one_swap(profile, grouped.deleted, max_rounds=swap_rounds)
    best = min((local, grouped, polished), key=lambda item: item.objective)
    return _finish(
        "overlap_search", profile, best.deleted, started,
        {"local_objective": local.objective,
         "prefix_objective": grouped.objective,
         "polished_objective": polished.objective,
         "prefix_diagnostics": dict(grouped.diagnostics)},
    )


def _repair_retained_indices(
    profile: BudgetProfile, retained: Iterable[int]
) -> Set[int]:
    """Greedily repair a min-cut retained set to exact size k under g_b."""
    retained_set = set(retained)
    while len(retained_set) < profile.k:
        increases = [0.0] * profile.d
        for row in profile.rows:
            prefix_count = min(profile.budget, len(row.candidate_indices))
            current_position = prefix_count
            current_value = (row.values[profile.budget]
                             if len(row.values) > profile.budget else 0.0)
            for position in range(prefix_count):
                if row.candidate_indices[position] in retained_set:
                    current_position = position
                    current_value = row.values[position]
                    break
            for position in range(current_position):
                candidate = row.candidate_indices[position]
                if candidate not in retained_set:
                    increases[candidate] += row.values[position] - current_value
        candidate = min(
            (i for i in range(profile.d) if i not in retained_set),
            key=lambda i: (increases[i], i),
        )
        retained_set.add(candidate)
    while len(retained_set) > profile.k:
        decreases = [0.0] * profile.d
        for row in profile.rows:
            prefix_count = min(profile.budget, len(row.candidate_indices))
            retained_positions = [
                position for position in range(prefix_count)
                if row.candidate_indices[position] in retained_set
            ]
            if not retained_positions:
                continue
            first = retained_positions[0]
            candidate = row.candidate_indices[first]
            next_value = (row.values[retained_positions[1]]
                          if len(retained_positions) > 1
                          else (row.values[profile.budget]
                                if len(row.values) > profile.budget else 0.0))
            decreases[candidate] += row.values[first] - next_value
        candidate = min(retained_set, key=lambda i: (-decreases[i], i))
        retained_set.remove(candidate)
    return retained_set


def parametric_repair(
    profile: BudgetProfile,
    *,
    iterations: int = 10,
    scale: int = 100_000,
) -> AlgorithmResult:
    """Repair regularized min-cut solutions to the strict cardinality.

    This is the project adaptation of the established regularized min-cut plus
    greedy cardinality-repair pattern. It is a strong baseline, not a novelty
    claim, and no external approximation ratio is transferred here.
    """
    from .flow import lagrangian_sweep

    started = perf_counter()
    certificates = lagrangian_sweep(profile, iterations=iterations, scale=scale)
    candidate_to_index = {vertex: i for i, vertex in enumerate(profile.candidates)}
    repaired = []
    for certificate in certificates:
        retained = {candidate_to_index[vertex] for vertex in certificate.retained}
        fixed = _repair_retained_indices(profile, retained)
        deleted = tuple(profile.candidates[i] for i in range(profile.d) if i not in fixed)
        value = profile.objective(deleted)
        repaired.append((value, deleted, certificate.retained_count,
                         certificate.multiplier, certificate.lower_bound))
    value, deleted, original_size, multiplier, lower_bound = min(repaired)
    return _finish(
        "parametric_repair", profile, deleted, started,
        {"sweep_solutions": len(certificates),
         "selected_original_retained_count": original_size,
         "selected_multiplier": multiplier,
         "best_sweep_lower_bound": max(item.lower_bound for item in certificates),
         "selected_cut_lower_bound": lower_bound},
    )


def certified_hybrid(
    profile: BudgetProfile,
    starts: Sequence[AlgorithmResult],
    *,
    parametric: Optional[AlgorithmResult] = None,
    fallbacks: Sequence[AlgorithmResult] = (),
    parametric_iterations: int = 10,
    parametric_scale: int = 100_000,
    swap_rounds: int = 100,
    exchange_rounds: int = 10,
) -> AlgorithmResult:
    """Combine parametric min-cut repair with strict-budget local search.

    The returned lower bound is inherited from the integer-flow sweep and is
    independent of the heuristic repair and polishing steps.  It therefore
    gives a rigorous a posteriori gap for the returned feasible solution.
    """
    started = perf_counter()
    if parametric is None:
        parametric = parametric_repair(
            profile, iterations=parametric_iterations, scale=parametric_scale
        )
    elif parametric.method != "parametric_repair":
        raise ValueError("parametric start must come from parametric_repair")
    local = multi_start_one_swap(
        profile, [*starts, parametric], max_rounds=swap_rounds
    )
    grouped = prefix_exchange(
        profile, local.deleted, max_rounds=exchange_rounds
    )
    polished = one_swap(profile, grouped.deleted, max_rounds=swap_rounds)
    candidates = (local, grouped, polished, *fallbacks)
    best = min(
        candidates,
        key=lambda item: (item.objective, item.method, item.deleted),
    )
    lower_bound = float(parametric.diagnostics["best_sweep_lower_bound"])
    gap = ((best.objective - lower_bound) / best.objective
           if best.objective else 0.0)
    return _finish(
        "certified_hybrid", profile, best.deleted, started,
        {"parametric_objective": parametric.objective,
         "local_objective": local.objective,
         "prefix_objective": grouped.objective,
         "polished_objective": polished.objective,
         "selected_component": best.method,
         "fallback_objectives": {
             item.method: item.objective for item in fallbacks
         },
         "certified_lower_bound": lower_bound,
         "certified_relative_gap": gap,
         "parametric_diagnostics": dict(parametric.diagnostics),
         "prefix_diagnostics": dict(grouped.diagnostics)},
    )


def brute_force_optimum(profile: BudgetProfile, *, max_combinations: int = 1_000_000):
    """Return the exact optimum for small instances, or raise on excess size."""
    from math import comb

    count = comb(profile.d, profile.budget)
    if count > max_combinations:
        raise ValueError("%d combinations exceed limit %d" % (count, max_combinations))
    best_value = float("inf")
    best_deleted: Tuple[int, ...] = tuple()
    for deleted in combinations(profile.candidates, profile.budget):
        value = profile.objective(deleted)
        if value < best_value:
            best_value = value
            best_deleted = deleted
    return best_value, best_deleted, count
