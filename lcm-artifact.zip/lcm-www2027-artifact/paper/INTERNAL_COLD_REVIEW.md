# Internal reviewer-oriented audit, 2026-10-15

This is an internal check, not an independent expert endorsement or an acceptance
prediction. Historical review notes are retained privately.

| Concern | Action and evidence | Limit |
|---|---|---|
| Singleton algorithm novelty | Explicitly identify SingletonSort as the established MUB specialization; cite NeurIPS/ICML 2013 | The algorithm itself is not newly invented |
| Theory depth | Prove the marginal floor, residual monotonicity, affine even/odd block bounds, feasible upper bound and refined envelopes in `thm:floor` / `app:floor` | No all-algorithm lower bound or envelope tightness is claimed |
| Generic framework overlap | Credit curvature, nearest-terminal traversal, weighted minimum union, nested monomials, closure/cuts and sparsification | Bounded source search cannot certify novelty |
| Modern literature | 27 cited works; all 21 DOI records rechecked, remaining 6 primary records verified | Two KDD full texts unavailable; only title-supported model distinctions are stated |
| Missing real BlockMatch comparator | Export the separate 48-cell exact-optimum experiment with all graph/method results | Post-freeze, low degree, no confirmatory significance claim |
| Negative result | Report PolBlogs label 595: BM 447.666666667 vs OPT 446.3; overlap finds OPT | No dominance over strong search or large-degree scalability claim |
| Numerical guarantee | Add integer-weight blossom, precision regression, independent exact DP agreement on all 48 cells | Historical float backend is preserved and its sample surrogates are separately verified |
| Reproducibility | Keep frozen implementation hash unchanged, retain historical protocol/results hashes, package verifier and data acquisition manifests | Raw graphs are not redistributed; timings are machine-specific |
| Statistics | Keep target-clustered intervals and frozen 198-cell primary analysis separate from supplementary audits | Audit cells are not independent statistical replications |
| Paper form | 8 main pages, at most 12 total, standard algorithm floats, manual TikZ concept diagram, vector scientific figures | Requires visual check after final build |
| Submission state | Current revision is local; prior OpenReview receipt remains historical | No new upload or email is performed by this revision |
