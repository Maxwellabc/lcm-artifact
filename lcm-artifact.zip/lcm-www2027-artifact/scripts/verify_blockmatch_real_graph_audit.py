"""Independently enumerate the new real-graph optima by original-graph BFS."""
import hashlib
import json
import sys
from collections import Counter
from fractions import Fraction
from itertools import combinations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from lcm.graph import load_edgelist
from lcm.objective import reverse_distances


def rational_bfs(graph, target, deleted):
    distances = reverse_distances(graph, target, blocked_head=target,
                                  blocked_tails=deleted)
    histogram = Counter(d for d in distances if d > 0)
    return sum((Fraction(count, distance) for distance, count in histogram.items()),
               Fraction(0))


def main():
    protocol_path = ROOT / "configs/BLOCKMATCH_REAL_GRAPH_PROTOCOL.json"
    protocol = json.loads(protocol_path.read_text())
    raw = ROOT / "results/blockmatch_real_graph.jsonl"
    rows = [json.loads(line) for line in raw.read_text().splitlines()]
    cells = 0
    subsets = 0
    for record in protocol["graphs"]:
        graph = load_edgelist(ROOT / record["graph"])
        for row in (r for r in rows if r["graph"] == record["name"]):
            target = row["target"]
            candidates = frozenset(graph.in_neighbors[target])
            denominator = int(row["rational_denominator"])
            checked = []
            for deleted in combinations(sorted(candidates), row["budget"]):
                checked.append(rational_bfs(graph, target, deleted))
            optimum = min(checked)
            assert len(checked) == row["optimum_combinations"]
            assert optimum == Fraction(int(row["optimum_numerator"]), denominator)
            assert rational_bfs(graph, target, candidates - set(row["optimum_retained"])) == optimum
            for method, answer in row["methods"].items():
                assert len(set(answer["deleted"])) == row["budget"]
                actual = rational_bfs(graph, target, answer["deleted"])
                expected = Fraction(int(answer["objective_numerator"]), denominator)
                assert actual == expected, (record["name"], target, row["budget"], method)
            cells += 1
            subsets += len(checked)
        print(json.dumps({"graph": record["name"], "verified_cells_so_far": cells}), flush=True)
    assert cells == 48 and subsets == 3239
    result = {"status": "ok", "cells": cells,
              "subsets_independently_enumerated_by_rational_original_graph_bfs": subsets,
              "method_outputs_verified": cells * 5,
              "all_exact_optima_match": True,
              "raw_sha256": hashlib.sha256(raw.read_bytes()).hexdigest(),
              "verifier_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    path = ROOT / "results/BLOCKMATCH_REAL_GRAPH_INDEPENDENT_VERIFICATION.json"
    path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
