"""Independent BFS oracle for harmonic centrality after local edge deletion."""
from collections import deque
from typing import Iterable, List, Optional, Sequence, Set

from .graph import DirectedGraph


def reverse_distances(
    graph: DirectedGraph,
    destination: int,
    *,
    omit_vertex: Optional[int] = None,
    blocked_head: Optional[int] = None,
    blocked_tails: Iterable[int] = (),
) -> List[int]:
    """Return distances from every source to ``destination``.

    Traversing ``in_neighbors`` is a BFS in the reversed graph.  If
    ``blocked_head`` is set, edges (tail, blocked_head) for listed tails are
    omitted.  ``omit_vertex`` removes a vertex and all incident edges.
    Unreachable vertices receive -1.
    """
    if destination < 0 or destination >= graph.n:
        raise ValueError("destination outside graph")
    if destination == omit_vertex:
        raise ValueError("destination cannot be omitted")
    blocked: Set[int] = set(blocked_tails)
    distances = [-1] * graph.n
    distances[destination] = 0
    queue = deque([destination])
    while queue:
        current = queue.popleft()
        next_distance = distances[current] + 1
        for predecessor in graph.in_neighbors[current]:
            if predecessor == omit_vertex:
                continue
            if current == blocked_head and predecessor in blocked:
                continue
            if distances[predecessor] == -1:
                distances[predecessor] = next_distance
                queue.append(predecessor)
    return distances


def harmonic_after_deletions(
    graph: DirectedGraph, target: int, deleted_tails: Iterable[int]
) -> float:
    """Compute h_{G-D}(target) for deleted incoming edges (u,target)."""
    deleted = frozenset(deleted_tails)
    candidates = set(graph.in_neighbors[target])
    if not deleted <= candidates:
        raise ValueError("deletion set contains a non-in-neighbor of target")
    distances = reverse_distances(
        graph, target, blocked_head=target, blocked_tails=deleted
    )
    return sum(1.0 / distance for vertex, distance in enumerate(distances)
               if vertex != target and distance > 0)


def harmonic_with_all_target_inedges_removed(
    graph: DirectedGraph, destination: int, target: int
) -> float:
    """Harmonic centrality used by Algorithm 1 on G minus rho(target)."""
    distances = reverse_distances(
        graph,
        destination,
        blocked_head=target,
        blocked_tails=graph.in_neighbors[target],
    )
    return sum(1.0 / distance for vertex, distance in enumerate(distances)
               if vertex != destination and distance > 0)

