"""Exhaustively audit core theorems on every directed simple graph with n=4."""
import argparse
import hashlib
import json
import sys
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from time import perf_counter


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from lcm.algorithms import brute_force_optimum, singleton_sort
from lcm.flow import exact_lagrangian_certificate
from lcm.graph import from_integer_edges
from lcm.objective import harmonic_after_deletions
from lcm.profile import build_budget_profile


def implementation_hash():
    digest = hashlib.sha256()
    for path in sorted((ROOT / "lcm").glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--n", type=int, default=4)
    args = parser.parse_args(argv)
    if args.n != 4:
        raise ValueError("the frozen exhaustive audit is defined for n=4")

    n = args.n
    possible_edges = [(u, v) for u in range(n) for v in range(n) if u != v]
    started = perf_counter()
    graph_count = 0
    target_budget_cells = 0
    deletion_sets = 0
    lagrangian_checks = 0
    cardinality_hits = 0
    multipliers = (Fraction(0), Fraction(1, 2), Fraction(1), Fraction(2))

    for mask in range(1 << len(possible_edges)):
        edges = [edge for bit, edge in enumerate(possible_edges) if mask & (1 << bit)]
        graph = from_integer_edges(n, edges)
        graph_count += 1
        for target in range(n):
            d = graph.indegree(target)
            for budget in range(d):
                profile = build_budget_profile(graph, target, budget)
                target_budget_cells += 1
                for size in range(budget + 1):
                    for deleted in combinations(profile.candidates, size):
                        deletion_sets += 1
                        profile_value = profile.objective(deleted)
                        oracle_value = harmonic_after_deletions(graph, target, deleted)
                        if abs(profile_value - oracle_value) > 1e-11:
                            raise AssertionError(
                                f"profile mismatch mask={mask} target={target} "
                                f"budget={budget} deleted={deleted}"
                            )
                optimum, _, _ = brute_force_optimum(profile)
                singleton, _ = singleton_sort(graph, profile)
                k = profile.k
                initial = harmonic_after_deletions(graph, target, ())
                factor = min(k, initial / k)
                if singleton.objective > factor * optimum + 1e-10:
                    raise AssertionError(
                        f"singleton bound failed mask={mask} target={target} budget={budget}"
                    )
                for multiplier in multipliers:
                    certificate = exact_lagrangian_certificate(profile, multiplier)
                    lagrangian_checks += 1
                    if float(certificate.lower_bound) > optimum + 1e-11:
                        raise AssertionError(
                            f"lower bound failed mask={mask} target={target} "
                            f"budget={budget} multiplier={multiplier}"
                        )
                    if certificate.retained_count == k:
                        cardinality_hits += 1
                        if abs(float(certificate.lower_bound) - optimum) > 1e-11:
                            raise AssertionError(
                                f"cardinality hit failed mask={mask} target={target} "
                                f"budget={budget} multiplier={multiplier}"
                            )

    result = {
        "status": "ok",
        "n": n,
        "possible_arcs": len(possible_edges),
        "graphs": graph_count,
        "target_budget_cells": target_budget_cells,
        "feasible_deletion_sets": deletion_sets,
        "lagrangian_checks": lagrangian_checks,
        "cardinality_hits": cardinality_hits,
        "multipliers": [str(value) for value in multipliers],
        "implementation_hash": implementation_hash(),
        "seconds": perf_counter() - started,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
