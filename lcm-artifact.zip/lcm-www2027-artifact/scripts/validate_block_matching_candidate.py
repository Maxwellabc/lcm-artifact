"""Validate the BlockMatch approximation candidate on small instances.

This is an exponential reference implementation for auditing the theorem.  The
claimed polynomial algorithm uses minimum-weight fixed-cardinality matching;
the dynamic program below is deliberately independent of a blossom library.
"""
import json
import random
import sys
from functools import lru_cache
from itertools import combinations
from math import inf
from pathlib import Path

import networkx as nx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from blockmatch import block_match
from lcm.graph import from_integer_edges
from lcm.objective import harmonic_after_deletions


def minimum_pair_partition(items, pair_count, value):
    """Return minimum surrogate for ``pair_count`` disjoint pairs."""
    items = tuple(items)
    index = {item: position for position, item in enumerate(items)}

    @lru_cache(maxsize=None)
    def solve(mask, remaining):
        if remaining == 0:
            return 0.0, ()
        if bin(mask).count("1") < 2 * remaining:
            return inf, ()
        first_position = (mask & -mask).bit_length() - 1
        first = items[first_position]
        without_first = mask & ~(1 << first_position)
        best = solve(without_first, remaining)
        tail = without_first
        while tail:
            second_position = (tail & -tail).bit_length() - 1
            second = items[second_position]
            suffix_value, suffix_partition = solve(
                without_first & ~(1 << second_position), remaining - 1
            )
            candidate = (
                value(frozenset((first, second))) + suffix_value,
                ((first, second),) + suffix_partition,
            )
            if candidate < best:
                best = candidate
            tail &= tail - 1
        return best

    mask = sum(1 << index[item] for item in items)
    return solve(mask, pair_count)


def pair_triple_match(items, k, value):
    """Independent BlockMatch reference using exponential matching DP."""
    items = tuple(items)
    if not 1 <= k <= len(items):
        raise ValueError("k must lie between one and the ground-set size")
    if k == 1:
        item = min(items, key=lambda candidate: (value(frozenset((candidate,))), candidate))
        partition = ((item,),)
        return value(frozenset((item,))), frozenset((item,)), partition
    if k % 2 == 0:
        surrogate, partition = minimum_pair_partition(items, k // 2, value)
    else:
        triple = min(
            combinations(items, 3),
            key=lambda candidate: (value(frozenset(candidate)), candidate),
        )
        remaining_items = tuple(item for item in items if item not in triple)
        pair_value, pairs = minimum_pair_partition(
            remaining_items, (k - 3) // 2, value
        )
        surrogate = value(frozenset(triple)) + pair_value
        partition = (triple,) + pairs
    selected = frozenset(item for block in partition for item in block)
    assert len(selected) == k
    return surrogate, selected, partition


def exact_optimum(items, k, value):
    return min((value(frozenset(selected)), frozenset(selected))
               for selected in combinations(items, k))


def audit_instance(items, k, value, tolerance=1e-9):
    optimum, _ = exact_optimum(items, k, value)
    surrogate, selected, _ = pair_triple_match(items, k, value)
    objective = value(selected)
    factor = 1 if k <= 3 else k // 2
    assert objective <= surrogate + tolerance
    assert objective <= factor * optimum + tolerance
    return objective, optimum, surrogate


def random_coverage_audit(rng, trials=300):
    checks = 0
    for _ in range(trials):
        d = rng.randrange(1, 10)
        universe = range(rng.randrange(2, 14))
        weights = {element: rng.randrange(1, 8) for element in universe}
        sets = {
            item: frozenset(element for element in universe if rng.random() < 0.4)
            for item in range(d)
        }

        def value(selected):
            covered = set()
            for item in selected:
                covered.update(sets[item])
            return float(sum(weights[element] for element in covered))

        for k in range(1, d + 1):
            audit_instance(tuple(range(d)), k, value)
            checks += 1
    return checks


def exhaustive_binary_coverage_audit(candidate_count=6, universe_size=3):
    """Exhaust every small unweighted coverage system and every cardinality.

    This audit is deliberately integer-only and does not call the production
    blossom implementation.  It checks both ordinary coverage and an
    LCM-shaped augmentation in which every selected candidate contributes one
    private element.  The latter supplies the structural lower bound
    ``g(R) >= |R|`` used by the instance-dependent LCM guarantees.
    """
    d = candidate_count
    if d < 3 or universe_size < 1:
        raise ValueError("audit requires at least three candidates and one element")

    def popcount(mask):
        """Count set bits without requiring Python 3.10's int.bit_count."""
        return bin(mask).count("1")

    full = (1 << d) - 1
    masks_by_size = {
        size: tuple(mask for mask in range(1, full + 1)
                    if popcount(mask) == size)
        for size in range(1, d + 1)
    }
    triples = tuple(combinations(range(d), 3))

    @lru_cache(maxsize=None)
    def matching_partitions(allowed_mask, pair_count):
        """All matchings of an exact size, represented by their pair masks."""
        if pair_count == 0:
            return ((),)
        if popcount(allowed_mask) < 2 * pair_count:
            return ()
        first_bit = allowed_mask & -allowed_mask
        without_first = allowed_mask ^ first_bit
        partitions = list(matching_partitions(without_first, pair_count))
        remaining = without_first
        while remaining:
            second_bit = remaining & -remaining
            suffix_mask = without_first ^ second_bit
            pair_mask = first_bit | second_bit
            for suffix in matching_partitions(suffix_mask, pair_count - 1):
                partitions.append((pair_mask,) + suffix)
            remaining ^= second_bit
        return tuple(partitions)

    def exact_optimum_mask(values, k):
        return min((values[mask], mask) for mask in masks_by_size[k])

    def singleton_mask(values, k):
        chosen = sorted(range(d), key=lambda item: (values[1 << item], item))[:k]
        return sum(1 << item for item in chosen)

    def blockmatch_mask(values, k):
        if k == 1:
            return min((values[1 << item], 1 << item) for item in range(d)) + ((),)
        if k % 2 == 0:
            candidates = []
            for partition in matching_partitions(full, k // 2):
                selected = 0
                surrogate = 0
                for pair_mask in partition:
                    selected |= pair_mask
                    surrogate += values[pair_mask]
                candidates.append((surrogate, selected, partition))
            return min(candidates)
        triple = min(
            (values[sum(1 << item for item in items)], items)
            for items in triples
        )[1]
        triple_mask = sum(1 << item for item in triple)
        candidates = []
        for partition in matching_partitions(full ^ triple_mask, (k - 3) // 2):
            selected = triple_mask
            surrogate = values[triple_mask]
            for pair_mask in partition:
                selected |= pair_mask
                surrogate += values[pair_mask]
            candidates.append((surrogate, selected, (triple_mask,) + partition))
        return min(candidates)

    def audit_values(values, *, lcm_augmented):
        h = values[full]
        for k in range(1, d + 1):
            optimum, _ = exact_optimum_mask(values, k)

            singleton_selected = singleton_mask(values, k)
            singleton_objective = values[singleton_selected]
            if singleton_objective > k * optimum:
                raise AssertionError("SingletonSort violates its k-factor")

            surrogate, selected, _ = blockmatch_mask(values, k)
            objective = values[selected]
            factor = 1 if k <= 3 else k // 2
            if objective > surrogate:
                raise AssertionError("BlockMatch objective exceeds block surrogate")
            if objective > factor * optimum:
                raise AssertionError("BlockMatch violates its block factor")
            if k <= 3 and objective != optimum:
                raise AssertionError("BlockMatch is not exact for k<=3")

            if lcm_augmented:
                if optimum < k:
                    raise AssertionError("private elements did not enforce OPT>=k")
                if singleton_objective * k > h * optimum:
                    raise AssertionError("SingletonSort violates its h/k branch")
                if singleton_objective * singleton_objective > h * optimum * optimum:
                    raise AssertionError("SingletonSort violates its sqrt(h) bound")
                if k >= 2:
                    if objective * k > h * optimum:
                        raise AssertionError("BlockMatch violates its h/k branch")
                    if 2 * objective * objective > h * optimum * optimum:
                        raise AssertionError("BlockMatch violates its sqrt(h/2) bound")

    system_count = 0
    ordinary_cells = 0
    augmented_cells = 0
    set_choice_count = 1 << universe_size
    total_systems = set_choice_count ** d
    for encoded in range(total_systems):
        code = encoded
        candidate_sets = []
        for _ in range(d):
            candidate_sets.append(code % set_choice_count)
            code //= set_choice_count

        unions = [0] * (1 << d)
        ordinary = [0] * (1 << d)
        augmented = [0] * (1 << d)
        for selected in range(1, 1 << d):
            bit = selected & -selected
            item = bit.bit_length() - 1
            predecessor = selected ^ bit
            unions[selected] = unions[predecessor] | candidate_sets[item]
            ordinary[selected] = popcount(unions[selected])
            augmented[selected] = ordinary[selected] + popcount(selected)

        audit_values(ordinary, lcm_augmented=False)
        audit_values(augmented, lcm_augmented=True)
        system_count += 1
        ordinary_cells += d
        augmented_cells += d

    return {
        "candidate_count": d,
        "universe_size": universe_size,
        "ordered_set_systems": system_count,
        "ordinary_coverage_cardinality_cells": ordinary_cells,
        "private_element_augmented_cardinality_cells": augmented_cells,
    }


def random_lcm_audit(rng, trials=120):
    checks = 0
    for _ in range(trials):
        n = rng.randrange(4, 10)
        edges = [(u, v) for u in range(n) for v in range(n)
                 if u != v and rng.random() < 0.35]
        graph = from_integer_edges(n, edges)
        target = rng.randrange(n)
        items = tuple(sorted(graph.in_neighbors[target]))
        if not items or len(items) > 9:
            continue

        def value(selected):
            deleted = set(items) - set(selected)
            return harmonic_after_deletions(graph, target, deleted)

        for k in range(1, len(items) + 1):
            audit_instance(items, k, value)
            checks += 1
    return checks


def tight_lcm_family(k, group_size):
    target = 0
    first = list(range(1, k + 1))
    second = list(range(k + 1, 2 * k + 1))
    edges = [(candidate, target) for candidate in (*first, *second)]
    if k % 2 == 0:
        groups = [first[position:position + 2] for position in range(0, k, 2)]
    else:
        groups = [first[:3]] + [first[position:position + 2]
                                  for position in range(3, k, 2)]
    next_source = 2 * k + 1
    for group in groups:
        for _ in range(group_size):
            edges.extend((next_source, candidate) for candidate in group)
            next_source += 1
    for _ in range(group_size + 1):
        edges.extend((next_source, candidate) for candidate in second)
        next_source += 1
    graph = from_integer_edges(next_source, edges)
    items = tuple((*first, *second))

    def value(selected):
        return harmonic_after_deletions(graph, target, set(items) - set(selected))

    objective, optimum, surrogate = audit_instance(items, k, value)
    return {
        "k": k,
        "blocks": k // 2,
        "group_size": group_size,
        "objective": objective,
        "optimum": optimum,
        "surrogate": surrogate,
        "ratio": objective / optimum,
    }


def compare_polynomial(items, k, value):
    reference_surrogate, _, _ = pair_triple_match(items, k, value)
    result = block_match(items, k, value)
    if abs(result.surrogate - reference_surrogate) > 1e-9:
        raise AssertionError("blossom surrogate disagrees with reference DP")
    if abs(result.objective - value(result.selected)) > 1e-9:
        raise AssertionError("reported BlockMatch objective is stale")
    optimum, _ = exact_optimum(items, k, value)
    factor = 1 if k <= 3 else k // 2
    if result.objective > factor * optimum + 1e-9:
        raise AssertionError("polynomial BlockMatch violates its factor")
    if result.matching_calls > 1:
        raise AssertionError("BlockMatch made more than one blossom call")
    return result.matching_calls


def polynomial_agreement_audit(rng, coverage_trials=80, lcm_trials=40):
    checks = 0
    maximum_matching_calls = 0
    for _ in range(coverage_trials):
        d = rng.randrange(1, 10)
        universe = range(rng.randrange(2, 14))
        weights = {element: rng.randrange(1, 8) for element in universe}
        sets = {
            item: frozenset(element for element in universe if rng.random() < 0.4)
            for item in range(d)
        }

        def value(selected):
            covered = set()
            for item in selected:
                covered.update(sets[item])
            return float(sum(weights[element] for element in covered))

        maximum_matching_calls = max(
            maximum_matching_calls,
            compare_polynomial(tuple(range(d)), rng.randrange(1, d + 1), value),
        )
        checks += 1

    while checks < coverage_trials + lcm_trials:
        n = rng.randrange(4, 10)
        edges = [(u, v) for u in range(n) for v in range(n)
                 if u != v and rng.random() < 0.35]
        graph = from_integer_edges(n, edges)
        target = rng.randrange(n)
        items = tuple(sorted(graph.in_neighbors[target]))
        if not items or len(items) > 9:
            continue

        def value(selected):
            return harmonic_after_deletions(
                graph, target, set(items) - set(selected)
            )

        maximum_matching_calls = max(
            maximum_matching_calls,
            compare_polynomial(items, rng.randrange(1, len(items) + 1), value),
        )
        checks += 1
    return checks, maximum_matching_calls


def main():
    rng = random.Random(20260926)
    exhaustive_coverage = exhaustive_binary_coverage_audit()
    coverage_checks = random_coverage_audit(rng)
    lcm_checks = random_lcm_audit(rng)
    polynomial_checks, maximum_matching_calls = polynomial_agreement_audit(rng)
    tight = [tight_lcm_family(k, 200) for k in (4, 5, 6, 7)]
    for row in tight:
        assert row["ratio"] > row["blocks"] - 0.2
    result = {
        "status": "all_checks_passed",
        "seed": 20260926,
        "reference_algorithm": (
            "minimum triple plus exponential matching dynamic program; "
            "theorem uses one polynomial fixed-cardinality blossom matching"
        ),
        "random_weighted_coverage_cells": coverage_checks,
        "exhaustive_binary_coverage": exhaustive_coverage,
        "random_lcm_cells": lcm_checks,
        "polynomial_blossom_reference_agreement_cells": polynomial_checks,
        "maximum_polynomial_matching_calls": maximum_matching_calls,
        "networkx_version": nx.__version__,
        "tight_dag_family": tight,
        "claim_under_audit": (
            "BlockMatch is exact for k<=3 and a floor(k/2)-approximation "
            "for normalized nonnegative monotone submodular minimization at "
            "cardinality k; for LCM its ratio is at most "
            "min(floor(k/2), h_G(v)/k) <= sqrt(h_G(v)/2) for k>=2."
        ),
        "novelty_status": "unresolved; do not cite this audit as prior-art clearance",
    }
    output = ROOT / "results" / "BLOCK_MATCHING_CANDIDATE_AUDIT.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
