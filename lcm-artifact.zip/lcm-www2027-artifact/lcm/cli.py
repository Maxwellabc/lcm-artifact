"""Command-line runner producing one JSON record per method."""
import argparse
import json
import platform
import sys
from pathlib import Path
from time import perf_counter

from .algorithms import (
    algorithm1,
    bundle_greedy,
    certified_hybrid,
    degree_deletion,
    greedy_deletion,
    one_swap,
    multi_start_one_swap,
    overlap_search,
    parametric_repair,
    random_deletion,
    singleton_sort,
)
from .flow import search_lagrangian_bound
from .graph import load_author_targets, load_edgelist
from .objective import harmonic_after_deletions
from .profile import build_budget_profile


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--graph", type=Path, required=True)
    target = result.add_mutually_exclusive_group(required=True)
    target.add_argument("--target", type=int, help="internal lexical-order ID")
    target.add_argument("--targets-file", type=Path)
    result.add_argument("--target-index", type=int, default=0)
    result.add_argument("--budget", type=int)
    result.add_argument("--budget-ratio", type=float, default=0.5)
    result.add_argument("--methods", default="algorithm1,degree,greedy,singleton_sort,parametric_repair,multi_start_one_swap,certified_hybrid")
    result.add_argument("--random-seed", type=int, default=0)
    result.add_argument("--certificate", action="store_true")
    result.add_argument("--output", type=Path)
    return result


def main(argv=None) -> int:
    args = parser().parse_args(argv)
    load_started = perf_counter()
    graph = load_edgelist(args.graph)
    load_seconds = perf_counter() - load_started
    if args.target is not None:
        target = args.target
    else:
        targets = load_author_targets(args.targets_file)
        target = targets[args.target_index]
    d = graph.indegree(target)
    budget = args.budget if args.budget is not None else int(d * args.budget_ratio)
    profile_started = perf_counter()
    profile = build_budget_profile(graph, target, budget)
    profile_seconds = perf_counter() - profile_started
    empty = harmonic_after_deletions(graph, target, ())
    methods = [method.strip() for method in args.methods.split(",") if method.strip()]
    records = []
    singleton_result = None
    singleton_cost_values = None
    cached = {}
    for method in methods:
        if method == "algorithm1":
            result = algorithm1(graph, profile)
            cached[method] = result
        elif method == "degree":
            result = degree_deletion(graph, profile)
        elif method == "random":
            result = random_deletion(profile, args.random_seed)
        elif method == "greedy":
            result = greedy_deletion(profile)
            cached[method] = result
        elif method == "singleton_sort":
            if singleton_result is None:
                singleton_result, singleton_cost_values = singleton_sort(graph, profile)
            result = singleton_result
        elif method == "one_swap":
            if singleton_result is None:
                singleton_result, singleton_cost_values = singleton_sort(graph, profile)
            result = one_swap(profile, singleton_result.deleted)
        elif method == "multi_start_one_swap":
            if singleton_result is None:
                singleton_result, singleton_cost_values = singleton_sort(graph, profile)
            if "algorithm1" not in cached:
                cached["algorithm1"] = algorithm1(graph, profile)
            if "greedy" not in cached:
                cached["greedy"] = greedy_deletion(profile)
            result = multi_start_one_swap(
                profile, [cached["algorithm1"], cached["greedy"], singleton_result],
                max_rounds=100,
            )
        elif method == "overlap_search":
            if singleton_result is None:
                singleton_result, singleton_cost_values = singleton_sort(graph, profile)
            if "algorithm1" not in cached:
                cached["algorithm1"] = algorithm1(graph, profile)
            if "greedy" not in cached:
                cached["greedy"] = greedy_deletion(profile)
            result = overlap_search(
                profile, [cached["algorithm1"], cached["greedy"], singleton_result],
                swap_rounds=100,
            )
            cached[method] = result
        elif method == "parametric_repair":
            result = parametric_repair(profile)
            cached[method] = result
        elif method == "certified_hybrid":
            if singleton_result is None:
                singleton_result, singleton_cost_values = singleton_sort(graph, profile)
            if "algorithm1" not in cached:
                cached["algorithm1"] = algorithm1(graph, profile)
            if "greedy" not in cached:
                cached["greedy"] = greedy_deletion(profile)
            result = certified_hybrid(
                profile, [cached["algorithm1"], cached["greedy"], singleton_result],
                parametric=cached.get("parametric_repair"),
                fallbacks=([cached["overlap_search"]]
                           if "overlap_search" in cached else []),
            )
        elif method == "bundle_greedy":
            result = bundle_greedy(profile)
        else:
            raise ValueError("unknown method %r" % method)
        exact = harmonic_after_deletions(graph, target, result.deleted)
        if abs(exact - result.objective) > 1e-9 * max(1.0, exact):
            raise AssertionError("compressed and original objectives disagree")
        record = {
            "dataset": args.graph.name,
            "n": graph.n,
            "m": graph.m,
            "target_internal_id": target,
            "target_original_label": graph.labels[target],
            "indegree": d,
            "budget": budget,
            "method": result.method,
            "deleted_count": len(result.deleted),
            "deleted_internal_ids": list(result.deleted),
            "objective_exact": exact,
            "empty_objective": empty,
            "remaining_fraction": exact / empty if empty else None,
            "load_seconds": load_seconds,
            "profile_seconds": profile_seconds,
            "solve_seconds": result.solve_seconds,
            "profile_accepted_labels": profile.accepted_labels,
            "profile_propagation_attempts": profile.propagation_attempts,
            "diagnostics": dict(result.diagnostics),
            "python": platform.python_version(),
            "status": "ok",
        }
        records.append(record)
    if args.certificate:
        certificate = search_lagrangian_bound(profile)
        trivial = max(float(profile.k), profile.base_lower_bound())
        if singleton_result is not None:
            trivial = max(trivial, float(singleton_result.diagnostics["kth_singleton_lower_bound"]))
        certificate_record = {
            "dataset": args.graph.name,
            "target_internal_id": target,
            "budget": budget,
            "method": "lagrangian_certificate",
            "lower_bound": max(trivial, certificate.lower_bound),
            "raw_lagrangian_lower_bound": certificate.lower_bound,
            "trivial_lower_bound": trivial,
            "multiplier": certificate.multiplier,
            "retained_count": certificate.retained_count,
            "flow_nodes": certificate.nodes,
            "flow_arcs": certificate.arcs,
            "scale": certificate.scale,
            "status": "ok",
        }
        records.append(certificate_record)
    rendered = "\n".join(json.dumps(record, sort_keys=True) for record in records) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    sys.stdout.write(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
