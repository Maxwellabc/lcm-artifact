# Reproduction artifact

This package supports the experiments and claims in *Sharper Approximation and
Certified Search for Local Harmonic Centrality Minimization*. It contains the
implementation, frozen configurations, target lists, result logs, generated
paper assets, tests, acquisition manifests, and audit scripts.

It deliberately excludes raw graph files, downloaded archives, the upstream
WWW 2024 repository snapshot, private submission records, virtual environments,
and caches. Dataset terms remain those of their respective sources. Fetch
missing inputs from the fixed public sources and verify their hashes with:

```bash
python3 scripts/verify_artifact_manifest.py --strict
python3 scripts/fetch_public_inputs.py --include-scalability
python3 scripts/fetch_public_inputs.py --include-scalability --check-only
```

The release builder also replaces the absolute checkout prefix in historical
traceback strings inside packaged raw JSONL logs. The frozen source logs remain
unchanged. `ARTIFACT_MANIFEST.json` records the packaged hash and, for every
transformed file, its original `source_sha256` and transformation name.
In the author workspace it also reads the excluded private file
`private/release_identity_markers.txt` and refuses to package any byte payload
that contains a listed identity marker. The marker values and private file are
never added to the archive. A public checkout without that private file still
builds normally; anonymous authors should supply their own marker file before
release.

The TAR builder automatically includes root `LICENSE`,
`THIRD_PARTY_NOTICES.md`, `CITATION.cff`, and `.zenodo.json` files when they
exist. They are absent from the current internal candidate because the author
has not yet approved a public software license. After building and auditing a
licensed TAR, create a deterministic ZIP with identical paths, modes, and
payload bytes using:

```bash
python3 scripts/build_release_zip.py
```

The ZIP command also writes an adjacent SHA-256 sidecar. A public release must
still verify the ZIP by fresh extraction; format conversion does not replace
the manifest, tests, or clean-environment audit.

The anonymous working build checks the excluded author-identity marker file by
default. An accepted, intentionally author-identified release whose license
and citation metadata name the author must instead invoke:

```bash
python3 scripts/build_release_artifact.py --no-identity-marker-check
```

This explicit switch does not weaken forbidden-member or absolute macOS user
path checks. Use it only after double-blind review no longer requires
anonymity, and inspect the resulting author identity deliberately before
publication.

Create the isolated optional LP environment and run the integrity checks:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-lp-lock.txt
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python scripts/exhaustive_small_graph_audit.py \
  --output results/EXHAUSTIVE_SMALL_GRAPH_AUDIT.json
.venv/bin/python scripts/validate_block_matching_candidate.py
python3 scripts/validate_structure.py
python3 scripts/audit_artifact.py
```

`validate_structure.py` reports elapsed time on stdout but deliberately omits
it from `results/structure_validation.json`, so a successful audit does not
change the deterministic evidence bytes.
When historical tracebacks have already been redacted in an extracted
artifact, the release builder verifies their packaged hashes and carries the
original source hashes forward from `ARTIFACT_MANIFEST.json`.  This preserves
both source provenance and byte-identical rebuilds without reconstructing a
private checkout path.

The expected implementation SHA256 is
`6f9f44a2750ac2e7a90a253606be686aa1b8352adcdcd8d05c605ed4c810cf25`.
The frozen runner version is `2026-09-26-resume-v4`. A valid audit reports
5,544 frozen method/trial rows, 198 target-budget cells, 198 exact-certificate
cells, 9 exact cardinality hits, and status `ok`.
The post-freeze BlockMatch reference audit reports 1,476 random weighted
coverage cells, 248 random LCM cells, four tight DAG-family instances, and 120
agreements between the polynomial blossom implementation and the independent
dynamic program; every audited call uses at most one blossom matching.
The separately frozen scalability extension adds 144 successful method rows
over four larger graphs; its 60 sealed pairs reproduce a 6/52/2 W/T/L result.

Regenerate the paper tables and figure from the frozen logs with:

```bash
.venv/bin/python scripts/generate_paper_assets.py \
  --protocol configs/FROZEN_TEST_PROTOCOL.json \
  --suite results/raw/test-moreno.jsonl \
  --suite results/raw/test-ciaodvd.jsonl \
  --suite results/raw/test-polblogs.jsonl \
  --suite results/raw/test-twitter.jsonl \
  --paper-dir paper
.venv/bin/python scripts/summarize_scalability_extension.py \
  --protocol configs/SCALABILITY_EXTENSION_PROTOCOL.json \
  --results results/scalability-extension.jsonl \
  --output-json results/SCALABILITY_EXTENSION_SUMMARY.json \
  --output-markdown results/SCALABILITY_EXTENSION_REPORT.md \
  --latex-output paper/generated/scalability_results.tex
```

Then build `paper/main.tex` with the current official ACM submission template
and a compatible LaTeX engine. The included PDF is the audited anonymous
working draft; the conference template must be checked again at submission.

Before public release, the authors must select and add an explicit license for
their implementation and deposit the final package in an archival repository.
The absence of a license in this internal candidate package does not grant
permission to redistribute or reuse its source code.

## October 15 structural and exact-optimum supplement

This material is separate from the frozen 198 primary cells. The 48 historical
low-degree real-graph records (16 targets, 4 graphs) retain their source hash.
The protocol export changes only public paths and hash provenance. It does
not retrospectively preregister the marginal-floor analysis.

```bash
.venv/bin/python scripts/verify_blockmatch_real_graph_audit.py
.venv/bin/python scripts/audit_structural_bounds.py
.venv/bin/python scripts/analyze_structural_real_graph.py
```

These commands independently verify 3,239 original-graph rational BFS values
and 240 method outputs, check 49,152 coverage and 1,293 directed-graph
cardinality cells, and compare all 48 exact integer blossom surrogates against
an independent subset dynamic program. All 13 tests pass, including a
matching-priority regression beyond float64 integer precision.

To repeat the historical method comparisons into a new file (times will vary):

```bash
.venv/bin/python scripts/run_blockmatch_real_graph_audit.py run \
  --results-output results/blockmatch_real_graph_rerun.jsonl
```

For deterministic vector figures, use a separate environment with
`requirements-paper.txt` (ReportLab 4.4.9), then:

```bash
python3 scripts/generate_supplement_assets.py
```

This regenerates the exact-optimum heatmap, error survival, bound comparison,
theoretical envelope, and supplementary table. The anonymous package includes
all algorithms, protocols, raw supplement records, verifiers, citation metadata,
and figure scripts. The original frozen implementation hash is unchanged.
