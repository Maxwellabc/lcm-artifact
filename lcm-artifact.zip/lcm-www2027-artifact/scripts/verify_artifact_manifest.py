"""Verify files against ARTIFACT_MANIFEST.json after extracting the archive."""
import argparse
import hashlib
import json
from pathlib import Path


MACOS_USER_PATH_MARKER = b"/" + b"Users" + b"/"
WORKSPACE_TOKEN = b"<WORKSPACE>"


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--strict", action="store_true",
        help="also reject files not listed in the manifest",
    )
    args = parser.parse_args(argv)
    root = args.root.resolve()
    manifest_path = root / "ARTIFACT_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text())
    failures = []
    expected = set()
    transformed_records = set()
    for record in manifest["files"]:
        relative = Path(record["path"])
        if relative.as_posix() in expected:
            failures.append("duplicate manifest record: %s" % relative.as_posix())
        expected.add(relative.as_posix())
        path = root / relative
        if not path.is_file():
            failures.append("missing: %s" % relative.as_posix())
            continue
        if path.stat().st_size != record["bytes"]:
            failures.append("size mismatch: %s" % relative.as_posix())
        elif sha256(path) != record["sha256"]:
            failures.append("hash mismatch: %s" % relative.as_posix())
        else:
            payload = path.read_bytes()
            if MACOS_USER_PATH_MARKER in payload:
                failures.append("absolute macOS user path: %s" % relative.as_posix())
            if record.get("transformation") == "redact_absolute_workspace_path":
                transformed_records.add(relative.as_posix())
                source_hash = record.get("source_sha256", "")
                if (len(source_hash) != 64
                        or any(character not in "0123456789abcdef"
                               for character in source_hash)):
                    failures.append("invalid source hash: %s" % relative.as_posix())
                if WORKSPACE_TOKEN not in payload:
                    failures.append("missing workspace token: %s" % relative.as_posix())
    if manifest.get("file_count") != len(manifest.get("files", [])):
        failures.append("manifest file_count mismatch")
    declared_transformed = set(
        manifest.get("transformations", {})
        .get("redact_absolute_workspace_path", {})
        .get("files", [])
    )
    if declared_transformed != transformed_records:
        failures.append("transformation file list mismatch")
    if args.strict:
        actual = {
            path.relative_to(root).as_posix()
            for path in root.rglob("*")
            if path.is_file() and path != manifest_path
        }
        for relative in sorted(actual - expected):
            failures.append("unlisted: %s" % relative)
    result = {
        "status": "ok" if not failures else "failed",
        "files_checked": len(expected),
        "strict": args.strict,
        "failures": failures,
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
