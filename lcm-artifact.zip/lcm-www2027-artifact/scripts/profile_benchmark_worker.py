"""Build one distance profile in an isolated process and emit one JSON row."""
import argparse
import hashlib
import json
import platform
import random
import resource
import sys
import tracemalloc
from pathlib import Path
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lcm.graph import load_author_targets, load_edgelist  # noqa: E402
from lcm.objective import reverse_distances  # noqa: E402
from lcm.profile import BudgetProfile, ProfileRow, build_budget_profile  # noqa: E402


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def rss_bytes():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return value if platform.system() == "Darwin" else value * 1024


def build_full_profile(graph, target, budget):
    """Reference profile made by one reverse BFS per target in-neighbor."""
    candidates = tuple(graph.in_neighbors[target])
    rows = [[] for _ in range(graph.n)]
    propagation_states = 0
    for label, candidate in enumerate(candidates):
        distances = reverse_distances(graph, candidate, omit_vertex=target)
        for source, distance in enumerate(distances):
            if source != target and distance >= 0:
                rows[source].append((distance, label))
                propagation_states += 1
    profile_rows = []
    for source, labels in enumerate(rows):
        if not labels:
            continue
        labels.sort(key=lambda item: (item[0], item[1]))
        profile_rows.append(ProfileRow(
            source=source,
            candidate_indices=tuple(label for _, label in labels),
            values=tuple(1.0 / (distance + 1) for distance, _ in labels),
        ))
    return BudgetProfile(
        target=target,
        budget=budget,
        candidates=candidates,
        rows=tuple(profile_rows),
        accepted_labels=propagation_states,
        propagation_attempts=propagation_states,
    )


def implementation_hash():
    digest = hashlib.sha256()
    for path in sorted((ROOT / "lcm").glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--graph", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--target-index", type=int, required=True)
    parser.add_argument("--budget-ratio", type=float, required=True)
    parser.add_argument("--mode", choices=("compressed", "full"), required=True)
    parser.add_argument("--probes", type=int, default=5)
    args = parser.parse_args(argv)

    total_started = perf_counter()
    load_started = perf_counter()
    graph = load_edgelist(args.graph)
    targets = load_author_targets(args.targets)
    target = targets[args.target_index]
    load_seconds = perf_counter() - load_started
    degree = graph.indegree(target)
    budget = int(degree * args.budget_ratio)

    tracemalloc.start()
    build_started = perf_counter()
    if args.mode == "compressed":
        profile = build_budget_profile(graph, target, budget)
    else:
        profile = build_full_profile(graph, target, budget)
    build_seconds = perf_counter() - build_started
    python_current, python_peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    rng = random.Random(20270000 + args.target_index * 10_000 + budget)
    probe_objectives = []
    for _ in range(args.probes):
        deleted = rng.sample(list(profile.candidates), budget)
        probe_objectives.append(profile.objective(deleted))
    row = {
        "status": "ok",
        "mode": args.mode,
        "graph": str(args.graph),
        "graph_sha256": sha256(args.graph),
        "implementation_hash": implementation_hash(),
        "n": graph.n,
        "m": graph.m,
        "target_index": args.target_index,
        "target_internal_id": target,
        "indegree": degree,
        "budget_ratio": args.budget_ratio,
        "budget": budget,
        "rows": len(profile.rows),
        "stored_labels": sum(len(row.values) for row in profile.rows),
        "accepted_labels": profile.accepted_labels,
        "propagation_attempts": profile.propagation_attempts,
        "load_seconds": load_seconds,
        "build_seconds": build_seconds,
        "total_seconds": perf_counter() - total_started,
        "tracemalloc_current_bytes": python_current,
        "tracemalloc_peak_bytes": python_peak,
        "peak_process_rss_bytes": rss_bytes(),
        "probe_objectives": probe_objectives,
        "python": platform.python_version(),
        "platform": platform.platform(),
    }
    print(json.dumps(row, sort_keys=True))


if __name__ == "__main__":
    main()
