"""Memory-bounded utilities for the separately frozen scalability extension."""
