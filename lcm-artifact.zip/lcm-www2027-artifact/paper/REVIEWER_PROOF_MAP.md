# Anonymous proof and evidence map, 2026-10-15

Current PDF SHA256: `80adadbaec78b4725043a710e4297ce473c38e06b2f8c3c3d3c8e49d2e27610b`.

Locations are generated from the compiled labels. This is internal orientation,
not an independent expert endorsement.

| Claim | Compiled number / page | Source line |
|---|---|---|
| Last-entry identity | 1 / 2 | main.tex:280 |
| Budget-exact profile | 3.1 / 2 | main.tex:292 |
| Profile construction | 3.2 / 3 | main.tex:331 |
| Singleton bound | 4.1 / 3 | main.tex:371 |
| BlockMatch base guarantee | 4.2 / 4 | main.tex:409 |
| Marginal-floor theorem | 4.4 / 4 | main.tex:448 |
| Tight block branch | 4.3 / 4 | main.tex:424 |
| Fallback dominance | 4.5 / 4 | main.tex:497 |
| Cardinality-hit certificate | 5.1 / 5 | main.tex:553 |
| Complete marginal-floor proof | A.1 / 9 | main.tex:978 |
| Exact-optimum results | 9 / 10 | main.tex:966 |
| Exploratory comparison plots | 5 / 11 | main.tex:958 |

The full parity proof handles a selected triple outside the optimum. The
curvature/MUB relationship is credited, and no universal dominance over the
relative-curvature bound is claimed. Integer DP and integer blossom agree
on all 48 supplement surrogates; 3,239 feasible sets and 240 outputs are
independently verified using rational original-graph BFS.

Supplementary data are separate from the 198 frozen primary cells; see
`REFERENCE_AUDIT_2026-10-15.md`, `STRUCTURAL_BOUND_AUDIT.json`, and
`STRUCTURAL_REAL_GRAPH_SUMMARY.json` in the anonymous artifact.
