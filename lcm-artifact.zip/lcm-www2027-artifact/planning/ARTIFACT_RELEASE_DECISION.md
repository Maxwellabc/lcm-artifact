# Artifact release and licensing decision

Status: prepared 2026-09-27; no public release or license grant has been made.
The decision is intentionally deferred until the author approves it or the
paper is accepted.

## Recommended release

Use the MIT License for original implementation and experiment scripts, with
copyright held by the author name approved in the private release record. Add
a short third-party notice that separates:

- ACM `acmart` sources and `acmart.cls`: LaTeX Project Public License 1.3 or
  later, as stated in `paper/acmart-source/acmart.dtx`;
- `paper/ACM-Reference-Format.bst`: public domain, as stated in its header;
- NetworkX, NumPy, and SciPy: installed dependencies, not redistributed in the
  archive;
- public graph data and downloaded archives: not redistributed; acquisition
  URLs, citations, and hashes only;
- the WWW 2024 upstream repository snapshot: excluded because the fixed
  upstream commit has no LICENSE file.

MIT is the simplest fit for a small research implementation and does not
conflict with the separately identified LPPL/public-domain template files.
This recommendation is not a legal opinion and does not authorize publishing
the package.

## Files to add after author approval

1. Root `LICENSE` containing the standard MIT text and the approved copyright
   year/name.
2. Root `THIRD_PARTY_NOTICES.md` containing the boundaries above and direct
   source/license references.
3. `license` metadata in `pyproject.toml`, using the syntax supported by the
   selected packaging toolchain.
4. A release README sentence that the MIT grant covers original code only;
   generated results, paper text, and third-party materials retain their own
   stated terms.

After these changes, rebuild the deterministic archive, inspect the manifest,
run the clean extraction smoke test, and use
`scripts/build_release_zip.py` to produce the deterministic single-file ZIP
required by the prepared Zenodo/Software Heritage workflow. The release
builder already selects the four optional root metadata/license files when
present. Because the approved license and citation records intentionally name
the author, invoke the TAR builder with `--no-identity-marker-check` only for
the accepted, de-anonymized public release; forbidden-member and absolute-path
checks remain active. Deposit the exact licensed ZIP in a DOI-granting
repository and record its DOI and SHA-256. The OpenReview PDF submission does
not require or upload this artifact at the current stage.

## Decision record

- Code license approved: [MIT / Apache-2.0 / other / not yet]
- Copyright line approved:
- Third-party notice reviewed: [yes/no]
- Archival repository:
- DOI:
- Public release timestamp:
- Released archive SHA-256:
