# Conflict-Certificate Sensitivity Audit

Declared after the aggregate frozen quality summary was inspected. The subset is a systematic first-three-target sensitivity audit, not blind confirmatory evidence.

| Dataset | Cells | Improved | Median LB increase | Median gap before | Median gap after | Median audit sec |
|---|---:|---:|---:|---:|---:|---:|
| test-ciaodvd | 3 | 0 | 0.0000 | 8.37% | 8.37% | 53.42 |
| test-moreno | 3 | 2 | 0.3018 | 8.70% | 8.35% | 80.79 |
| test-polblogs | 3 | 2 | 1.3359 | 5.20% | 4.88% | 50.89 |
| test-twitter | 3 | 2 | 0.5904 | 9.17% | 9.01% | 91.04 |

Across 12 cells, conflicts improve 6 certificates. The median gap reduction over all cells is 0.050 percentage points; the maximum is 0.429 points. Median total audit time is 67.62 seconds.

This is a post-summary, systematically selected sensitivity analysis. It quantifies an established conflict/closure adaptation and its cost; it is not part of the blind primary comparison and is not presented as a new general inequality.
