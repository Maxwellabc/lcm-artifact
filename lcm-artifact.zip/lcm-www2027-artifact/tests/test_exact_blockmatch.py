import random
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'scripts'))
from blockmatch.exact import block_match_exact
from audit_structural_bounds import matching_value


class ExactMatchingTests(unittest.TestCase):
    def test_integer_priorities_beyond_float_precision(self):
        # An integer-only oracle exposes gaps which float64 cannot represent.
        base = 2 ** 57
        weights = [base + 4, base + 3, base + 2, base + 1]
        value = lambda selected: sum(weights[i] for i in selected)
        answer = block_match_exact(range(4), 2, value)
        self.assertEqual(answer.selected, frozenset([2, 3]))
        self.assertEqual(answer.objective, 2 * base + 3)

    def test_blossom_against_independent_integer_dp_both_parities(self):
        rng = random.Random(481516)
        for _ in range(40):
            d = rng.randrange(4, 9)
            sets = [rng.randrange(256) for _ in range(d)]
            values = []
            for mask in range(1 << d):
                union = 0
                for i in range(d):
                    if mask >> i & 1:
                        union |= sets[i]
                values.append(bin(mask).count('1') * 3 + bin(union).count('1'))
            for k in range(1, d + 1):
                result = block_match_exact(range(d), k,
                    lambda selected: values[sum(1 << i for i in selected)])
                expected, _ = matching_value(values, d, k)
                self.assertEqual(result.surrogate, expected)
                self.assertEqual(len(result.selected), k)

if __name__ == '__main__':
    unittest.main()
