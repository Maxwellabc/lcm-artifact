# Exact Certificate Audit on Frozen Test Targets

Implementation hash: `6f9f44a2750ac2e7a90a253606be686aa1b8352adcdcd8d05c605ed4c810cf25`. Certificate cells: 198; errors: 0.

| Dataset | b/d | Cells | Exact hits | Frozen hybrid optimal on hits | Median numerical gap | Median audit sec |
|---|---:|---:|---:|---:|---:|---:|
| test-ciaodvd | 0.25 | 15 | 0 | 0 | 0.0062 | 2.27 |
| test-ciaodvd | 0.50 | 15 | 0 | 0 | 0.0414 | 5.43 |
| test-ciaodvd | 0.75 | 15 | 0 | 0 | 0.0837 | 11.87 |
| test-moreno | 0.25 | 16 | 0 | 0 | 0.0015 | 2.21 |
| test-moreno | 0.50 | 16 | 3 | 3 | 0.0039 | 6.84 |
| test-moreno | 0.75 | 16 | 2 | 2 | 0.0381 | 14.77 |
| test-polblogs | 0.25 | 17 | 2 | 2 | 0.0003 | 1.56 |
| test-polblogs | 0.50 | 17 | 0 | 0 | 0.0259 | 3.36 |
| test-polblogs | 0.75 | 17 | 0 | 0 | 0.0577 | 6.49 |
| test-twitter | 0.25 | 18 | 2 | 2 | 0.0015 | 7.41 |
| test-twitter | 0.50 | 18 | 0 | 0 | 0.0279 | 18.62 |
| test-twitter | 0.75 | 18 | 0 | 0 | 0.0616 | 30.45 |

Across audited cells, 9/198 had an exact cardinality hit; the frozen hybrid matched the proved optimum in 9/9 hits.
