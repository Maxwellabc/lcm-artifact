# Frozen Test Results

Protocol: `configs/FROZEN_TEST_PROTOCOL.json`; implementation hash `6f9f44a2750ac2e7a90a253606be686aa1b8352adcdcd8d05c605ed4c810cf25`; runner `2026-09-26-resume-v4`.

Complete cells: 198/198. Missing or partial cells: 0. Logged error records: 0.

| Dataset | n/m | b/d | Targets | Wins / ties / losses | Median gain | Mean gain [95% target-bootstrap CI] | Best gain | Worst gain | Median certified gap | Median pipeline sec | Peak RSS MiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| test-ciaodvd | 4658/40133 | 0.25 | 15 | 0/15/0 | 0.0000% | 0.0000% [0.0000%, 0.0000%] | 0.0000% | 0.0000% | 0.62% | 7.62 | 99.1 |
| test-ciaodvd | 4658/40133 | 0.50 | 15 | 1/14/0 | 0.0000% | 0.0020% [0.0000%, 0.0059%] | 0.0297% | 0.0000% | 4.14% | 14.01 | 99.1 |
| test-ciaodvd | 4658/40133 | 0.75 | 15 | 1/14/0 | 0.0000% | 0.0040% [0.0000%, 0.0119%] | 0.0597% | 0.0000% | 8.37% | 26.85 | 99.1 |
| test-moreno | 1224/19022 | 0.25 | 16 | 1/15/0 | 0.0000% | 0.0017% [0.0000%, 0.0051%] | 0.0272% | 0.0000% | 0.15% | 5.93 | 84.4 |
| test-moreno | 1224/19022 | 0.50 | 16 | 5/11/0 | 0.0000% | 0.0244% [0.0026%, 0.0586%] | 0.2469% | 0.0000% | 0.39% | 14.90 | 84.4 |
| test-moreno | 1224/19022 | 0.75 | 16 | 0/16/0 | 0.0000% | 0.0000% [0.0000%, 0.0000%] | 0.0000% | 0.0000% | 3.81% | 25.17 | 84.4 |
| test-polblogs | 1224/33430 | 0.25 | 17 | 1/16/0 | 0.0000% | 0.0013% [0.0000%, 0.0039%] | 0.0223% | 0.0000% | 0.03% | 5.70 | 108.3 |
| test-polblogs | 1224/33430 | 0.50 | 17 | 3/14/0 | 0.0000% | 0.0233% [0.0000%, 0.0611%] | 0.2662% | 0.0000% | 2.59% | 13.27 | 108.3 |
| test-polblogs | 1224/33430 | 0.75 | 17 | 4/13/0 | 0.0000% | 0.0462% [0.0005%, 0.1306%] | 0.6959% | 0.0000% | 5.77% | 18.77 | 108.3 |
| test-twitter | 465017/834797 | 0.25 | 18 | 2/16/0 | 0.0000% | 0.0099% [0.0000%, 0.0278%] | 0.1444% | 0.0000% | 0.15% | 13.96 | 417.2 |
| test-twitter | 465017/834797 | 0.50 | 18 | 3/15/0 | 0.0000% | 0.0255% [0.0000%, 0.0652%] | 0.3098% | 0.0000% | 2.79% | 30.89 | 417.2 |
| test-twitter | 465017/834797 | 0.75 | 18 | 1/17/0 | 0.0000% | 0.0064% [0.0000%, 0.0193%] | 0.1159% | 0.0000% | 6.16% | 46.86 | 417.2 |

Across complete cells: 22 strict wins, 176 ties, 0 losses; median paired relative gain 0.0000% and mean 0.0124%. Among strict wins, the median gain was 0.0406% and the maximum was 0.6959%.

Strongest baseline frequency: algorithm1=1, greedy=22, multi_start_one_swap=101, overlap_search=52, parametric_repair=22.

Selected final components: multi_start_one_swap=158, one_swap=37, overlap_search=3.

Pipeline time includes profile construction plus A1, Greedy, singleton, parametric repair, overlap search, and hybrid polishing because those components are required by the frozen candidate. Graph load time is reported in raw records and is not multiplied into each cell.

## Pairwise component comparisons

| Comparator | Wins / ties / losses | Median improvement | Mean improvement | Maximum improvement |
|---|---:|---:|---:|---:|
| algorithm1 | 197/1/0 | 2.985% | 3.385% | 10.525% |
| degree | 198/0/0 | 4.441% | 6.130% | 33.485% |
| greedy | 175/23/0 | 0.496% | 1.939% | 22.359% |
| singleton_sort | 197/1/0 | 2.880% | 3.348% | 10.525% |
| parametric_repair | 132/66/0 | 0.044% | 0.224% | 1.958% |
| multi_start_one_swap | 78/120/0 | 0.000% | 0.158% | 1.744% |
| overlap_search | 30/168/0 | 0.000% | 0.053% | 1.744% |
