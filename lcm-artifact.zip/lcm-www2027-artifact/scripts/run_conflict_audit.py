"""Run exact cross-source conflict Lagrangian bounds on selected cells."""
import argparse
import hashlib
import json
import sys
import traceback
from fractions import Fraction
from pathlib import Path
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lcm.conflict import (  # noqa: E402
    build_prefix_triggers,
    separated_conflict_bound,
    search_conflict_lagrangian_bound,
    select_conflict_matching,
)
from lcm.graph import load_author_targets, load_edgelist  # noqa: E402
from lcm.profile import build_budget_profile  # noqa: E402


def implementation_hash():
    digest = hashlib.sha256()
    for path in sorted((ROOT / "lcm").glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--graph", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--target-indices", type=int, nargs="+", required=True)
    parser.add_argument("--budget-ratios", type=float, nargs="+", default=[0.25, 0.5, 0.75])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--iterations", type=int, default=16)
    parser.add_argument("--pool-size", type=int, default=500)
    parser.add_argument("--max-pairs", type=int, default=100)
    parser.add_argument("--separated", action="store_true")
    parser.add_argument("--protocol", type=Path)
    args = parser.parse_args(argv)
    graph = load_edgelist(args.graph)
    graph_hash = hashlib.sha256(args.graph.read_bytes()).hexdigest()
    code_hash = implementation_hash()
    if args.protocol is not None:
        protocol = json.loads(args.protocol.read_text())
        if code_hash != protocol["implementation_hash"]:
            raise RuntimeError("implementation does not match frozen protocol")
    targets = load_author_targets(args.targets)
    completed = set()
    if args.output.exists():
        for line in args.output.read_text().splitlines():
            row = json.loads(line)
            if row.get("status") == "ok":
                completed.add((
                    row["target_index"], row["budget"], row.get("graph_sha256"),
                    row.get("implementation_hash"), row.get("iterations"),
                    row.get("pool_size"), row.get("max_pairs"),
                    row.get("separated"),
                ))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("a", encoding="utf-8") as handle:
        for target_index in args.target_indices:
            target = targets[target_index]
            degree = graph.indegree(target)
            for ratio in args.budget_ratios:
                budget = int(degree * ratio)
                key = (
                    target_index, budget, graph_hash, code_hash,
                    args.iterations, args.pool_size, args.max_pairs,
                    args.separated,
                )
                if key in completed:
                    continue
                started = perf_counter()
                context = {
                    "graph_sha256": graph_hash,
                    "implementation_hash": code_hash,
                    "n": graph.n,
                    "m": graph.m,
                    "target_index": target_index,
                    "target_internal_id": target,
                    "indegree": degree,
                    "budget_ratio": ratio,
                    "budget": budget,
                    "pool_size": args.pool_size,
                    "max_pairs": args.max_pairs,
                    "iterations": args.iterations,
                    "separated": args.separated,
                }
                try:
                    profile = build_budget_profile(graph, target, budget)
                    triggers, _ = build_prefix_triggers(profile)
                    if args.separated:
                        separated = separated_conflict_bound(
                            profile, iterations=args.iterations,
                            pool_size=args.pool_size, max_pairs=args.max_pairs,
                        )
                        certificate = separated.best
                        penalties = separated.penalties
                        base_lower_bound = separated.base.lower_bound
                        strength = separated.strength
                        separation_deleted_count = (
                            separated.separation_cut.deleted_count
                            if separated.separation_cut is not None else None
                        )
                    else:
                        penalties = select_conflict_matching(
                            profile, triggers, pool_size=args.pool_size,
                            max_pairs=args.max_pairs,
                        )
                        certificate = search_conflict_lagrangian_bound(
                            profile, penalties, iterations=args.iterations
                        )
                        base_lower_bound = None
                        strength = Fraction(1)
                        separation_deleted_count = None
                    record = {
                    **context,
                    "trigger_count": len(triggers),
                    "conflict_count": len(penalties),
                    "conflict_mass": str(sum(
                        (penalty.multiplier for penalty in penalties), Fraction(0)
                    )),
                    "lower_bound": str(certificate.lower_bound),
                    "lower_bound_float": float(certificate.lower_bound),
                    "base_lower_bound": (str(base_lower_bound)
                                         if base_lower_bound is not None else None),
                    "base_lower_bound_float": (float(base_lower_bound)
                                               if base_lower_bound is not None else None),
                    "improvement": (float(certificate.lower_bound - base_lower_bound)
                                    if base_lower_bound is not None else None),
                    "selected_strength": str(strength),
                    "separation_deleted_count": separation_deleted_count,
                    "cardinality_multiplier": str(certificate.cardinality_multiplier),
                    "mincut_deleted_count": certificate.deleted_count,
                    "scale": certificate.scale,
                    "nodes": certificate.nodes,
                    "arcs": certificate.arcs,
                    "seconds": perf_counter() - started,
                    "status": "ok",
                    }
                except Exception as error:
                    record = {
                        **context,
                        "status": "error",
                        "error": repr(error),
                        "traceback": traceback.format_exc(),
                        "seconds": perf_counter() - started,
                    }
                handle.write(json.dumps(record, sort_keys=True) + "\n")
                handle.flush()
                print(json.dumps(record, sort_keys=True))


if __name__ == "__main__":
    main()
