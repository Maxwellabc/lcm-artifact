# WWW 2027 submission metadata worksheet

This is the reusable anonymous template. The populated authoritative record is
`private/submission_metadata.md`; do not duplicate author identity or receipt
data here.  Recheck and freeze the private record before **2026-10-17 18:00
Beijing time**. A populated copy must stay outside the anonymous paper and
release artifact.

## Paper metadata

- Title: Sharper Approximation and Certified Search for Local Harmonic
  Centrality Minimization
- Track: Graph Algorithms and Modeling for the Web
- Abstract: the current plain-text copy is in `planning/OPENREVIEW_ENTRY.md`;
  refresh it from `paper/main.tex` after all theory-review corrections close.
- Keywords: harmonic centrality; graph modification; approximation
  algorithms; minimum cut; optimality certificates

## Authors in immutable order

| Order | Full name | Affiliation | Institutional email | OpenReview profile complete? | Conflicts checked? |
|---:|---|---|---|---|---|
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |
| 3 |  |  |  |  |  |

Delete unused rows or add rows before the abstract deadline. Obtain explicit
approval of order, spelling, affiliation, abstract, and conflicts from every
author; save that approval privately.

## Artifact decisions

- OpenReview paper license: CC BY 4.0 (fixed in the live form; checked
  2026-09-27)
- Code license selected: [MIT recommended / Apache-2.0 / other]
- License compatibility reviewed for bundled original code: [yes/no]
- Archival repository: [Zenodo / institutional repository / other]
- DOI: [populate after deposit]
- Anonymous review-stage artifact permitted by CFP: [verified date/source]

## Submission receipt

- OpenReview submission ID:
- Abstract submitted timestamp and local receipt:
- Final PDF submitted timestamp:
- Downloaded PDF SHA256:
- Confirmation receipt path:

These fields intentionally remain blank in the public template. Their current
values and the authenticated receipt are stored under `private/`.
