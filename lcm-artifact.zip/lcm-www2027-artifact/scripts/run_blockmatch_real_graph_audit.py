"""Post-freeze exploratory BlockMatch audit; never edits the frozen protocol."""
import argparse
import hashlib
import json
import math
import platform
import sys
from itertools import combinations
from pathlib import Path
from time import perf_counter

import networkx as nx
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from blockmatch import block_match
from lcm.algorithms import algorithm1, degree_deletion, greedy_deletion
from lcm.algorithms import overlap_search, singleton_sort
from lcm.graph import load_edgelist
from lcm.objective import harmonic_after_deletions, reverse_distances
from lcm.profile import build_budget_profile

PROTOCOL = ROOT / "configs/BLOCKMATCH_REAL_GRAPH_PROTOCOL.json"
ROWS = ROOT / "results/blockmatch_real_graph.jsonl"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def code_hash():
    digest = hashlib.sha256()
    for path in sorted((ROOT / "lcm").glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def prepare():
    if PROTOCOL.exists() or ROWS.exists():
        raise RuntimeError("refusing to replace an existing preregistration or results")
    graphs = []
    for name in ("moreno", "ciaodvd", "polblogs", "twitter"):
        config = json.loads((ROOT / f"configs/development-hybrid-{name}.json").read_text())
        path = ROOT / config["graph"]
        graph = load_edgelist(path)
        # All prior target IDs are excluded; no outcome is used in selection.
        excluded = set(map(int, (ROOT / config["targets_file"]).read_text().split()))
        targets = []
        for lower, upper in ((4, 5), (6, 7), (8, 9), (10, 12)):
            eligible = [v for v in range(graph.n)
                        if lower <= graph.indegree(v) <= upper and v not in excluded]
            if not eligible:
                raise RuntimeError(f"empty target stratum: {name} {lower} {upper}")
            target = min(eligible, key=lambda v: hashlib.sha256(
                f"blockmatch-real-graph-2026-10-11|{name}|{graph.labels[v]}".encode()
            ).hexdigest())
            targets.append({"target": target, "label": graph.labels[target],
                            "indegree": graph.indegree(target),
                            "stratum": [lower, upper], "eligible": len(eligible)})
        graphs.append({"name": name, "graph": config["graph"],
                       "sha256": sha(path), "n": graph.n, "m": graph.m,
                       "targets": targets})
    protocol = {
        "date": "2026-10-11 Asia/Shanghai",
        "status": "preregistered_before_any_new_objective",
        "scope": "post-freeze exploratory low-indegree real-graph audit",
        "selection": "one SHA256-minimum target per degree stratum; exclude all prior target IDs",
        "budget_ratios": [0.25, 0.5, 0.75],
        "budget_rule": "floor(ratio * indegree)",
        "methods": ["blockmatch", "algorithm1", "singleton_sort", "greedy", "overlap_search"],
        "overlap_parameters": {"swap_rounds": 100, "exchange_rounds": 10},
        "exact_optimum": "enumerate every retained k-set with integer-scaled rational distances",
        "max_degree": 12, "max_optimum_combinations": 924,
        "oracle": "all candidates, not a budget-truncated profile; aggregate identical full distance rows",
        "timing": "per-cell standalone graph-load + full method preprocessing + solve + independent final BFS; shared inputs charged again to each method",
        "limitations": ["degree-stratified targets do not represent the high-indegree frozen evaluation",
                        "no confirmatory statistics or retuning", "single runtime observation per cell"],
        "lcm_implementation_hash": code_hash(),
        "blockmatch_sha256": sha(ROOT / "blockmatch/algorithm.py"),
        "runner_sha256": sha(Path(__file__)),
        "python": platform.python_version(), "numpy": np.__version__, "networkx": nx.__version__,
        "graphs": graphs,
    }
    PROTOCOL.write_text(json.dumps(protocol, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"protocol": PROTOCOL.name, "targets": 16, "cells": 48}), flush=True)


class FullRetentionOracle:
    """Exact rational g(R), including small blocks outside the deletion budget."""
    def __init__(self, graph, target):
        self.candidates = tuple(graph.in_neighbors[target])
        self.positions = {u: i for i, u in enumerate(self.candidates)}
        distances = np.empty((graph.n, len(self.candidates)), dtype=np.int32)
        sentinel = graph.n + 1
        for column, candidate in enumerate(self.candidates):
            row = np.asarray(reverse_distances(graph, candidate, omit_vertex=target), dtype=np.int32)
            distances[:, column] = np.where(row >= 0, row, sentinel)
        patterns, counts = np.unique(distances, axis=0, return_counts=True)
        reachable = patterns.min(axis=1) < sentinel
        self.patterns, self.counts = patterns[reachable], counts[reachable]
        self.sentinel = sentinel
        finite = self.patterns[self.patterns < sentinel]
        self.scale = 1
        for distance in np.unique(finite):
            self.scale = math.lcm(self.scale, int(distance) + 1)

    def integer(self, retained):
        if not retained:
            return 0
        columns = [self.positions[u] for u in retained]
        minimum = self.patterns[:, columns].min(axis=1)
        denominators = np.where(minimum < self.sentinel, minimum + 1, 0)
        # Integral source counts <= n are exactly representable by float64.
        histogram = np.bincount(denominators, weights=self.counts)
        return sum(int(histogram[i]) * (self.scale // int(i))
                   for i in np.flatnonzero(histogram) if i)

    def __call__(self, retained):
        return self.integer(retained) / self.scale


def run():
    protocol = json.loads(PROTOCOL.read_text())
    if protocol.get("export", {}).get("public_runner_sha256", protocol["runner_sha256"]) != sha(Path(__file__)):
        raise RuntimeError("runner changed after preregistration")
    if protocol["lcm_implementation_hash"] != code_hash():
        raise RuntimeError("LCM implementation changed")
    if protocol["blockmatch_sha256"] != sha(ROOT / "blockmatch/algorithm.py"):
        raise RuntimeError("BlockMatch implementation changed")
    existing = [json.loads(line) for line in ROWS.read_text().splitlines()] if ROWS.exists() else []
    protocol_sha = protocol.get("export", {}).get("source_protocol_sha256", sha(PROTOCOL))
    if any(row["protocol_sha256"] != protocol_sha for row in existing):
        raise RuntimeError("result protocol mismatch")
    complete = {(row["graph"], row["target"], row["budget"]) for row in existing}
    for graph_record in protocol["graphs"]:
        path = ROOT / graph_record["graph"]
        if sha(path) != graph_record["sha256"]:
            raise RuntimeError("graph hash mismatch")
        started = perf_counter()
        graph = load_edgelist(path)
        load_seconds = perf_counter() - started
        for target_record in graph_record["targets"]:
            target, d = target_record["target"], target_record["indegree"]
            budgets = [int(ratio * d) for ratio in protocol["budget_ratios"]]
            if all((graph_record["name"], target, b) in complete for b in budgets):
                continue
            started = perf_counter()
            oracle = FullRetentionOracle(graph, target)
            oracle_seconds = perf_counter() - started
            candidates = frozenset(oracle.candidates)
            for ratio, b in zip(protocol["budget_ratios"], budgets):
                key = (graph_record["name"], target, b)
                if key in complete:
                    continue
                k = d - b
                started = perf_counter()
                profile = build_budget_profile(graph, target, b)
                profile_seconds = perf_counter() - started
                a1 = algorithm1(graph, profile)
                singleton, _ = singleton_sort(graph, profile)
                greedy = greedy_deletion(profile)
                degree = degree_deletion(graph, profile)
                overlap = overlap_search(profile, [a1, singleton, greedy, degree],
                                         **protocol["overlap_parameters"])
                started = perf_counter()
                matching = block_match(oracle.candidates, k, oracle)
                matching_seconds = perf_counter() - started
                selections = {result.method: (frozenset(result.deleted),
                              result.objective, result.solve_seconds)
                              for result in (a1, singleton, greedy, overlap)}
                selections["blockmatch"] = (candidates - matching.selected,
                                             matching.objective, matching_seconds)
                methods = {}
                for method, (deleted, value, solve_seconds) in selections.items():
                    assert len(deleted) == b
                    retained = candidates - deleted
                    exact = oracle.integer(retained)
                    started = perf_counter()
                    checked = harmonic_after_deletions(graph, target, deleted)
                    verify_seconds = perf_counter() - started
                    tolerance = 1e-8 * max(1.0, checked)
                    assert abs(checked - exact / oracle.scale) <= tolerance
                    assert abs(checked - value) <= tolerance
                    prep = oracle_seconds if method == "blockmatch" else profile_seconds
                    dependencies = (sum(result.solve_seconds for result in
                                        (a1, singleton, greedy, degree))
                                    if method == "overlap_search" else 0.0)
                    methods[method] = {
                        "deleted": sorted(deleted), "objective": checked,
                        "objective_numerator": str(exact), "preprocess_seconds": prep,
                        "solve_seconds": solve_seconds, "dependency_seconds": dependencies,
                        "verify_seconds": verify_seconds,
                        "standalone_seconds": load_seconds + prep + solve_seconds + dependencies + verify_seconds,
                        "solver_seconds_including_preprocess": prep + solve_seconds + dependencies + verify_seconds,
                        "oracle_bfs_discrepancy": abs(checked - exact / oracle.scale),
                    }
                started = perf_counter()
                optimum_numerator, optimum_selected = min(
                    (oracle.integer(selected), selected)
                    for selected in combinations(oracle.candidates, k))
                enumeration_seconds = perf_counter() - started
                optimum_bfs = harmonic_after_deletions(graph, target, candidates - set(optimum_selected))
                assert abs(optimum_bfs - optimum_numerator / oracle.scale) <= 1e-8 * max(1.0, optimum_bfs)
                bm_numerator = int(methods["blockmatch"]["objective_numerator"])
                factor = 1 if k <= 3 else k // 2
                assert bm_numerator <= factor * optimum_numerator
                if k <= 3:
                    assert bm_numerator == optimum_numerator
                h_numerator = oracle.integer(candidates)
                assert bm_numerator <= h_numerator
                assert optimum_numerator >= k * oracle.scale
                for record in methods.values():
                    numerator = int(record["objective_numerator"])
                    assert numerator >= optimum_numerator
                    record["ratio_to_optimum"] = numerator / optimum_numerator
                    record["optimal"] = numerator == optimum_numerator
                row = {
                    "protocol_sha256": protocol_sha, "graph": graph_record["name"],
                    "target": target, "target_label": target_record["label"],
                    "d": d, "budget": b, "budget_ratio": ratio, "k": k,
                    "graph_load_seconds": load_seconds, "distance_signatures": len(oracle.patterns),
                    "rational_denominator": str(oracle.scale),
                    "optimum_numerator": str(optimum_numerator), "optimum": optimum_bfs,
                    "optimum_retained": list(optimum_selected), "optimum_combinations": math.comb(d, k),
                    "enumeration_seconds": enumeration_seconds,
                    "blockmatch_oracle_calls": matching.oracle_calls,
                    "blockmatch_matching_calls": matching.matching_calls,
                    "blockmatch_blocks": matching.blocks,
                    "h_original": h_numerator / oracle.scale,
                    "methods": methods, "status": "ok",
                }
                with ROWS.open("a") as handle:
                    handle.write(json.dumps(row, sort_keys=True) + "\n")
                print(json.dumps({"graph": row["graph"], "target": target, "d": d, "b": b,
                                  "k": k, "blockmatch_optimal": methods["blockmatch"]["optimal"],
                                  "blockmatch_ratio": methods["blockmatch"]["ratio_to_optimum"]}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("prepare", "run"))
    parser.add_argument("--results-output", type=Path)
    args = parser.parse_args()
    if args.results_output is not None:
        ROWS = args.results_output.resolve()
        ROWS.parent.mkdir(parents=True, exist_ok=True)
    prepare() if args.mode == "prepare" else run()
