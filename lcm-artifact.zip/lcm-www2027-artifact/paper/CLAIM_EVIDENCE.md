# Claim-to-evidence audit

This ledger separates proved, measured, inherited, and unresolved statements.
It should be checked before every paper revision.

| Paper claim | Type | Authoritative evidence | Current limit |
|---|---|---|---|
| Last-entry row-max identity is exact | Proved | `paper/main.tex`, `notes/theory-audit.md`; exhaustive/random comparison with independent BFS in `tests/test_core.py` | Directed, unweighted simple graphs as implemented |
| Top-`b+1` rows preserve every deletion set of size at most `b` | Proved | `thm:profile` in `paper/main.tex`; exhaustive subset checks in `tests/test_core.py`; zero padding covers rows whose reachable candidates are all deleted | One profile is tied to one budget; `b=d` handled separately |
| Multi-label construction uses `O((b+1)(n+m))` work and `O(n(b+1)+n+m)` space | Proved for the stated first-enqueue implementation | `lcm/profile.py`, queue/acceptance proof in `notes/theory-audit.md` | Hash tables and Python objects cause large constants; weighted graphs require Dijkstra |
| Singleton sorting is a `min{k,h/k} <= sqrt(h)` approximation and improves A1's `sqrt(2h)` factor at the same asymptotic cost | Proved plus inherited comparison | `thm:singleton` in `paper/main.tex`, A1 theorem in Miyauchi et al.; `notes/theory-audit.md`; exhaustive OPT checks in `tests/test_core.py` | Computing all singleton costs still takes one reverse BFS per candidate; the bound does not imply pointwise empirical dominance |
| BlockMatch is exact for `k<=3` and a `min{floor(k/2),h/k} <= sqrt(h/2)` approximation for `k>=2` | Proved; post-freeze reference and implementation audit | `thm:blockmatch` in `paper/main.tex`, `blockmatch/algorithm.py`, `notes/block-matching-candidate.md`, `results/BLOCK_MATCHING_CANDIDATE_AUDIT.json`; exhaustive audit of all 262,144 ordered six-set/three-element coverage systems at every cardinality (3,145,728 ordinary-plus-LCM cells), plus 120 blossom/reference agreement cells and at most one matching call per audited instance; Chen et al.'s full COCOON version and JCSS description use a distinct density/singleton construction; the 2026-10-04 structure- and citation-based sweep in `notes/literature-audit.md` found no identical result | Polynomial but much more expensive than SingletonSort; not part of the frozen real-graph experiment; finite audit and bounded search do not replace proof or establish novelty, an external expert novelty/proof review remains an optional quality check, not a WWW submission requirement |
| For every integer `k >= 4`, BlockMatch's `floor(k/2)` branch is asymptotically tight on DAGs | Proved | `prop:blockmatch-tight` in `paper/main.tex`; explicit `k=4,5,6,7` families in `results/BLOCK_MATCHING_CANDIDATE_AUDIT.json` | Tightness is for the block surrogate, not the scalable singleton hybrid |
| Quantized min-cut value is a valid lower bound | Proved and tested | `lcm/flow.py`; randomized `LB <= OPT` checks in `tests/test_core.py` | Capacity rounding can weaken the bound |
| A cardinality hit proves global optimality | Proved and exactly checked | `thm:hit` in `paper/main.tex`; rational reconstruction in `lcm/flow.py`; `results/EXACT_CERTIFICATE_TEST_REPORT.md` | Opportunistic: only 9/198 frozen cells hit |
| Profile exactness, SingletonSort's bound, lower-bound validity, and cardinality-hit equality hold on every directed simple graph with four vertices | Exhaustive computational audit | `scripts/exhaustive_small_graph_audit.py`, `results/EXHAUSTIVE_SMALL_GRAPH_AUDIT.json`: 4,096 graphs, 24,576 target-budget cells, 55,296 feasible deletion sets, 98,304 Lagrangian checks | Exhaustive finite audit supports but does not replace the general proofs |
| Hybrid never loses to its required starts and overlap fallback | Proved | `prop:fallback` in `paper/main.tex`, fallback code in `lcm/algorithms.py`, tests | Degree is an external comparator rather than a required start; it was never strongest in the frozen cells |
| Hybrid improves WWW 2024 A1 in 197/198 cells, median 2.985% | Frozen measurement | `results/TEST_REPORT.md`, hash-matched raw JSONL | Four datasets and selected high-indegree targets; no claim of universal dominance |
| Hybrid mean gain over A1 is 3.385% [3.142%, 3.623%] | Frozen measurement with target-clustered bootstrap | `scripts/generate_paper_assets.py`, `paper/generated/statistical_summary.tex`; 10,000 stratified replicates move all budgets of one target together | Interval quantifies the frozen target population, not graph sampling uncertainty |
| SingletonSort alone wins/ties/loses 40/114/44 against A1 | Frozen measurement | Hash-matched component objectives loaded by `scripts/generate_paper_assets.py` | Mean gain is 0.039%; theory is the contribution, not universal empirical dominance |
| On four additional large graphs, SingletonSort wins/ties/loses 6/52/2 against A1 over 60 sealed cells | Separately preregistered measurement | `configs/SCALABILITY_EXTENSION_PROTOCOL.json`, `results/scalability-extension.jsonl`, `results/SCALABILITY_EXTENSION_SUMMARY.json`, and strict audit in `scripts/summarize_scalability_extension.py` | Only five sealed targets per graph and only the two same-asymptotic sorting rules; median change is zero and the two losses must remain visible |
| All eight experiment graph bytes match their frozen hashes, and the four large-graph raw/self-loop/simple counts reconcile with the published simple graphs | Artifact check | `data/manifests/*.json`, `scripts/fetch_public_inputs.py --include-scalability --check-only`, `data/README.md`; fresh-extraction smoke record | Raw graph files are fetched from their public sources and are not redistributed; CiaoDVD remains explicitly labeled as a count-matching third-party copy |
| Hybrid adds little over strongest adapted components | Frozen negative result | 22 wins, 176 ties, 0 losses, 0.012% mean in `results/TEST_REPORT.md` | The no-loss behavior is partly structural because of fallback |
| Median certified gap is 2.26% overall | Frozen measurement | `results/TEST_REPORT.md`; exact audit independently validates hits | Gap rises with budget and reaches 10.58% in the worst cell |
| Compression helps at low budget but hurts at high budget in Python | Mechanism benchmark | `results/PROFILE_BENCHMARK_REPORT.md` | One target per dataset; not a population estimate; Twitter full reference intentionally omitted |
| Prefix exchange can escape a 1-swap local optimum | Exact synthetic mechanism | `results/SYNTHETIC_OVERLAP_REPORT.md`; 924-set exhaustive OPT | Constructed family, not a real-graph average or approximation theorem |
| Conflict separation sometimes improves certificates but has weak cost/benefit | Post-summary sensitivity result | `configs/CERTIFICATE_AUDIT_PROTOCOL.json`, `results/CONFLICT_SENSITIVITY_REPORT.md` | 6/12 improve; median gap reduction 0.050 points for 67.6 s median audit time; general technique is prior art |
| The combination is novel enough for WWW 2027 | Research judgment supported by internal audit | `notes/literature-audit.md`; latest internal broad sweep completed 2026-10-04; optional external packet in `paper/INDEPENDENT_REVIEW_PACKET.md` | Bounded search found no direct follow-up or identical construction, but no literature search can prove novelty |
| The anonymous ACM PDF uses 8 main pages and 10 total pages with references starting on page 9 | Artifact check | `paper/main.pdf`, `paper/main.log`; all pages visually inspected and all fonts embedded on 2026-10-14 under production CTAN `acmart` v2.20 | Re-check the official template version and submission metadata immediately before upload |

The paper must not claim effects on exposure, misinformation diffusion,
recommendation outcomes, or human behavior. Its application claim is a
structural link-audit problem with local control and a strict intervention
budget.

## October 15 refinements

- SingletonSort is an established modular-upper-bound specialization, not a
  newly invented generic algorithm (Iyer et al., NeurIPS 2013).
- `thm:floor` proves `g(R) <= min(t OPT - mu k(t-1), h-mu b)` and factor
  `tH/(H+mu k(t-1))`, with `mu>=1/2` for unweighted LCM. Full parity and
  envelope proofs are in `app:floor`. Generic modular residuals are prior art.
- New audit `results/STRUCTURAL_BOUND_AUDIT.json`: 49,152 coverage and 1,293
  directed-graph cardinality cells, integer-only comparisons, independent DP.
- `results/blockmatch_real_graph.jsonl` and independent verification cover
  48 separate post-freeze cells, 3,239 rational original-graph enumerations,
  240 method outputs. BlockMatch 47/48 optima; overlap 48/48. No retuning.
- `blockmatch/exact.py` uses integer weights throughout blossom; all 48
  surrogates agree with independent DP. The historical float backend and frozen
  code remain unchanged. Exactness is not assumed from float comparisons.
- `results/STRUCTURAL_REAL_GRAPH_SUMMARY.json`: all 24 `k>=4` bounds improve
  (median 1.87%); the other 24 cells retain exact small-k guarantees.
- 27 cited works are mapped in `notes/REFERENCE_AUDIT_2026-10-15.md`; all 21 DOI
  entries have fresh publisher-deposited metadata checks. KDD full text was
  unavailable, so only title-supported model distinctions are made.
