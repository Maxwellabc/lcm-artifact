"""BlockMatch via fixed-cardinality minimum-weight blossom matching.

The implementation is intentionally separate from :mod:`lcm`: it was derived
after the real-graph protocol froze, and changing it must not change the frozen
LCM implementation hash.
"""
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations
from math import isfinite
from typing import Callable, FrozenSet, Hashable, Iterable, Tuple

import networkx as nx


Item = Hashable
ValueOracle = Callable[[FrozenSet[Item]], float]


@dataclass(frozen=True)
class BlockMatchResult:
    selected: FrozenSet[Item]
    blocks: Tuple[Tuple[Item, ...], ...]
    surrogate: float
    objective: float
    oracle_calls: int
    matching_calls: int


def fixed_cardinality_matching(
    items: Iterable[Item],
    pair_count: int,
    pair_cost: Callable[[Item, Item], float],
) -> Tuple[float, Tuple[Tuple[Item, Item], ...]]:
    """Return a minimum-weight matching with exactly ``pair_count`` edges.

    Add ``n-2q`` dummy vertices, connect each dummy to every real vertex at
    zero cost, and omit dummy--dummy edges.  A perfect matching in the
    augmented graph contains exactly ``q`` real--real edges.  NetworkX's
    minimum-weight maximum-cardinality blossom routine therefore solves the
    fixed-cardinality problem.
    """
    ordered = tuple(items)
    n = len(ordered)
    if pair_count < 0 or 2 * pair_count > n:
        raise ValueError("pair_count must lie in [0, floor(n/2)]")
    if pair_count == 0:
        return 0.0, ()
    graph = nx.Graph()
    real_nodes = [("real", position) for position in range(n)]
    dummy_nodes = [("dummy", position) for position in range(n - 2 * pair_count)]
    graph.add_nodes_from(real_nodes)
    graph.add_nodes_from(dummy_nodes)
    costs = {}
    for left in range(n):
        for right in range(left + 1, n):
            weight = float(pair_cost(ordered[left], ordered[right]))
            if not isfinite(weight):
                raise ValueError("pair costs must be finite")
            costs[left, right] = weight
            graph.add_edge(real_nodes[left], real_nodes[right], weight=weight)
    for dummy in dummy_nodes:
        for real in real_nodes:
            graph.add_edge(dummy, real, weight=0.0)
    matching = nx.min_weight_matching(graph, weight="weight")
    expected_edges = (len(real_nodes) + len(dummy_nodes)) // 2
    if len(matching) != expected_edges:
        raise AssertionError("augmented matching is not perfect")
    blocks = []
    for left, right in matching:
        if left[0] == right[0] == "real":
            positions = tuple(sorted((left[1], right[1])))
            blocks.append(positions)
    blocks.sort()
    if len(blocks) != pair_count:
        raise AssertionError("dummy reduction returned the wrong cardinality")
    surrogate = sum(costs[pair] for pair in blocks)
    return surrogate, tuple(
        (ordered[left], ordered[right]) for left, right in blocks
    )


def block_match(items: Iterable[Item], k: int, value: ValueOracle) -> BlockMatchResult:
    """Run BlockMatch for a normalized nonnegative monotone submodular oracle.

    Tie breaking follows the input iteration order, so item labels need only be
    hashable; they do not need to be mutually comparable.
    """
    ordered = tuple(items)
    if len(set(ordered)) != len(ordered):
        raise ValueError("items must be distinct")
    if not 1 <= k <= len(ordered):
        raise ValueError("k must lie between one and the ground-set size")
    calls = 0

    @lru_cache(maxsize=None)
    def cached(selected: FrozenSet[Item]) -> float:
        nonlocal calls
        calls += 1
        answer = float(value(selected))
        if not isfinite(answer) or answer < 0.0:
            raise ValueError("oracle values must be finite and nonnegative")
        return answer

    def pair_cost(left: Item, right: Item) -> float:
        return cached(frozenset((left, right)))

    matching_calls = 0
    if k == 1:
        chosen = min(
            enumerate(ordered),
            key=lambda positioned: (
                cached(frozenset((positioned[1],))), positioned[0]
            ),
        )[1]
        blocks = ((chosen,),)
        surrogate = cached(frozenset((chosen,)))
    elif k % 2 == 0:
        matching_calls = 1
        surrogate, blocks = fixed_cardinality_matching(
            ordered, k // 2, pair_cost
        )
    else:
        positions = {item: position for position, item in enumerate(ordered)}
        triple = min(
            combinations(ordered, 3),
            key=lambda candidate: (
                cached(frozenset(candidate)),
                tuple(positions[item] for item in candidate),
            ),
        )
        outside = tuple(item for item in ordered if item not in triple)
        if k > 3:
            matching_calls = 1
            pair_value, pairs = fixed_cardinality_matching(
                outside, (k - 3) // 2, pair_cost
            )
        else:
            pair_value, pairs = 0.0, ()
        surrogate = cached(frozenset(triple)) + pair_value
        blocks = (triple,) + pairs
    selected = frozenset(item for block in blocks for item in block)
    if len(selected) != k:
        raise AssertionError("BlockMatch returned the wrong cardinality")
    return BlockMatchResult(
        selected=selected,
        blocks=tuple(tuple(block) for block in blocks),
        surrogate=surrogate,
        objective=cached(selected),
        oracle_calls=calls,
        matching_calls=matching_calls,
    )
