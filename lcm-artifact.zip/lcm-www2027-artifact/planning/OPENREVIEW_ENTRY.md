# WWW 2027 OpenReview entry

Status: local revision prepared on 2026-10-15; not uploaded. The last verified
server metadata describes the October 14 version. Author identities and
receipts remain in excluded private records.

## Title

Sharper Approximation and Certified Search for Local Harmonic Centrality
Minimization

## Research track

Graph Algorithms and Modeling for the Web

## Abstract

Local harmonic centrality minimization removes at most b incoming links to reduce a target's structural reachability. Interchangeable last edges of shortest paths make the value of a deletion depend on other deleted links. We analyze complementary strict-budget approximations that retain k = d - b of the target's d in-neighbors. SingletonSort specializes a modular upper bound and runs in O(d(|V|+|E|)) time. BlockMatch selects pairs and at most one triple using one fixed-cardinality matching. A lower bound on every candidate's marginal contribution yields a factor of h_G(v)/(2 sqrt(h_G(v))-1) for k >= 4; BlockMatch is exact for k <= 3. We also construct a budget-exact profile storing only the b+1 best terminal candidates per source. It supports exact local moves and a Lagrangian minimum-cut lower bound, with global optimality certified whenever a cut meets the required cardinality. A hybrid preserves its strongest included feasible solution and a refined singleton guarantee. Across 198 blind target-budget cells from four directed graphs, it improves the prior sorting baseline in 197 cells, with a 2.985% median reduction in residual centrality. The median certified gap is 2.26%, and nine solutions are proved optimal. A separate 48-cell exact-enumeration study finds BlockMatch optimal in 47 cells and overlap search optimal in all 48. A four-graph scalability extension shows that the sorting rules are usually tied on million-scale inputs. Hash-fixed inputs and independent shortest-path recomputation make the comparisons auditable.

## Keywords

harmonic centrality; graph modification; approximation algorithms; minimum
cut; optimality certificates

## ACM CCS concepts

- Theory of computation: Approximation algorithms analysis
- Theory of computation: Graph algorithms analysis

## Fields completed or checked privately

- Author names, ordered profile IDs, affiliations, and institutional emails
- OpenReview identity, current and past affiliations, ORCID, and advisor entry

## Fields that still require author action

- Final institutional and personal conflict review in the venue's actual COI
  interface (the updated CFP inconsistently names EasyChair while submission
  and profiles are in OpenReview)

The OpenReview registration, submission number, proof-wording revision, and
byte-verified server PDF receipt are recorded in the excluded private
submission files.

Before entry, compare this file byte-for-byte in meaning with the final title,
abstract, and keywords in `paper/main.tex`; resolve any later proof correction
in both places.
