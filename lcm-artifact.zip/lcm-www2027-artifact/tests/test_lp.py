import importlib.util
import unittest

from lcm.algorithms import brute_force_optimum
from lcm.graph import from_integer_edges
from lcm.lp import (
    solve_local_hull_relaxation,
    solve_prefix_relaxation,
    solve_prefix_with_pair_cuts,
)
from lcm.profile import build_budget_profile


SCIPY_AVAILABLE = importlib.util.find_spec("scipy") is not None


@unittest.skipUnless(SCIPY_AVAILABLE, "scipy is installed only in the project .venv")
class RelaxationTests(unittest.TestCase):
    def test_cross_source_l2_l3_gap(self):
        edges = [(u, 0) for u in range(1, 6)]
        edges += [(6, 1), (6, 2), (7, 3), (7, 4)]
        graph = from_integer_edges(8, edges)
        profile = build_budget_profile(graph, 0, 3)
        l1 = solve_prefix_relaxation(profile, 3)
        l1_pair = solve_prefix_with_pair_cuts(profile, 3)
        l2 = solve_local_hull_relaxation(profile)
        l3 = solve_local_hull_relaxation(profile, conflict_order=2)
        l4 = solve_local_hull_relaxation(profile, conflict_order=3)
        mip = solve_prefix_relaxation(profile, 3, integer=True)
        optimum, _, _ = brute_force_optimum(profile)
        self.assertLessEqual(l1.objective, l2.objective + 1e-8)
        self.assertGreaterEqual(l1_pair.objective + 1e-8, l1.objective)
        self.assertAlmostEqual(l2.objective, 7.0 / 3.0, places=8)
        self.assertAlmostEqual(l3.objective, 2.5, places=8)
        self.assertAlmostEqual(l4.objective, 2.5, places=8)
        self.assertAlmostEqual(mip.objective, optimum, places=8)

    def test_l0_is_no_stronger_than_l1(self):
        edges = [(u, 0) for u in range(1, 4)]
        edges += [(1, 2), (2, 1), (1, 3), (3, 1), (2, 3), (3, 2)]
        graph = from_integer_edges(4, edges)
        full = build_budget_profile(graph, 0, 3)
        budget = build_budget_profile(graph, 0, 1)
        l0 = solve_prefix_relaxation(full, 1)
        l1 = solve_prefix_relaxation(budget, 1)
        self.assertLessEqual(l0.objective, l1.objective + 1e-8)
        self.assertAlmostEqual(l0.objective, 2.0, places=8)
        self.assertAlmostEqual(l1.objective, 2.5, places=8)


if __name__ == "__main__":
    unittest.main()
