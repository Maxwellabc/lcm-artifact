# WWW 2027 submission checklist

Status date: 2026-10-15 Asia/Shanghai. Target track: **Graph Algorithms and
Modeling for the Web**. The authoritative policy is the
[WWW 2027 Research Track CFP](https://www2027.thewebconf.org/research-track-papers/).

## Fixed external constraints

- Abstract deadline: **2026-10-18 AoE** (2026-10-19 19:59 Beijing time).
- Full-paper deadline: **2026-10-25 AoE** (2026-10-26 19:59 Beijing time).
- Internal freezes: abstract/authors by **2026-10-17 18:00 Beijing time**;
  final PDF by **2026-10-24 18:00 Beijing time**.
- Long papers use `\documentclass[sigconf, anonymous, review]{acmart}` and may
  contain 8 main pages and at most 12 total pages. The first 8 pages must be
  self-contained.
- The first page must state the specific Web research problem and track
  relevance. Merely evaluating on a social-network dataset is insufficient.
- Review is double blind. The author list and ordering become immutable after
  the abstract deadline. Every author needs a complete OpenReview profile and
  conflict information.
- The updated CFP says OpenReview manages submissions and profiles, but its COI
  paragraph still says conflicts are declared in EasyChair and provides no
  EasyChair link. OpenReview documentation says organizers may compute conflict
  edges from profiles, publications, affiliations, and relations, which can
  explain the missing author-side control but not how private conflicts are
  supplied. Keep the OpenReview profile current and check for an operative
  conflict interface before the abstract freeze. The author declined the
  proposed chair email; no communication is scheduled by this checklist.
- A placeholder abstract is forbidden. Submit the paper as one viewable PDF.
- Public code/data are encouraged after review. An archival DOI is needed to
  apply for the optional ACM artifact badge after acceptance.

## Internal schedule and exit criteria

| Beijing dates | Work product | Exit criterion |
|---|---|---|
| Sep 27--30 | Internal theory and novelty review; optional external review | Internal proof and prior-art checks are recorded. An external specialist verdict is optional and is not a WWW submission requirement. |
| Oct 1--5 | Repair proofs, positioning, and references | `CLAIM_EVIDENCE.md` matches the paper; no result is labeled new solely because it is absent from the WWW 2024 code. |
| Oct 6--9 | Freeze experiments and artifact logic | No new primary metric is introduced; tests and `scripts/audit_artifact.py` pass from a clean environment. |
| Oct 10--13 | Cold paper review | A reader can restate the problem, theorem improvement, certificate meaning, and experimental conclusion from the first 8 pages. |
| Oct 14--17 | Author/OpenReview and abstract freeze | Final author order, profiles, affiliations, conflicts, title, abstract, track, and keywords are entered and checked. |
| Oct 18 | Abstract deadline safeguard | OpenReview entry exists, contains a substantive abstract, and has a downloaded local receipt. |
| Oct 19--22 | Final paper revision | Any known substantive issues are addressed; anonymous PDF passes a fresh visual and metadata inspection. External review is optional. |
| Oct 23 | Reproduction rehearsal | A second checkout can fetch/verify inputs, run tests and audits, regenerate assets, and rebuild the PDF from the documented commands. |
| Oct 24 18:00 | Internal submission freeze | PDF hash is recorded; title/abstract/author order match OpenReview; no source or result changes afterward except a blocking correction. |
| Oct 25 | Submit and verify | Downloaded OpenReview PDF matches the frozen hash and renders correctly; submission confirmation is archived. |

## Paper gate

- [x] Title and abstract lead with the sharper strict-budget approximation
  guarantee, then the exact profile and instance certificates.
- [x] Page 1 names a concrete Web link-audit setting and explains why local
  incoming-link control with a strict budget is a Web graph problem.
- [x] The problem definition states directed, unweighted, simple graphs and
  distinguishes deleted candidates from retained candidates.
- [x] The comparison to A1 quotes the correct published factor and the same
  asymptotic running time.
- [x] The profile theorem, construction lemma, singleton and BlockMatch
  theorems, both matching parities, tight family, Lagrangian lower bound, and
  cardinality-hit theorem have passed internal proof and computational checks.
- [ ] Optional: obtain an external specialist proof/novelty review. This is
  not an official submission gate.
- [x] The certificate section uses consistent signs, constants, variable
  meanings, and exact-versus-rounded terminology.
- [x] The empirical text reports the weak incremental gain over adapted
  components as clearly as the strong gain over A1.
- [x] Dataset selection, target selection, blind exclusions, budgets, hardware,
  seeds, bootstrap unit, and unsuccessful high-budget profile behavior are
  disclosed.
- [x] The separately frozen four-graph scalability extension reports its pilot
  gate, five test targets per graph, 6/52/2 W/T/L, zero median gain, and two
  losses without implying empirical dominance.
- [x] Limitations avoid claims about exposure, diffusion, misinformation,
  recommendation quality, or human outcomes.
- [x] Citations cover the WWW 2024 paper, all-vertices nearest terminals,
  Minimum k-Union, cardinality-constrained submodular optimization, nested
  monomials, closure/min-cut side constraints, and the JCSS 2026 general
  `2 sqrt(d)` cardinality-constrained minimization result.
- [x] Every bibliography entry was checked against a DOI registry and primary
  source on 2026-10-04; all cited claims match the source's scope.
- [x] No author name, affiliation, acknowledgment, deanonymizing repository
  URL, local path, PDF metadata identity, or first-person self-citation remains.
- [x] Current official ACM class/template is used; fonts are embedded; pages
  print correctly; main content is at most 8 pages and total is at most 12.

## Artifact and evidence gate

- [x] `python3 scripts/fetch_public_inputs.py --include-scalability --check-only`
  verifies all eight graph hashes and the declared raw/self-loop/simple counts
  for the four scalability inputs.
- [x] `.venv/bin/python -m unittest discover -s tests -v` succeeds.
- [x] `.venv/bin/python scripts/exhaustive_small_graph_audit.py --output results/EXHAUSTIVE_SMALL_GRAPH_AUDIT.json` reproduces 4,096 graphs and status `ok`.
- [x] `.venv/bin/python scripts/validate_block_matching_candidate.py` passes all
  cardinalities of 262,144 ordered six-set/three-element coverage systems
  (3,145,728 ordinary-plus-LCM cells), 1,724 random coverage/LCM cells, four
  tight DAG families, and 120 independent blossom/reference agreement cells.
- [x] `python3 scripts/audit_artifact.py` returns status `ok` after the final PDF build.
- [x] Frozen protocol hash, runner version, config hashes, graph hashes, 5,544
  result rows, 198 cells, and 198 certificate audits remain unchanged.
- [x] Scalability protocol/config/target hashes match; its result file has 144
  unique successful rows and its 60 sealed pairs reproduce 6/52/2 W/T/L.
- [x] Generated tables and figures contain no hand-transcribed result values.
- [x] Release package excludes raw graph archives and the unlicensed upstream
  snapshot; manifests, target lists, acquisition script, code, configs, logs,
  and generated reports remain included.
- [x] A clean release directory contains no virtual environment, unlisted
  LaTeX intermediates, temporary renders, cache, absolute user path, or
  secrets.  The audited `main.log` and reproducible `main.bbl` are included
  deliberately.
- [ ] If accepted, archive the artifact in a DOI-granting repository and apply
  for the optional ACM “Artifacts Available” badge.

## Final OpenReview gate

- [x] Select **Graph Algorithms and Modeling for the Web**.
- [x] Check title, substantive abstract, keywords, author order,
  affiliation, and OpenReview profile.
- [ ] Recheck the complete institutional and personal conflict set before the
  abstract freeze; do not infer conflicts from the public profile.
- [x] Upload only the anonymous PDF and any explicitly permitted anonymous
  supplementary material.
- [x] The revised anonymous PDF uses eight main pages and ten pages total;
  references start on page 9. Local proof, metadata, layout, embedded-font,
  and 11-test audits passed on 2026-10-14. Its current SHA-256 is
  `b866d7969787866492cb5dabe0da1d3c93fd8a2090c60ba96767a95a46094c2e`.
- [x] Uploaded the revised PDF and synchronized abstract after explicit
  author confirmation on 2026-10-14. The authenticated server download is
  byte-identical to the audited local PDF; the saved author order and full
  abstract were independently re-opened and checked in the revision form.
- [x] Save the submission ID, timestamp, PDF SHA256, and confirmation receipt.

## Current local revision

October 15: 8 main pages, 12 total, 27 verified references, full marginal-floor
proof, 48-cell exploratory exact-optimum supplement, and 13 passing tests.
This revision and its changed abstract have not been uploaded; historical
authenticated receipts continue to describe the October 14 version.
