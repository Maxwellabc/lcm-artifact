"""Compare L0/L1/local-hull L2/conflict L3/MILP on small exact instances."""
import argparse
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lcm.algorithms import brute_force_optimum  # noqa: E402
from lcm.graph import from_integer_edges  # noqa: E402
from lcm.lp import solve_local_hull_relaxation, solve_prefix_relaxation  # noqa: E402
from lcm.profile import build_budget_profile  # noqa: E402


def write(handle, record):
    handle.write(json.dumps(record, sort_keys=True) + "\n")
    handle.flush()


def evaluate(instance, graph, target, budget):
    full = build_budget_profile(graph, target, graph.indegree(target))
    profile = build_budget_profile(graph, target, budget)
    optimum, deleted, enumerated = brute_force_optimum(profile)
    methods = {
        "l0": solve_prefix_relaxation(full, budget),
        "l1": solve_prefix_relaxation(profile, budget),
        "l2": solve_local_hull_relaxation(profile),
        "l3": solve_local_hull_relaxation(profile, conflict_order=2),
        "l4": solve_local_hull_relaxation(profile, conflict_order=3),
        "milp": solve_prefix_relaxation(profile, budget, integer=True),
    }
    values = {name: result.objective for name, result in methods.items()}
    tolerance = 1e-7
    if not (values["l0"] <= values["l1"] + tolerance
            and values["l1"] <= values["l2"] + tolerance
            and values["l2"] <= values["l3"] + tolerance
            and values["l3"] <= values["l4"] + tolerance
            and values["l4"] <= optimum + tolerance
            and abs(values["milp"] - optimum) <= tolerance):
        raise AssertionError("relaxation ordering failed: %r optimum=%r" % (values, optimum))
    return {
        "instance": instance,
        "n": graph.n,
        "m": graph.m,
        "d": profile.d,
        "budget": budget,
        "optimum": optimum,
        "optimum_deleted": list(deleted),
        "enumerated": enumerated,
        "values": values,
        "improvement_l1_over_l0": values["l1"] - values["l0"],
        "improvement_l2_over_l1": values["l2"] - values["l1"],
        "improvement_l3_over_l2": values["l3"] - values["l2"],
        "improvement_l4_over_l3": values["l4"] - values["l3"],
        "remaining_gap_l4": optimum - values["l4"],
        "details": {
            name: {
                "seconds": result.solve_seconds,
                "variables": result.variables,
                "equalities": result.equalities,
                "inequalities": result.inequalities,
                "diagnostics": result.diagnostics,
            }
            for name, result in methods.items()
        },
        "status": "ok",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--instances", type=int, default=40)
    parser.add_argument("--seed", type=int, default=20260925)
    parser.add_argument("--output", type=Path,
                        default=ROOT / "results" / "small_lp_audit.jsonl")
    args = parser.parse_args(argv)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)
    with args.output.open("w", encoding="utf-8") as handle:
        # The proved L2-to-L3 separating instance.
        edges = [(u, 0) for u in range(1, 6)]
        edges += [(6, 1), (6, 2), (7, 3), (7, 4)]
        write(handle, evaluate("cross_source_witness", from_integer_edges(8, edges), 0, 3))
        for instance_index in range(args.instances):
            d = rng.randrange(4, 9)
            extra = rng.randrange(2, 7)
            n = 1 + d + extra
            probability = rng.choice((0.15, 0.3, 0.5, 0.75))
            edges = [(u, 0) for u in range(1, d + 1)]
            edges += [
                (u, v)
                for u in range(1, n)
                for v in range(1, n)
                if u != v and rng.random() < probability
            ]
            budget = rng.randrange(1, d)
            graph = from_integer_edges(n, edges)
            write(handle, evaluate("random_%03d" % instance_index, graph, 0, budget))
    print(args.output)


if __name__ == "__main__":
    main()
