import hashlib
import tempfile
import unittest
from pathlib import Path

from lcm.graph import from_integer_edges
from lcm.objective import harmonic_after_deletions, harmonic_with_all_target_inedges_removed
from lcm.profile import singleton_costs
from scalability.compact_graph import BFSWorkspace, ReverseCSR, build_reverse_csr


class CompactScalabilityTests(unittest.TestCase):
    def test_compact_bfs_matches_independent_backend(self):
        edges = {
            (0, 2), (1, 2), (2, 3), (1, 3), (3, 4), (2, 4),
            (0, 5), (5, 3),
        }
        graph = from_integer_edges(6, edges)
        target = 4
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "graph.tsv"
            source.write_text("".join("%d %d\n" % (u + 1, v + 1)
                                      for u, v in sorted(edges)))
            graph_hash = hashlib.sha256(source.read_bytes()).hexdigest()
            cache = root / "graph.reverse-csr"
            build_reverse_csr(
                source, cache, expected_sha256=graph_hash,
                expected_n=graph.n, expected_m=graph.m,
            )
            with ReverseCSR(cache) as compact:
                workspace = BFSWorkspace(compact)
                candidates = sorted(graph.in_neighbors[target])
                expected_singletons = singleton_costs(graph, target, candidates)
                for index, candidate in enumerate(candidates):
                    self.assertAlmostEqual(
                        workspace.harmonic_without_target_inedges(candidate, target),
                        harmonic_with_all_target_inedges_removed(graph, candidate, target),
                    )
                    self.assertAlmostEqual(
                        workspace.singleton_cost(candidate, target),
                        expected_singletons[index],
                    )
                for deleted in ((), (candidates[0],), tuple(candidates)):
                    self.assertAlmostEqual(
                        workspace.lcm_objective(target, deleted),
                        harmonic_after_deletions(graph, target, deleted),
                    )
                self.assertEqual([compact.original_label(i) for i in range(compact.n)],
                                 [1, 2, 3, 4, 5, 6])

    def test_compact_graph_maps_gapped_external_labels(self):
        external_edges = {(10, 30), (20, 30), (30, 50)}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "gapped.tsv"
            source.write_text("".join("%d %d\n" % edge
                                      for edge in sorted(external_edges)))
            graph_hash = hashlib.sha256(source.read_bytes()).hexdigest()
            cache = root / "gapped.reverse-csr"
            build_reverse_csr(
                source, cache, expected_sha256=graph_hash,
                expected_n=4, expected_m=3,
            )
            with ReverseCSR(cache) as compact:
                self.assertEqual([compact.original_label(i) for i in range(compact.n)],
                                 [10, 20, 30, 50])
                self.assertEqual(list(compact.incoming(2)), [0, 1])
                self.assertEqual(list(compact.incoming(3)), [2])


if __name__ == "__main__":
    unittest.main()
