# Reference and positioning audit, 2026-10-15

The current bibliography contains 27 cited works (15 retained, 12 added).
Every added reference has a verified primary record. All 21 DOI entries were
queried again through Crossref, using the publisher-deposited metadata; the
selected fields and query URLs are in `doi_metadata_2026-10-15.json`.
Authors and order, title, venue, volume/issue, pages/article number and DOI
were checked. The six non-DOI records use the primary sources below. This is
a bounded literature audit, not a proof that no overlapping theorem exists.

## Added work and citation purpose

| Key | Primary record | Purpose and limit |
|---|---|---|
| iyer2013curvature | [NeurIPS official proceedings](https://proceedings.neurips.cc/paper/2013/hash/c1e39d912d21c91dce811d6da9929ae8-Abstract.html) | MUB, modular residual and curvature are prior art. Corollary 5.1 / SLB discussion gives the comparator factor. Official BibTeX has empty pages, so none were invented. |
| svitkina2011submodular | [SIAM J. Comput.](https://doi.org/10.1137/100783352) | General value-oracle barriers, not an LCM-specific lower bound. |
| chlamtac2017union | [SODA](https://doi.org/10.1137/1.9781611974782.56) | General minimum k-union context; its unweighted exponent is not claimed for LCM by analogy. |
| lee2025diffim | [AAAI 39(17):18128–18136](https://ojs.aaai.org/index.php/AAAI/article/view/33994) | Diffusion intervention; different objective and surrogate learning. |
| liu2024moderating | [TKDE 36(4):1385–1398](https://doi.org/10.1109/TKDE.2023.3309987), [author preprint](https://arxiv.org/abs/2309.06392) | Information centrality and connectivity-preserving removal. DOI contains 2023; issue year is 2024. |
| zhang2026information | [ACM KDD V.2](https://doi.org/10.1145/3770855.3817829) | Global edge addition model, as stated in title. |
| wang2026markov | [ACM KDD V.1](https://doi.org/10.1145/3770854.3780201) | Group Markov model, as stated in title. |
| berner2024resistance | [ECML PKDD](https://doi.org/10.1007/978-3-031-70365-2_17), [author preprint](https://arxiv.org/abs/2407.11521) | Graph-level electrical resistance robustness; 287–302. |
| spaeh2025multiobjective | [PMLR 267:56692–56718](https://proceedings.mlr.press/v267/spaeh25a.html) | Fair centrality maximization, a different optimization direction. |
| cruciani2025percolation | [IEEE ICDM](https://doi.org/10.1109/ICDM65498.2025.00121), [author preprint](https://arxiv.org/abs/2509.11454) | Fixed-graph percolation-centrality estimation, not an LCM solver. |
| rafiey2022sparsification | [AAAI 36(9):10336–10344](https://ojs.aaai.org/index.php/AAAI/article/view/21275) | Approximate component reweighting, distinct from exact terminal truncation. |
| bao2026sparsify | [arXiv:2606.20777](https://arxiv.org/abs/2606.20777) | Closest recent cardinality-aware sparsification preprint; not labeled a published conference paper. |

Both KDD records are real and their complete bibliographic fields were
verified against ACM-deposited Crossref metadata and the official KDD paper
list. The ACM full-text endpoint returned HTTP 403 in this session; therefore
the paper makes only the title-supported model distinction and no detailed
claims about those algorithms, their proofs or measured quality. Other added
model distinctions were checked in publisher abstracts or author manuscripts.

## Non-DOI primary records

- Har-Peled: [arXiv:1607.07818](https://arxiv.org/abs/1607.07818).
- Iyer, Jegelka, Bilmes, Fast Semidifferential-based Submodular Function
  Optimization: [PMLR 28(3):855–863](https://proceedings.mlr.press/v28/iyer13.html).
- Iyer et al., curvature: the official NeurIPS record and downloaded official
  `iyer2013curvature_official.bib` (no page range in its source).
- Bienstock and Zuckerberg: [Optimization Online technical report, 2009](https://optimization-online.org/2009/08/2380/).
- Spaeh and Miyauchi: PMLR record above.
- Bao, Cai and Chen: arXiv record above, explicitly a preprint.

## Resolved metadata differences

Boland et al. appeared online in 2011; volume 133, pages 481–511 is the 2012
journal issue used in the bibliography. Cruciani–Pellegrina is cited as ICDM
2025 and year 2025, following IEEE-deposited Crossref publication date
2025-11-12 and the author's accepted-conference record; an institutional
catalog displays 2026, which was not used to replace the publisher date.
KONECT's Crossref title is abbreviated to “KONECT”; the full publisher title
includes “The Koblenz Network Collection”. No fictional page numbers or DOI
were supplied for records that do not provide them.

## Novelty boundary

SingletonSort is an MUB specialization. Generic modular-residual reasoning,
nearest-terminal search, closure/cut methods, and approximate sparsification
are explicitly credited. The new refinement is the LCM lower marginal floor
and the affine pair/triple argument, including the odd-cardinality case, its
feasible upper bound, and resulting envelopes. A bounded search cannot certify
that this specialization is unprecedented; the paper uses no “first” claim.
