"""Generate vector comparison figures and compact tables from frozen records.

This companion generator uses ReportLab only, so the additional paper figures
remain reproducible in environments where Matplotlib is unavailable.
"""

import argparse
import json
import statistics
import sys
from collections import Counter
from pathlib import Path

import reportlab
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

from summarize_test_results import (
    TOLERANCE,
    build_cells,
    load_frozen_design,
    read_frozen_rows,
)


BLUE = HexColor("#0072B2")
ORANGE = HexColor("#D55E00")
GREEN = HexColor("#009E73")
GRID = HexColor("#D9D9D9")
INK = HexColor("#252525")
MUTED = HexColor("#666666")
FONT_REGULAR = "PaperVera"
FONT_BOLD = "PaperVeraBold"


def register_fonts():
    """Use ReportLab's bundled Vera faces so every figure font is embedded."""
    font_dir = Path(reportlab.__file__).resolve().parent / "fonts"
    pdfmetrics.registerFont(TTFont(FONT_REGULAR, font_dir / "Vera.ttf"))
    pdfmetrics.registerFont(TTFont(FONT_BOLD, font_dir / "VeraBd.ttf"))


def comparison_values(cells, comparator):
    values = []
    for cell in cells:
        baseline = (cell["baseline"] if comparator == "strongest"
                    else cell["component_objectives"][comparator])
        values.append((baseline - cell["hybrid"]) / baseline if baseline else 0.0)
    return values


def write_budget_table(path, cells):
    rows = []
    for ratio in (0.25, 0.50, 0.75):
        group = [cell for cell in cells if cell["budget_ratio"] == ratio]
        a1 = comparison_values(group, "algorithm1")
        strong = comparison_values(group, "strongest")
        wins = sum(value > TOLERANCE for value in strong)
        losses = sum(value < -TOLERANCE for value in strong)
        ties = len(strong) - wins - losses
        gaps = [max(0.0, (cell["hybrid"] - cell["certificate_lower_bound"])
                    / cell["hybrid"])
                for cell in group if cell["certificate_lower_bound"] is not None]
        rows.append(
            f"{ratio:.2f} & {len(group)} & {100 * statistics.mean(a1):.3f}\\% & "
            f"{100 * statistics.median(a1):.3f}\\% & {wins}/{ties}/{losses} & "
            f"{100 * statistics.median(gaps):.2f}\\% \\\\"
        )
    path.write_text("\n".join([
        "\\begin{tabular}{crrrrr}",
        "\\toprule",
        "$b/d$ & Cells & A1 mean & A1 median & Strong W/T/L & Median gap \\\\",
        "\\midrule",
        *rows,
        "\\bottomrule",
        "\\end{tabular}",
        "",
    ]), encoding="utf-8")


def write_detailed_table(path, cells):
    display = {
        "test-ciaodvd": "CiaoDVD",
        "test-moreno": "Moreno",
        "test-polblogs": "PolBlogs",
        "test-twitter": "Twitter",
    }
    rows = []
    for suite in sorted(display):
        for ratio in (0.25, 0.50, 0.75):
            group = [cell for cell in cells
                     if cell["suite"] == suite and cell["budget_ratio"] == ratio]
            strong = comparison_values(group, "strongest")
            wins = sum(value > TOLERANCE for value in strong)
            losses = sum(value < -TOLERANCE for value in strong)
            ties = len(strong) - wins - losses
            gaps = [max(0.0, (cell["hybrid"] - cell["certificate_lower_bound"])
                        / cell["hybrid"])
                    for cell in group if cell["certificate_lower_bound"] is not None]
            rows.append(
                f"{display[suite]} & {ratio:.2f} & {wins}/{ties}/{losses} & "
                f"{100 * statistics.mean(strong):.3f}\\% & "
                f"{100 * max(strong):.3f}\\% & "
                f"{100 * statistics.median(gaps):.2f}\\% & "
                f"{statistics.median(cell['hybrid_pipeline_seconds'] for cell in group):.2f} "
                "\\\\"
            )
    path.write_text("\n".join([
        "\\begin{tabular}{lcrrrrr}",
        "\\toprule",
        "Graph & $b/d$ & W/T/L & Mean gain & Best gain & Median gap & Median s \\\\ ",
        "\\midrule",
        *rows,
        "\\bottomrule",
        "\\end{tabular}",
        "",
    ]), encoding="utf-8")


def label(c, x, y, text, size=6.5, color=INK, align="left", bold=False):
    font = FONT_BOLD if bold else FONT_REGULAR
    c.setFont(font, size)
    c.setFillColor(color)
    width = stringWidth(text, font, size)
    if align == "center":
        x -= width / 2
    elif align == "right":
        x -= width
    c.drawString(x, y, text)


def axes(c, x, y, width, height, x_ticks, y_ticks, x_range, y_range,
         x_label, y_label, tag):
    left, bottom = x + 31, y + 23
    plot_w, plot_h = width - 39, height - 31
    c.setStrokeColor(INK)
    c.setLineWidth(0.55)
    c.line(left, bottom, left + plot_w, bottom)
    c.line(left, bottom, left, bottom + plot_h)
    for value, text in y_ticks:
        py = bottom + (value - y_range[0]) / (y_range[1] - y_range[0]) * plot_h
        c.setStrokeColor(GRID)
        c.setLineWidth(0.35)
        c.line(left, py, left + plot_w, py)
        label(c, left - 4, py - 2.2, text, 5.6, align="right")
    for value, text in x_ticks:
        px = left + (value - x_range[0]) / (x_range[1] - x_range[0]) * plot_w
        label(c, px, bottom - 10, text, 5.6, align="center")
    label(c, left + plot_w / 2, y + 2, x_label, 6.1, align="center")
    if y_label:
        c.saveState()
        c.translate(x + 5, bottom + plot_h / 2)
        c.rotate(90)
        label(c, 0, 0, y_label, 6.1, align="center")
        c.restoreState()
    label(c, x + 3, y + height - 9, tag, 7.0, bold=True)
    return left, bottom, plot_w, plot_h


def map_point(left, bottom, plot_w, plot_h, xv, yv, xr, yr):
    return (
        left + (xv - xr[0]) / (xr[1] - xr[0]) * plot_w,
        bottom + (yv - yr[0]) / (yr[1] - yr[0]) * plot_h,
    )


def draw_polyline(c, points, color, width=1.1):
    if not points:
        return
    path = c.beginPath()
    path.moveTo(*points[0])
    for point in points[1:]:
        path.lineTo(*point)
    c.setStrokeColor(color)
    c.setLineWidth(width)
    c.drawPath(path)


def draw_comparison(path, cells):
    width, height = 7.05 * 72, 2.18 * 72
    c = canvas.Canvas(
        str(path), pagesize=(width, height), pageCompression=1,
        invariant=1, initialFontName=FONT_REGULAR)
    panel_w = width / 3

    xr, yr = (0.0, 10.7), (0.0, 100.0)
    left, bottom, pw, ph = axes(
        c, 0, 0, panel_w, height,
        [(0, "0"), (2, "2"), (5, "5"), (10, "10")],
        [(0, "0"), (25, "25"), (50, "50"), (75, "75"), (100, "100")],
        xr, yr, "hybrid improvement (%)", "cells at/above gain (%)", "(a)")
    series = [
        ("algorithm1", "A1", BLUE),
        ("greedy", "Greedy", ORANGE),
        ("strongest", "Strongest", GREEN),
    ]
    for key, _name, color in series:
        values = sorted(100 * value for value in comparison_values(cells, key))
        points = []
        for index, value in enumerate(values):
            survival = 100 * (len(values) - index) / len(values)
            points.append(map_point(left, bottom, pw, ph,
                                    max(xr[0], min(xr[1], value)), survival,
                                    xr, yr))
        draw_polyline(c, points, color)
    for index, (_, name, color) in enumerate(series):
        y = height - 13 - 8 * index
        c.setStrokeColor(color)
        c.setLineWidth(1.3)
        c.line(left + pw - 44, y + 2, left + pw - 34, y + 2)
        label(c, left + pw - 31, y, name, 5.5)

    counts = Counter(cell["baseline_method"] for cell in cells)
    order = [
        ("multi_start_one_swap", "Multi-start"),
        ("overlap_search", "Overlap"),
        ("greedy", "Greedy"),
        ("parametric_repair", "Cut repair"),
        ("algorithm1", "A1"),
    ]
    left, bottom, pw, ph = axes(
        c, panel_w, 0, panel_w, height,
        [(0, "0"), (25, "25"), (50, "50"), (75, "75"), (100, "100")],
        [], (0.0, 110.0), (0.0, 5.0),
        "cells where component is strongest", "", "(b)")
    bar_h = ph / 7
    for row, (key, name) in enumerate(order):
        value = counts[key]
        py = bottom + ph - (row + 1.1) * ph / 5.4
        px = left + value / 110 * pw
        c.setFillColor(HexColor("#6A8CAF"))
        c.rect(left, py, max(0.8, px - left), bar_h, stroke=0, fill=1)
        label(c, left - 3, py + 1.2, name, 5.4, align="right")
        label(c, px + 3, py + 1.2, str(value), 5.4)

    xr, yr = (0.0, 2.0), (0.0, 7.0)
    left, bottom, pw, ph = axes(
        c, 2 * panel_w, 0, panel_w, height,
        [(0, ".25"), (1, ".50"), (2, ".75")],
        [(0, "0"), (2, "2"), (4, "4"), (6, "6")],
        xr, yr, "budget ratio b/d", "mean improvement (%)", "(c)")
    for key, _name, color in series:
        values = []
        for index, ratio in enumerate((0.25, 0.50, 0.75)):
            group = [cell for cell in cells if cell["budget_ratio"] == ratio]
            values.append((index, 100 * statistics.mean(
                comparison_values(group, key))))
        points = [map_point(left, bottom, pw, ph, x, y, xr, yr)
                  for x, y in values]
        draw_polyline(c, points, color)
        c.setFillColor(color)
        for px, py in points:
            c.circle(px, py, 1.7, stroke=0, fill=1)
    for index, (_, name, color) in enumerate(series):
        y = height - 13 - 8 * index
        c.setStrokeColor(color)
        c.setLineWidth(1.3)
        c.line(left + 2, y + 2, left + 12, y + 2)
        label(c, left + 15, y, name, 5.5)
    c.showPage()
    c.save()


def draw_profile(path, records):
    latest = {}
    full_by_dataset = {}
    for record in records:
        if record.get("status") == "ok":
            latest[(record["dataset"], record["budget_ratio"], record["mode"])] = record
            if record["mode"] == "full":
                full_by_dataset[record["dataset"]] = record
    datasets = (("ciaodvd", "CiaoDVD", BLUE),
                ("moreno", "Moreno", ORANGE),
                ("polblogs", "PolBlogs", GREEN))
    budgets = (0.25, 0.50, 0.75)
    width, height = 7.05 * 72, 2.15 * 72
    c = canvas.Canvas(
        str(path), pagesize=(width, height), pageCompression=1,
        invariant=1, initialFontName=FONT_REGULAR)
    panel_w = width / 3
    panels = [
        ("stored-label reduction (%)", (-30.0, 80.0),
         [(-25, "-25"), (0, "0"), (25, "25"), (50, "50"), (75, "75")]),
        ("full/compressed build time", (0.0, 1.6),
         [(0, "0"), (0.5, ".5"), (1.0, "1"), (1.5, "1.5")]),
        ("traced-memory reduction (%)", (-35.0, 60.0),
         [(-25, "-25"), (0, "0"), (25, "25"), (50, "50")]),
    ]
    for panel, (ylabel, yr, y_ticks) in enumerate(panels):
        xr = (0.0, 2.0)
        left, bottom, pw, ph = axes(
            c, panel * panel_w, 0, panel_w, height,
            [(0, ".25"), (1, ".50"), (2, ".75")], y_ticks,
            xr, yr, "budget ratio b/d", ylabel, f"({chr(97 + panel)})")
        baseline = 1.0 if panel == 1 else 0.0
        p1 = map_point(left, bottom, pw, ph, 0, baseline, xr, yr)
        p2 = map_point(left, bottom, pw, ph, 2, baseline, xr, yr)
        c.setStrokeColor(MUTED)
        c.setDash(2, 2)
        c.setLineWidth(0.55)
        c.line(p1[0], p1[1], p2[0], p2[1])
        c.setDash()
        for dataset, _name, color in datasets:
            values = []
            for index, ratio in enumerate(budgets):
                compressed = latest[(dataset, ratio, "compressed")]
                full = full_by_dataset[dataset]
                if panel == 0:
                    value = 100 * (1 - compressed["stored_labels"] /
                                   full["stored_labels"])
                elif panel == 1:
                    value = full["build_seconds"] / compressed["build_seconds"]
                else:
                    value = 100 * (1 - compressed["tracemalloc_peak_bytes"] /
                                   full["tracemalloc_peak_bytes"])
                values.append((index, value))
            points = [map_point(left, bottom, pw, ph, x, y, xr, yr)
                      for x, y in values]
            draw_polyline(c, points, color)
            c.setFillColor(color)
            for px, py in points:
                c.circle(px, py, 1.7, stroke=0, fill=1)
        if panel == 0:
            for index, (_, name, color) in enumerate(datasets):
                y = height - 13 - 8 * index
                c.setStrokeColor(color)
                c.setLineWidth(1.3)
                c.line(left + 2, y + 2, left + 12, y + 2)
                label(c, left + 15, y, name, 5.5)
    c.showPage()
    c.save()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--suite", type=Path, action="append", required=True)
    parser.add_argument("--profile-benchmarks", type=Path, required=True)
    parser.add_argument("--paper-dir", type=Path, required=True)
    args = parser.parse_args(argv)
    register_fonts()
    protocol, configs, expected = load_frozen_design(args.protocol)
    rows = read_frozen_rows(args.suite, protocol, configs)
    cells, partial, errors = build_cells(rows, configs)
    if partial or errors or len(cells) != len(expected):
        raise RuntimeError("frozen inputs are incomplete")
    records = [json.loads(line) for line in
               args.profile_benchmarks.read_text().splitlines() if line.strip()]
    generated = args.paper_dir / "generated"
    figures = args.paper_dir / "figures"
    generated.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    write_budget_table(generated / "budget_results.tex", cells)
    write_detailed_table(generated / "detailed_results.tex", cells)
    draw_comparison(figures / "comparison_views.pdf", cells)
    draw_profile(figures / "profile_tradeoffs.pdf", records)
    return 0


if __name__ == "__main__":
    sys.exit(main())
