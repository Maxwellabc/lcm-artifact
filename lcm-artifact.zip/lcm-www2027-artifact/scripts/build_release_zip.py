"""Convert the audited release TAR into a deterministic, equivalent ZIP."""

import argparse
import hashlib
import json
import tarfile
import zipfile
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT / "dist" / "lcm-www2027-artifact.tar.gz"
DEFAULT_OUTPUT = ROOT / "dist" / "lcm-www2027-artifact.zip"
PREFIX = "lcm-www2027-artifact"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_members(path):
    payloads = []
    with tarfile.open(path, "r:gz") as archive:
        for member in archive.getmembers():
            if member.isdir():
                continue
            if not member.isfile():
                raise RuntimeError("non-regular TAR member: %s" % member.name)
            relative = PurePosixPath(member.name)
            if not relative.parts or relative.parts[0] != PREFIX:
                raise RuntimeError("member outside release prefix: %s" % member.name)
            if relative.is_absolute() or ".." in relative.parts:
                raise RuntimeError("unsafe member path: %s" % member.name)
            handle = archive.extractfile(member)
            if handle is None:
                raise RuntimeError("cannot read TAR member: %s" % member.name)
            payloads.append((relative.as_posix(), member.mode & 0o777, handle.read()))
    payloads.sort(key=lambda item: item[0])
    if not payloads:
        raise RuntimeError("release TAR is empty")
    if len({name for name, _, _ in payloads}) != len(payloads):
        raise RuntimeError("duplicate TAR member")
    return payloads


def build_zip(path, payloads):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(
        path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for name, mode, payload in payloads:
            info = zipfile.ZipInfo(name)
            info.date_time = (1980, 1, 1, 0, 0, 0)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (0o100000 | mode) << 16
            info.flag_bits = 0
            archive.writestr(
                info,
                payload,
                compress_type=zipfile.ZIP_DEFLATED,
                compresslevel=9,
            )


def verify_zip(path, payloads):
    expected = {name: (mode, payload) for name, mode, payload in payloads}
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if names != sorted(expected):
            raise RuntimeError("ZIP order or member set differs from TAR")
        for name in names:
            info = archive.getinfo(name)
            mode = (info.external_attr >> 16) & 0o777
            expected_mode, expected_payload = expected[name]
            if mode != expected_mode:
                raise RuntimeError("mode mismatch: %s" % name)
            if archive.read(name) != expected_payload:
                raise RuntimeError("payload mismatch: %s" % name)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args(argv)
    source = args.input.resolve()
    output = args.output.resolve()
    payloads = read_members(source)
    build_zip(output, payloads)
    verify_zip(output, payloads)
    digest = sha256(output)
    sidecar = Path(str(output) + ".sha256")
    sidecar.write_text("%s  %s\n" % (digest, output.name), encoding="utf-8")
    print(json.dumps({
        "input": str(source),
        "input_sha256": sha256(source),
        "members": len(payloads),
        "output": str(output),
        "output_sha256": digest,
        "status": "ok",
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
