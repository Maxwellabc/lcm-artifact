"""Generate paper tables, statistics, and figures from frozen result records."""
import argparse
import json
import random
import statistics
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from summarize_test_results import (
    DETERMINISTIC_BASELINES,
    TOLERANCE,
    build_cells,
    load_frozen_design,
    read_frozen_rows,
)


DISPLAY = {
    "test-ciaodvd": "CiaoDVD",
    "test-moreno": "Moreno",
    "test-polblogs": "PolBlogs",
    "test-twitter": "Twitter",
}
COMPARATORS = (
    ("algorithm1", "WWW 2024 A1"),
    ("degree", "Degree"),
    ("greedy", "Greedy"),
    ("singleton_sort", "SingletonSort"),
    ("parametric_repair", "Parametric repair"),
    ("multi_start_one_swap", "Multi-start 1-swap"),
    ("overlap_search", "Overlap search"),
)


def percentile(values, probability):
    ordered = sorted(values)
    position = probability * (len(ordered) - 1)
    low = int(position)
    high = min(low + 1, len(ordered) - 1)
    weight = position - low
    return ordered[low] * (1.0 - weight) + ordered[high] * weight


def clustered_mean_ci(cells, value, *, seed, repetitions=10_000):
    """Stratified target bootstrap; all budgets of one target move together."""
    by_suite_target = defaultdict(lambda: defaultdict(list))
    for cell in cells:
        by_suite_target[cell["suite"]][cell["target_index"]].append(value(cell))
    rng = random.Random(seed)
    estimates = []
    for _ in range(repetitions):
        sample = []
        for suite in sorted(by_suite_target):
            clusters = list(by_suite_target[suite].values())
            for _ in range(len(clusters)):
                sample.extend(clusters[rng.randrange(len(clusters))])
        estimates.append(statistics.mean(sample))
    return percentile(estimates, 0.025), percentile(estimates, 0.975)


def comparison_values(cells, comparator):
    values = []
    for cell in cells:
        baseline = (cell["baseline"] if comparator == "strongest"
                    else cell["component_objectives"][comparator])
        values.append((baseline - cell["hybrid"]) / baseline if baseline else 0.0)
    return values


def write_component_table(path, cells):
    slash = "\\"
    rows = [(key, label) for key, label in COMPARATORS]
    rows.append(("strongest", "Strongest component"))
    lines = [
        slash + "begin{tabular}{lrrrr}",
        slash + "toprule",
        "Comparator & W/T/L & Median & Mean & Maximum " + slash * 2,
        slash + "midrule",
    ]
    for key, label in rows:
        values = comparison_values(cells, key)
        wins = sum(value > TOLERANCE for value in values)
        losses = sum(value < -TOLERANCE for value in values)
        ties = len(values) - wins - losses
        lines.append(
            f"{label} & {wins}/{ties}/{losses} & "
            f"{100 * statistics.median(values):.3f}\\% & "
            f"{100 * statistics.mean(values):.3f}\\% & "
            f"{100 * max(values):.3f}\\% " + slash * 2
        )
    lines += [slash + "bottomrule", slash + "end{tabular}"]
    path.write_text("\n".join(lines) + "\n")


def write_budget_table(path, cells):
    slash = "\\"
    lines = [
        slash + "begin{tabular}{crrrrr}",
        slash + "toprule",
        "$b/d$ & Cells & A1 mean & A1 median & Strong W/T/L & Median gap "
        + slash * 2,
        slash + "midrule",
    ]
    for ratio in (0.25, 0.50, 0.75):
        group = [cell for cell in cells if cell["budget_ratio"] == ratio]
        a1 = comparison_values(group, "algorithm1")
        strong = comparison_values(group, "strongest")
        wins = sum(value > TOLERANCE for value in strong)
        losses = sum(value < -TOLERANCE for value in strong)
        ties = len(strong) - wins - losses
        gaps = [max(0.0, (cell["hybrid"] - cell["certificate_lower_bound"])
                    / cell["hybrid"])
                for cell in group if cell["certificate_lower_bound"] is not None]
        lines.append(
            f"{ratio:.2f} & {len(group)} & {100 * statistics.mean(a1):.3f}\\% & "
            f"{100 * statistics.median(a1):.3f}\\% & {wins}/{ties}/{losses} & "
            f"{100 * statistics.median(gaps):.2f}\\% " + slash * 2
        )
    lines += [slash + "bottomrule", slash + "end{tabular}"]
    path.write_text("\n".join(lines) + "\n")


def write_dataset_table(path, cells):
    by_target = {}
    for cell in cells:
        by_target[(cell["suite"], cell["target_index"])] = cell
    by_suite = defaultdict(list)
    for (suite, _), cell in by_target.items():
        by_suite[suite].append(cell)
    slash = "\\"
    lines = [
        slash + "begin{tabular}{lrrrr}",
        slash + "toprule",
        "Graph & $|V|$ & $|E|$ & Targets & $d$: min/med/max " + slash * 2,
        slash + "midrule",
    ]
    for suite in sorted(by_suite):
        group = by_suite[suite]
        degrees = sorted(cell["budget"] / cell["budget_ratio"] for cell in group)
        # The ratios are exactly .25/.5/.75 but floor(b) loses information.
        # Recover indegree from b=floor(r*d) by reading one matching raw record
        # attached below by main().
        exact_degrees = sorted(cell["indegree"] for cell in group)
        median = statistics.median(exact_degrees)
        median_text = f"{median:g}"
        lines.append(
            f"{DISPLAY[suite]} & {group[0]['n']:,} & {group[0]['m']:,} & "
            f"{len(group)} & {min(exact_degrees)}/{median_text}/{max(exact_degrees)} "
            + slash * 2
        )
    lines += [slash + "bottomrule", slash + "end{tabular}"]
    path.write_text("\n".join(lines) + "\n")


def write_statistical_macros(path, cells):
    def gain(cell, comparator):
        baseline = (cell["baseline"] if comparator == "strongest"
                    else cell["component_objectives"][comparator])
        return (baseline - cell["hybrid"]) / baseline if baseline else 0.0

    values_a1 = [gain(cell, "algorithm1") for cell in cells]
    values_strong = [gain(cell, "strongest") for cell in cells]
    a1_ci = clustered_mean_ci(
        cells, lambda cell: gain(cell, "algorithm1"), seed=27027)
    strong_ci = clustered_mean_ci(
        cells, lambda cell: gain(cell, "strongest"), seed=27028)
    lines = [
        f"\\newcommand{{\\AOneMeanGain}}{{{100 * statistics.mean(values_a1):.3f}\\%}}",
        f"\\newcommand{{\\AOneMeanCILow}}{{{100 * a1_ci[0]:.3f}\\%}}",
        f"\\newcommand{{\\AOneMeanCIHigh}}{{{100 * a1_ci[1]:.3f}\\%}}",
        f"\\newcommand{{\\StrongMeanGain}}{{{100 * statistics.mean(values_strong):.3f}\\%}}",
        f"\\newcommand{{\\StrongMeanCILow}}{{{100 * strong_ci[0]:.3f}\\%}}",
        f"\\newcommand{{\\StrongMeanCIHigh}}{{{100 * strong_ci[1]:.3f}\\%}}",
    ]
    path.write_text("\n".join(lines) + "\n")


def draw_results_figure(pdf_path, png_path, cells):
    colors = {
        "test-ciaodvd": "#0072B2",
        "test-moreno": "#D55E00",
        "test-polblogs": "#009E73",
        "test-twitter": "#CC79A7",
    }
    budgets = (0.25, 0.5, 0.75)
    fig, axes = plt.subplots(1, 3, figsize=(7.05, 2.25))

    for ax, metric, ylabel, tag in [
        (axes[0], lambda c: 100 * (
            c["component_objectives"]["algorithm1"] - c["hybrid"]
        ) / c["component_objectives"]["algorithm1"],
         "gain over WWW 2024 A1 (%)", "(a)"),
        (axes[1], lambda c: 100 * max(
            0.0, (c["hybrid"] - c["certificate_lower_bound"]) / c["hybrid"]
        ), "certified gap (%)", "(b)"),
    ]:
        grouped = [[metric(cell) for cell in cells if cell["budget_ratio"] == ratio]
                   for ratio in budgets]
        ax.boxplot(
            grouped, positions=range(3), widths=0.55, showfliers=False,
            patch_artist=True,
            boxprops={"facecolor": "#D9EAF7", "edgecolor": "#333333"},
            medianprops={"color": "#111111", "linewidth": 1.2},
            whiskerprops={"color": "#555555"}, capprops={"color": "#555555"},
        )
        for suite_index, suite in enumerate(sorted(DISPLAY)):
            for budget_index, ratio in enumerate(budgets):
                subset = [metric(cell) for cell in cells
                          if cell["suite"] == suite and cell["budget_ratio"] == ratio]
                offsets = np.linspace(-0.13, 0.13, len(subset)) if subset else []
                ax.scatter(
                    budget_index + offsets, subset, s=7, alpha=0.48,
                    color=colors[suite], edgecolors="none", rasterized=True,
                )
        ax.set_xticks(range(3), [".25", ".50", ".75"])
        ax.set_xlabel("budget ratio $b/d$")
        ax.set_ylabel(ylabel)
        ax.grid(axis="y", color="#DDDDDD", linewidth=0.5)
        ax.text(0.01, 0.98, tag, transform=ax.transAxes, va="top", fontweight="bold")

    ax = axes[2]
    for suite in sorted(DISPLAY):
        medians = [statistics.median(
            cell["hybrid_pipeline_seconds"] for cell in cells
            if cell["suite"] == suite and cell["budget_ratio"] == ratio
        ) for ratio in budgets]
        ax.plot(range(3), medians, marker="o", markersize=3.2, linewidth=1.2,
                color=colors[suite], label=DISPLAY[suite])
    ax.set_xticks(range(3), [".25", ".50", ".75"])
    ax.set_xlabel("budget ratio $b/d$")
    ax.set_ylabel("median pipeline time (s)")
    ax.grid(axis="y", color="#DDDDDD", linewidth=0.5)
    ax.text(0.01, 0.98, "(c)", transform=ax.transAxes, va="top", fontweight="bold")
    ax.legend(frameon=False, fontsize=6.5, ncol=2, loc="upper left",
              bbox_to_anchor=(0.0, 0.88))

    for ax in axes:
        ax.tick_params(labelsize=7)
        ax.xaxis.label.set_size(7.5)
        ax.yaxis.label.set_size(7.5)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
    fig.tight_layout(w_pad=1.1)
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    png_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(pdf_path, bbox_inches="tight")
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def draw_comparison_figure(pdf_path, png_path, cells):
    fig, axes = plt.subplots(1, 3, figsize=(7.05, 2.18))

    ax = axes[0]
    for key, label, color in [
        ("algorithm1", "A1", "#0072B2"),
        ("greedy", "Greedy", "#D55E00"),
        ("strongest", "Strongest component", "#009E73"),
    ]:
        values = np.sort(100 * np.asarray(comparison_values(cells, key)))
        survival = 100 * (len(values) - np.arange(len(values))) / len(values)
        ax.step(values, survival, where="post", linewidth=1.25,
                label=label, color=color)
    ax.set_xlim(-0.1, 10.7)
    ax.set_ylim(-2, 103)
    ax.set_xlabel("hybrid improvement (%)")
    ax.set_ylabel("cells at or above gain (%)")
    ax.legend(frameon=False, fontsize=6.2, loc="upper right")
    ax.text(0.01, 0.98, "(a)", transform=ax.transAxes, va="top",
            fontweight="bold")

    ax = axes[1]
    counts = defaultdict(int)
    for cell in cells:
        counts[cell["baseline_method"]] += 1
    order = [
        ("multi_start_one_swap", "Multi-start"),
        ("overlap_search", "Overlap"),
        ("greedy", "Greedy"),
        ("parametric_repair", "Cut repair"),
        ("algorithm1", "A1"),
    ]
    labels = [label for key, label in order if counts[key]]
    values = [counts[key] for key, _ in order if counts[key]]
    positions = np.arange(len(labels))
    ax.barh(positions, values, color="#6A8CAF", height=0.62)
    ax.set_yticks(positions, labels)
    ax.invert_yaxis()
    ax.set_xlabel("cells where component is strongest")
    for position, value in zip(positions, values):
        ax.text(value + 1.5, position, str(value), va="center", fontsize=6.5)
    ax.set_xlim(0, max(values) * 1.18)
    ax.text(0.01, 0.98, "(b)", transform=ax.transAxes, va="top",
            fontweight="bold")

    ax = axes[2]
    budgets = (0.25, 0.50, 0.75)
    for key, label, color, marker in [
        ("algorithm1", "vs A1", "#0072B2", "o"),
        ("greedy", "vs Greedy", "#D55E00", "s"),
        ("strongest", "vs strongest", "#009E73", "^"),
    ]:
        means = [100 * statistics.mean(comparison_values(
            [cell for cell in cells if cell["budget_ratio"] == ratio], key))
            for ratio in budgets]
        ax.plot(range(3), means, marker=marker, markersize=3.5,
                linewidth=1.2, color=color, label=label)
    ax.set_xticks(range(3), [".25", ".50", ".75"])
    ax.set_xlabel("budget ratio $b/d$")
    ax.set_ylabel("mean improvement (%)")
    ax.legend(frameon=False, fontsize=6.2, loc="upper left")
    ax.text(0.01, 0.98, "(c)", transform=ax.transAxes, va="top",
            fontweight="bold")

    for ax in axes:
        ax.grid(axis="both", color="#DDDDDD", linewidth=0.5)
        ax.tick_params(labelsize=7)
        ax.xaxis.label.set_size(7.5)
        ax.yaxis.label.set_size(7.5)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
    fig.tight_layout(w_pad=1.0)
    fig.savefig(pdf_path, bbox_inches="tight")
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def draw_profile_figure(pdf_path, png_path, records):
    latest = {}
    full_by_dataset = {}
    for record in records:
        if record.get("status") == "ok":
            latest[(record["dataset"], record["budget_ratio"], record["mode"])] = record
            if record["mode"] == "full":
                full_by_dataset[record["dataset"]] = record
    datasets = ("ciaodvd", "moreno", "polblogs")
    labels = {"ciaodvd": "CiaoDVD", "moreno": "Moreno",
              "polblogs": "PolBlogs"}
    colors = {"ciaodvd": "#0072B2", "moreno": "#D55E00",
              "polblogs": "#009E73"}
    budgets = (0.25, 0.50, 0.75)
    fig, axes = plt.subplots(1, 3, figsize=(7.05, 2.15))
    metrics = []
    for dataset in datasets:
        storage, speed, memory = [], [], []
        for ratio in budgets:
            compressed = latest[(dataset, ratio, "compressed")]
            full = full_by_dataset[dataset]
            storage.append(100 * (1 - compressed["stored_labels"] /
                                  full["stored_labels"]))
            speed.append(full["build_seconds"] / compressed["build_seconds"])
            memory.append(100 * (1 - compressed["tracemalloc_peak_bytes"] /
                                 full["tracemalloc_peak_bytes"]))
        metrics.append((dataset, storage, speed, memory))
    for index, (ylabel, baseline) in enumerate([
        ("stored-label reduction (%)", 0.0),
        ("full/compressed build time", 1.0),
        ("traced-memory reduction (%)", 0.0),
    ]):
        ax = axes[index]
        for dataset, storage, speed, memory in metrics:
            values = (storage, speed, memory)[index]
            ax.plot(range(3), values, marker="o", markersize=3.2,
                    linewidth=1.2, color=colors[dataset], label=labels[dataset])
        ax.axhline(baseline, color="#666666", linewidth=0.7, linestyle="--")
        ax.set_xticks(range(3), [".25", ".50", ".75"])
        ax.set_xlabel("budget ratio $b/d$")
        ax.set_ylabel(ylabel)
        ax.grid(axis="y", color="#DDDDDD", linewidth=0.5)
        ax.text(0.01, 0.98, f"({chr(97 + index)})", transform=ax.transAxes,
                va="top", fontweight="bold")
        ax.tick_params(labelsize=7)
        ax.xaxis.label.set_size(7.5)
        ax.yaxis.label.set_size(7.5)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
    axes[0].legend(frameon=False, fontsize=6.2, loc="lower left")
    fig.tight_layout(w_pad=1.0)
    fig.savefig(pdf_path, bbox_inches="tight")
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--suite", type=Path, action="append", required=True)
    parser.add_argument("--paper-dir", type=Path, required=True)
    parser.add_argument("--profile-benchmarks", type=Path)
    args = parser.parse_args(argv)

    protocol, configs, expected = load_frozen_design(args.protocol)
    rows = read_frozen_rows(args.suite, protocol, configs)
    cells, partial, errors = build_cells(rows, configs)
    if partial or errors or len(cells) != len(expected):
        raise RuntimeError(
            f"frozen results incomplete: cells={len(cells)}/{len(expected)}, "
            f"partial={len(partial)}, errors={len(errors)}"
        )

    # Add exact indegrees from one hash-matched deterministic record per target.
    indegree = {}
    for row in rows:
        if row.get("status") == "ok" and row.get("trial") is None:
            indegree[(row["suite"], row["target_index"])] = row["indegree"]
    for cell in cells:
        cell["indegree"] = indegree[(cell["suite"], cell["target_index"])]

    generated = args.paper_dir / "generated"
    generated.mkdir(parents=True, exist_ok=True)
    write_component_table(generated / "component_results.tex", cells)
    write_budget_table(generated / "budget_results.tex", cells)
    write_dataset_table(generated / "datasets.tex", cells)
    write_statistical_macros(generated / "statistical_summary.tex", cells)
    draw_results_figure(
        args.paper_dir / "figures" / "frozen_results.pdf",
        args.paper_dir / "figures" / "frozen_results.png",
        cells,
    )
    draw_comparison_figure(
        args.paper_dir / "figures" / "comparison_views.pdf",
        args.paper_dir / "figures" / "comparison_views.png",
        cells,
    )
    if args.profile_benchmarks:
        records = [json.loads(line) for line in
                   args.profile_benchmarks.read_text().splitlines() if line.strip()]
        draw_profile_figure(
            args.paper_dir / "figures" / "profile_tradeoffs.pdf",
            args.paper_dir / "figures" / "profile_tradeoffs.png",
            records,
        )


if __name__ == "__main__":
    sys.exit(main())
