"""Run a resumable JSON-configured experiment suite."""
import argparse
import hashlib
import json
import resource
import sys
import traceback
from pathlib import Path
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
RUNNER_VERSION = "2026-09-26-resume-v4"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lcm.algorithms import (  # noqa: E402
    algorithm1,
    bundle_greedy,
    certified_hybrid,
    degree_deletion,
    greedy_deletion,
    one_swap,
    multi_start_one_swap,
    overlap_search,
    parametric_repair,
    random_deletion,
    singleton_sort,
)
from lcm.flow import search_lagrangian_bound  # noqa: E402
from lcm.graph import load_author_targets, load_edgelist  # noqa: E402
from lcm.objective import harmonic_after_deletions  # noqa: E402
from lcm.profile import build_budget_profile  # noqa: E402


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def implementation_hash() -> str:
    digest = hashlib.sha256()
    for path in sorted((ROOT / "lcm").glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def append_record(path: Path, record) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")
        handle.flush()


def record_key(record):
    return (
        record.get("target_index"), record.get("budget"), record.get("method"),
        record.get("trial"), record.get("implementation_hash"),
        record.get("config_hash"), record.get("runner_version"),
    )


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "raw")
    args = parser.parse_args(argv)
    config_bytes = args.config.read_bytes()
    config = json.loads(config_bytes)
    config_hash = hashlib.sha256(config_bytes).hexdigest()
    code_hash = implementation_hash()
    output = args.output / (config["name"] + ".jsonl")
    completed = set()
    if output.exists():
        for line in output.read_text(encoding="utf-8").splitlines():
            record = json.loads(line)
            if record.get("status") == "ok":
                completed.add(record_key(record))
    graph_path = ROOT / config["graph"]
    targets_path = ROOT / config["targets_file"]
    graph_hash = sha256(graph_path)
    load_started = perf_counter()
    graph = load_edgelist(graph_path)
    load_seconds = perf_counter() - load_started
    targets = load_author_targets(targets_path)
    base = {
        "suite": config["name"],
        "config_hash": config_hash,
        "implementation_hash": code_hash,
        "runner_version": RUNNER_VERSION,
        "graph_sha256": graph_hash,
        "n": graph.n,
        "m": graph.m,
        "load_seconds": load_seconds,
    }
    for target_index in config["target_indices"]:
        target = targets[target_index]
        d = graph.indegree(target)
        empty = harmonic_after_deletions(graph, target, ())
        for ratio in config["budget_ratios"]:
            budget = int(d * ratio)
            profile_started = perf_counter()
            profile = build_budget_profile(graph, target, budget)
            profile_seconds = perf_counter() - profile_started
            context = {
                **base,
                "target_index": target_index,
                "target_internal_id": target,
                "target_original_label": graph.labels[target],
                "indegree": d,
                "budget_ratio": ratio,
                "budget": budget,
                "empty_objective": empty,
                "profile_seconds": profile_seconds,
                "profile_accepted_labels": profile.accepted_labels,
                "profile_propagation_attempts": profile.propagation_attempts,
            }
            singleton_result = None
            singleton_cost_values = None
            cached = {}
            for method in config["methods"]:
                key = (
                    target_index, budget, method, None, code_hash, config_hash,
                    RUNNER_VERSION,
                )
                if key in completed:
                    continue
                started = perf_counter()
                try:
                    if method == "algorithm1":
                        result = algorithm1(graph, profile)
                        cached[method] = result
                    elif method == "degree":
                        result = degree_deletion(graph, profile)
                    elif method == "greedy":
                        result = greedy_deletion(profile)
                        cached[method] = result
                    elif method == "singleton_sort":
                        singleton_result, singleton_cost_values = singleton_sort(graph, profile)
                        result = singleton_result
                    elif method == "one_swap":
                        if singleton_result is None:
                            singleton_result, singleton_cost_values = singleton_sort(graph, profile)
                        result = one_swap(
                            profile, singleton_result.deleted,
                            max_rounds=config.get("one_swap_rounds", 10),
                        )
                    elif method == "multi_start_one_swap":
                        if singleton_result is None:
                            singleton_result, singleton_cost_values = singleton_sort(graph, profile)
                        if "algorithm1" not in cached:
                            cached["algorithm1"] = algorithm1(graph, profile)
                        if "greedy" not in cached:
                            cached["greedy"] = greedy_deletion(profile)
                        result = multi_start_one_swap(
                            profile,
                            [cached["algorithm1"], cached["greedy"], singleton_result],
                            max_rounds=config.get("one_swap_rounds", 100),
                        )
                    elif method == "overlap_search":
                        if singleton_result is None:
                            singleton_result, singleton_cost_values = singleton_sort(graph, profile)
                        if "algorithm1" not in cached:
                            cached["algorithm1"] = algorithm1(graph, profile)
                        if "greedy" not in cached:
                            cached["greedy"] = greedy_deletion(profile)
                        result = overlap_search(
                            profile,
                            [cached["algorithm1"], cached["greedy"], singleton_result],
                            swap_rounds=config.get("one_swap_rounds", 100),
                            exchange_rounds=config.get("exchange_rounds", 10),
                        )
                        cached[method] = result
                    elif method == "parametric_repair":
                        result = parametric_repair(
                            profile,
                            iterations=config.get("parametric_iterations", 10),
                            scale=config.get("parametric_scale", 100000),
                        )
                        cached[method] = result
                    elif method == "certified_hybrid":
                        if singleton_result is None:
                            singleton_result, singleton_cost_values = singleton_sort(graph, profile)
                        if "algorithm1" not in cached:
                            cached["algorithm1"] = algorithm1(graph, profile)
                        if "greedy" not in cached:
                            cached["greedy"] = greedy_deletion(profile)
                        result = certified_hybrid(
                            profile,
                            [cached["algorithm1"], cached["greedy"], singleton_result],
                            parametric=cached.get("parametric_repair"),
                            fallbacks=([cached["overlap_search"]]
                                       if "overlap_search" in cached else []),
                            parametric_iterations=config.get("parametric_iterations", 10),
                            parametric_scale=config.get("parametric_scale", 100000),
                            swap_rounds=config.get("one_swap_rounds", 100),
                            exchange_rounds=config.get("exchange_rounds", 10),
                        )
                    elif method == "bundle_greedy":
                        result = bundle_greedy(
                            profile,
                            max_prefix=config.get("bundle_max_prefix", 8),
                            max_bundle_steps=config.get("bundle_max_steps", 32),
                        )
                    else:
                        raise ValueError("unknown method %r" % method)
                    exact = harmonic_after_deletions(graph, target, result.deleted)
                    if abs(exact - result.objective) > 1e-9 * max(1.0, exact):
                        raise AssertionError("profile/oracle disagreement")
                    record = {
                        **context,
                        "method": method,
                        "trial": None,
                        "deleted_count": len(result.deleted),
                        "deleted_internal_ids": list(result.deleted),
                        "objective_exact": exact,
                        "remaining_fraction": exact / empty if empty else None,
                        "solve_seconds": result.solve_seconds,
                        "total_method_seconds": perf_counter() - started,
                        "peak_process_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                        "diagnostics": dict(result.diagnostics),
                        "status": "ok",
                    }
                except Exception as error:
                    record = {
                        **context, "method": method, "trial": None,
                        "status": "error", "error": repr(error),
                        "traceback": traceback.format_exc(),
                        "total_method_seconds": perf_counter() - started,
                    }
                append_record(output, record)
                completed.add(record_key(record))
            for trial in range(config.get("random_trials", 0)):
                method = "random"
                key = (
                    target_index, budget, method, trial, code_hash, config_hash,
                    RUNNER_VERSION,
                )
                if key in completed:
                    continue
                seed_material = "%s:%s:%s:%s" % (graph_hash, target, budget, trial)
                seed = int(hashlib.sha256(seed_material.encode()).hexdigest()[:16], 16)
                result = random_deletion(profile, seed)
                exact = harmonic_after_deletions(graph, target, result.deleted)
                record = {
                    **context, "method": method, "trial": trial, "seed": seed,
                    "deleted_count": len(result.deleted),
                    "deleted_internal_ids": list(result.deleted),
                    "objective_exact": exact,
                    "remaining_fraction": exact / empty if empty else None,
                    "solve_seconds": result.solve_seconds,
                    "peak_process_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                    "status": "ok",
                }
                append_record(output, record)
                completed.add(record_key(record))
            if (target_index in config.get("certificate_target_indices", [])
                    and ratio in config.get("certificate_budget_ratios", [])):
                method = "lagrangian_certificate"
                key = (
                    target_index, budget, method, None, code_hash, config_hash,
                    RUNNER_VERSION,
                )
                if key not in completed:
                    started = perf_counter()
                    try:
                        certificate = search_lagrangian_bound(
                            profile,
                            iterations=config.get("certificate_iterations", 10),
                            scale=config.get("certificate_scale", 100000),
                        )
                        trivial = max(float(profile.k), profile.base_lower_bound())
                        if singleton_result is None:
                            singleton_result, singleton_cost_values = singleton_sort(graph, profile)
                        trivial = max(trivial, float(
                            singleton_result.diagnostics["kth_singleton_lower_bound"]))
                        record = {
                            **context, "method": method, "trial": None,
                            "lower_bound": max(trivial, certificate.lower_bound),
                            "raw_lagrangian_lower_bound": certificate.lower_bound,
                            "trivial_lower_bound": trivial,
                            "multiplier": certificate.multiplier,
                            "retained_count": certificate.retained_count,
                            "flow_nodes": certificate.nodes,
                            "flow_arcs": certificate.arcs,
                            "solve_seconds": perf_counter() - started,
                            "peak_process_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                            "status": "ok",
                        }
                    except Exception as error:
                        record = {
                            **context, "method": method, "trial": None,
                            "status": "error", "error": repr(error),
                            "traceback": traceback.format_exc(),
                            "solve_seconds": perf_counter() - started,
                        }
                    append_record(output, record)
                    completed.add(record_key(record))
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
