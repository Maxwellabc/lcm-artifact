# Synthetic Overlap Mechanism

The target has 12 in-neighbors and budget 6. Each auxiliary source reaches one listed candidate subset in one step; duplicating all source groups by `scale` changes their weight without changing the set system. Candidate self-contributions remain one. Exact enumeration checks all 924 strict-budget deletion sets.

| Scale | Sources | A1 / Greedy / Singleton | Multi-start 1-swap | Prefix exchange | OPT | Improvement over 1-swap |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 41 | 21.5 | 19.5 | 19.0 | 19.0 | 2.56% |
| 2 | 82 | 37.0 | 33.0 | 32.0 | 32.0 | 3.03% |
| 4 | 164 | 68.0 | 60.0 | 58.0 | 58.0 | 3.33% |
| 8 | 328 | 130.0 | 114.0 | 110.0 | 110.0 | 3.51% |
| 16 | 656 | 254.0 | 222.0 | 214.0 | 214.0 | 3.60% |

For scale t, the three one-shot starts have value 6+15.5t, one-swap reaches 6+13.5t, and one prefix exchange reaches the optimum 6+13t. The strict-budget improvement over the 1-swap local optimum is 0.5t/(6+13.5t), approaching 1/27. This is a controlled mechanism example, not a worst-case guarantee for prefix exchange.
