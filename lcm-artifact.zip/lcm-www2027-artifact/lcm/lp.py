"""Small-instance LP/MILP formulations for relaxation audits.

SciPy is optional and intentionally kept outside the core package dependency.
The local-hull formulation enumerates all exact-budget deletion sets and is
therefore only suitable for small candidate sets.
"""
from dataclasses import dataclass
from itertools import combinations
from math import comb
from time import perf_counter
from typing import Dict, FrozenSet, List, Optional, Sequence, Tuple

from .profile import BudgetProfile, ProfileRow


@dataclass(frozen=True)
class OptimizationResult:
    name: str
    objective: float
    solve_seconds: float
    status: str
    variables: int
    equalities: int
    inequalities: int
    diagnostics: Dict[str, object]


def _scipy():
    try:
        import numpy as np
        from scipy.optimize import Bounds, LinearConstraint, linprog, milp
        from scipy.sparse import coo_matrix
    except ImportError as error:
        raise RuntimeError("LP experiments require scipy; use the project .venv") from error
    return np, Bounds, LinearConstraint, linprog, milp, coo_matrix


def _prefix_terms(profile: BudgetProfile, prefix_limit: int):
    terms = []
    constant = 0.0
    for row_index, row in enumerate(profile.rows):
        if row.values:
            constant += row.values[0]
        values = list(row.values[:prefix_limit + 1])
        values.extend([0.0] * (prefix_limit + 1 - len(values)))
        prefix = []
        for rank, candidate in enumerate(row.candidate_indices[:prefix_limit]):
            prefix.append(candidate)
            delta = values[rank] - values[rank + 1]
            if delta > 1e-15:
                terms.append((row_index, frozenset(prefix), delta))
    return constant, terms


def solve_prefix_relaxation(
    profile: BudgetProfile,
    cardinality: int,
    *,
    integer: bool = False,
) -> OptimizationResult:
    """Solve C-sum(delta*z), z_P<=x_u, sum(x)=cardinality.

    Use a full profile built with budget=d for L0.  Use a profile built with
    the tested budget for L1.  Integer=True gives an exact small-instance MILP.
    """
    np, Bounds, LinearConstraint, linprog, milp, coo_matrix = _scipy()
    if cardinality < 0 or cardinality > profile.d:
        raise ValueError("invalid cardinality")
    prefix_limit = min(profile.budget, profile.d)
    constant, terms = _prefix_terms(profile, prefix_limit)
    d = profile.d
    variable_count = d + len(terms)
    row_indices = []
    col_indices = []
    data = []
    upper = []
    constraint_row = 0
    for term_index, (_, prefix, _) in enumerate(terms):
        z_column = d + term_index
        for candidate in prefix:
            row_indices.extend([constraint_row, constraint_row])
            col_indices.extend([z_column, candidate])
            data.extend([1.0, -1.0])
            upper.append(0.0)
            constraint_row += 1
    aub = coo_matrix((data, (row_indices, col_indices)),
                     shape=(constraint_row, variable_count)).tocsr()
    c = np.zeros(variable_count)
    for term_index, (_, _, delta) in enumerate(terms):
        c[d + term_index] = -delta
    aeq = coo_matrix(
        (np.ones(d), (np.zeros(d, dtype=int), np.arange(d))),
        shape=(1, variable_count),
    ).tocsr()
    started = perf_counter()
    if integer:
        matrices = [aeq]
        lower = [float(cardinality)]
        bounds_upper = [float(cardinality)]
        if constraint_row:
            matrices.append(aub)
            lower.extend([-np.inf] * constraint_row)
            bounds_upper.extend(upper)
        from scipy.sparse import vstack
        matrix = vstack(matrices).tocsr()
        result = milp(
            c,
            integrality=np.ones(variable_count),
            bounds=Bounds(np.zeros(variable_count), np.ones(variable_count)),
            constraints=LinearConstraint(matrix, np.asarray(lower), np.asarray(bounds_upper)),
            options={"time_limit": 300.0},
        )
        name = "prefix_milp"
    else:
        result = linprog(
            c,
            A_ub=aub if constraint_row else None,
            b_ub=np.asarray(upper) if constraint_row else None,
            A_eq=aeq,
            b_eq=np.asarray([float(cardinality)]),
            bounds=(0.0, 1.0),
            method="highs",
        )
        name = "prefix_lp"
    elapsed = perf_counter() - started
    if not result.success:
        raise RuntimeError("%s failed: %s" % (name, result.message))
    return OptimizationResult(
        name=name,
        objective=constant + float(result.fun),
        solve_seconds=elapsed,
        status=str(result.message),
        variables=variable_count,
        equalities=1,
        inequalities=constraint_row,
        diagnostics={"prefix_terms": len(terms), "constant": constant,
                     "mip_gap": getattr(result, "mip_gap", None)},
    )


def solve_prefix_with_pair_cuts(
    profile: BudgetProfile,
    cardinality: int,
    *,
    max_rounds: int = 10,
    max_cuts_per_round: int = 200,
    violation_tolerance: float = 1e-8,
) -> OptimizationResult:
    """Solve L1 and iteratively separate violated cross-row pair conflicts.

    This floating LP is for empirical relaxation comparison.  It is not used
    as a rigorous numerical certificate; the quantized max-flow code provides
    that certificate for L1.
    """
    np, Bounds, LinearConstraint, linprog, milp, coo_matrix = _scipy()
    from scipy.sparse import vstack

    constant, terms = _prefix_terms(profile, min(profile.budget, profile.d))
    d = profile.d
    variable_count = d + len(terms)
    base_rows = []
    base_cols = []
    base_data = []
    base_upper = []
    constraint_row = 0
    for term_index, (_, prefix, _) in enumerate(terms):
        z_column = d + term_index
        for candidate in prefix:
            base_rows.extend([constraint_row, constraint_row])
            base_cols.extend([z_column, candidate])
            base_data.extend([1.0, -1.0])
            base_upper.append(0.0)
            constraint_row += 1
    base = coo_matrix((base_data, (base_rows, base_cols)),
                      shape=(constraint_row, variable_count)).tocsr()
    c = np.zeros(variable_count)
    for term_index, (_, _, delta) in enumerate(terms):
        c[d + term_index] = -delta
    aeq = coo_matrix(
        (np.ones(d), (np.zeros(d, dtype=int), np.arange(d))),
        shape=(1, variable_count),
    ).tocsr()
    cuts = []
    cut_set = set()
    result = None
    rounds = 0
    started = perf_counter()
    for round_index in range(max_rounds + 1):
        if cuts:
            cut_rows = []
            cut_cols = []
            for row_index, (left, right) in enumerate(cuts):
                cut_rows.extend([row_index, row_index])
                cut_cols.extend([d + left, d + right])
            cut_matrix = coo_matrix(
                (np.ones(len(cut_rows)), (cut_rows, cut_cols)),
                shape=(len(cuts), variable_count),
            ).tocsr()
            aub = vstack([base, cut_matrix]).tocsr()
            bub = np.asarray(base_upper + [1.0] * len(cuts))
        else:
            aub = base
            bub = np.asarray(base_upper)
        result = linprog(
            c, A_ub=aub, b_ub=bub, A_eq=aeq,
            b_eq=np.asarray([float(cardinality)]), bounds=(0.0, 1.0), method="highs",
        )
        if not result.success:
            raise RuntimeError("pair-cut LP failed: %s" % result.message)
        if round_index == max_rounds:
            break
        z = result.x[d:]
        active = sorted((i for i, value in enumerate(z) if value > violation_tolerance),
                        key=lambda i: (-z[i], i))
        violations = []
        for left_position, left in enumerate(active):
            for right in active[left_position + 1:]:
                violation = z[left] + z[right] - 1.0
                if violation <= violation_tolerance:
                    break
                pair = (min(left, right), max(left, right))
                if pair in cut_set or terms[left][0] == terms[right][0]:
                    continue
                if len(terms[left][1] | terms[right][1]) > cardinality:
                    violations.append((violation, pair))
        if not violations:
            break
        violations.sort(key=lambda item: (-item[0], item[1]))
        for _, pair in violations[:max_cuts_per_round]:
            cuts.append(pair)
            cut_set.add(pair)
        rounds += 1
    elapsed = perf_counter() - started
    return OptimizationResult(
        name="prefix_pair_cut_lp",
        objective=constant + float(result.fun),
        solve_seconds=elapsed,
        status=str(result.message),
        variables=variable_count,
        equalities=1,
        inequalities=constraint_row + len(cuts),
        diagnostics={"prefix_terms": len(terms), "cuts": len(cuts),
                     "cut_rounds": rounds, "constant": constant,
                     "numeric_certificate": False},
    )


def _row_value(row: ProfileRow, deleted: FrozenSet[int]) -> float:
    for candidate, value in zip(row.candidate_indices, row.values):
        if candidate not in deleted:
            return value
    return 0.0


def solve_local_hull_relaxation(
    profile: BudgetProfile,
    *,
    conflict_order: int = 0,
    max_pattern_variables: int = 250_000,
    max_conflicts: int = 250_000,
) -> OptimizationResult:
    """Intersect exact per-row fixed-cardinality hulls through shared x.

    L2 uses one probability distribution over all size-b deletion sets per
    distinct row profile. Order 2 adds pairwise trigger conflicts (L3); order
    3 also adds inclusion-minimal triple union conflicts (L4). This is an audit
    formulation, not a scalable algorithm.
    """
    np, Bounds, LinearConstraint, linprog, milp, coo_matrix = _scipy()
    d, b = profile.d, profile.budget
    pattern_count = comb(d, b)
    # Equal row profiles can share a distribution by symmetry.
    groups: Dict[Tuple[Tuple[int, ...], Tuple[float, ...]], Tuple[ProfileRow, int]] = {}
    for row in profile.rows:
        key = (row.candidate_indices, row.values)
        if key in groups:
            original, multiplicity = groups[key]
            groups[key] = (original, multiplicity + 1)
        else:
            groups[key] = (row, 1)
    grouped = list(groups.values())
    if len(grouped) * pattern_count > max_pattern_variables:
        raise ValueError("local hull would need %d pattern variables" %
                         (len(grouped) * pattern_count))
    patterns = tuple(frozenset(items) for items in combinations(range(d), b))
    offsets = [d + group_index * pattern_count for group_index in range(len(grouped))]
    variable_count = d + len(grouped) * pattern_count
    c = np.zeros(variable_count)
    for group_index, (row, multiplicity) in enumerate(grouped):
        offset = offsets[group_index]
        for pattern_index, deleted in enumerate(patterns):
            c[offset + pattern_index] = multiplicity * _row_value(row, deleted)

    eq_rows = []
    eq_cols = []
    eq_data = []
    beq = []
    eq_index = 0
    # Exact cardinality on shared marginals.
    for candidate in range(d):
        eq_rows.append(eq_index)
        eq_cols.append(candidate)
        eq_data.append(1.0)
    beq.append(float(b))
    eq_index += 1
    for group_index, _ in enumerate(grouped):
        offset = offsets[group_index]
        for pattern_index in range(pattern_count):
            eq_rows.append(eq_index)
            eq_cols.append(offset + pattern_index)
            eq_data.append(1.0)
        beq.append(1.0)
        eq_index += 1
        for candidate in range(d):
            eq_rows.append(eq_index)
            eq_cols.append(candidate)
            eq_data.append(-1.0)
            for pattern_index, deleted in enumerate(patterns):
                if candidate in deleted:
                    eq_rows.append(eq_index)
                    eq_cols.append(offset + pattern_index)
                    eq_data.append(1.0)
            beq.append(0.0)
            eq_index += 1
    aeq = coo_matrix((eq_data, (eq_rows, eq_cols)),
                     shape=(eq_index, variable_count)).tocsr()

    if conflict_order not in (0, 2, 3):
        raise ValueError("conflict_order must be 0, 2, or 3")
    # Each spec is (terms, rhs), encoding sum(trigger(term)) <= rhs.
    conflict_specs = []
    if conflict_order:
        terms = []
        for group_index, (row, _) in enumerate(grouped):
            values = list(row.values[:b + 1])
            values.extend([0.0] * (b + 1 - len(values)))
            prefix = set()
            for rank, candidate in enumerate(row.candidate_indices[:b]):
                prefix.add(candidate)
                if values[rank] - values[rank + 1] > 1e-15:
                    terms.append((group_index, frozenset(prefix)))
        pair_infeasible = set()
        for left_index, left in enumerate(terms):
            for right_index in range(left_index + 1, len(terms)):
                right = terms[right_index]
                if left[0] != right[0] and len(left[1] | right[1]) > b:
                    pair_infeasible.add((left_index, right_index))
                    conflict_specs.append(((left, right), 1.0))
                    if len(conflict_specs) > max_conflicts:
                        raise ValueError("cross-source conflict limit exceeded")
        if conflict_order >= 3:
            for first in range(len(terms)):
                for second in range(first + 1, len(terms)):
                    if (first, second) in pair_infeasible:
                        continue
                    union = terms[first][1] | terms[second][1]
                    for third in range(second + 1, len(terms)):
                        if ((first, third) in pair_infeasible
                                or (second, third) in pair_infeasible):
                            continue
                        family = (terms[first], terms[second], terms[third])
                        if len({term[0] for term in family}) < 2:
                            continue
                        if len(union | terms[third][1]) > b:
                            conflict_specs.append((family, 2.0))
                            if len(conflict_specs) > max_conflicts:
                                raise ValueError("cross-source conflict limit exceeded")
    ub_rows = []
    ub_cols = []
    ub_data = []
    conflict_rhs = []
    for constraint_index, (family, rhs) in enumerate(conflict_specs):
        conflict_rhs.append(rhs)
        for group_index, prefix in family:
            offset = offsets[group_index]
            for pattern_index, deleted in enumerate(patterns):
                if prefix <= deleted:
                    ub_rows.append(constraint_index)
                    ub_cols.append(offset + pattern_index)
                    ub_data.append(1.0)
    aub = coo_matrix((ub_data, (ub_rows, ub_cols)),
                     shape=(len(conflict_specs), variable_count)).tocsr()
    started = perf_counter()
    result = linprog(
        c,
        A_ub=aub if conflict_specs else None,
        b_ub=np.asarray(conflict_rhs) if conflict_specs else None,
        A_eq=aeq,
        b_eq=np.asarray(beq),
        bounds=(0.0, 1.0),
        method="highs",
    )
    elapsed = perf_counter() - started
    if not result.success:
        raise RuntimeError("local hull LP failed: %s" % result.message)
    return OptimizationResult(
        name={0: "local_hull_l2", 2: "local_hull_l3", 3: "local_hull_l4"}[conflict_order],
        objective=float(result.fun),
        solve_seconds=elapsed,
        status=str(result.message),
        variables=variable_count,
        equalities=eq_index,
        inequalities=len(conflict_specs),
        diagnostics={"groups": len(grouped), "patterns": pattern_count,
                     "conflicts": len(conflict_specs)},
    )
