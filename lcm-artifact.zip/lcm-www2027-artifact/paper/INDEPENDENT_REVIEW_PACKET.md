# Independent proof and novelty review packet

This packet supports an optional quality check. WWW 2027 does not require
authors to obtain external proof or novelty approval before submitting.

Please review the claims independently rather than treating passing tests or
the existing prose as proof. Record a verdict for every question: **valid**,
**repairable**, or **blocking**, with a page/line reference and a proposed
correction. The intended venue is the WWW 2027 research track, so a claim that
is mathematically correct but routine in adjacent literature still needs to be
identified.

## Frozen object under review

- Paper: `paper/main.pdf` and `paper/main.tex`.
- Paper PDF SHA-256:
  `b866d7969787866492cb5dabe0da1d3c93fd8a2090c60ba96767a95a46094c2e`.
- Claim ledger: `paper/CLAIM_EVIDENCE.md`.
- Theory derivations: `notes/theory-audit.md`.
- Literature boundary: `notes/literature-audit.md`.
- Frozen implementation hash:
  `6f9f44a2750ac2e7a90a253606be686aa1b8352adcdcd8d05c605ed4c810cf25`.
- Runner version: `2026-09-26-resume-v4`.
- Computational audit: 4,096 directed simple graphs on four vertices, 24,576
  target-budget cells, 55,296 feasible deletion sets, and 98,304 exact
  Lagrangian checks.
- Post-freeze BlockMatch audit: all 262,144 ordered six-set systems over a
  three-element universe at every positive cardinality (1,572,864 ordinary
  coverage cells plus 1,572,864 private-element LCM augmentations), 1,476
  random weighted-coverage cells, 248 random LCM cells, and explicit tight DAG
  families for `k=4,5,6,7`, all checked with a separate exhaustive reference;
  120 further cells compare the polynomial blossom implementation with that
  reference.
- Large-graph protocol: `configs/SCALABILITY_EXTENSION_PROTOCOL.json`; 144
  successful method rows, including 60 sealed target-budget pairs across the
  four additional original-study graphs.

The intended approximation claim has two tiers. BlockMatch is a higher-cost
polynomial algorithm with factor
`min{floor(k/2), h_G(v)/k} <= sqrt(h_G(v)/2)` for `k>=2`; it is exact for
`k<=3`. SingletonSort remains the scalable rule and improves the published A1
factor from `sqrt(2 h_G(v))` to `sqrt(h_G(v))` at the same `O(d(n+m))`
asymptotic time. The profile and closure network support exact search and
instance lower bounds. The paper does not claim that nearest-source
propagation, nested prefix variables, matching itself, min-cut closure, or
conflict graphs are new in general.

## A. Problem reduction and profile

1. Does deleting the target vertex before computing distances preserve the
   last-entry identity for every source, including in graphs with cycles and
   paths that would otherwise revisit the target?
2. Does monotonicity justify replacing `|D| <= b` by `|D| = b` for every
   stated case? Check `b=0`, `b=d`, unreachable sources, ties, and zero-valued
   candidates separately.
3. Does retaining the top `b+1` candidates per source preserve the row maximum
   for all deletion sets of size at most `b`? Check whether tie-breaking is
   used consistently in the theorem, algorithm, and implementation.
4. In the multi-label FIFO construction, can a vertex fill its `b+1` slots
   with longer labels before a nearer label arrives? Verify the first-enqueue
   argument at equal distances and terminal initialization collisions.
5. Does each accepted state scan exactly the edge orientation required by a
   reverse search from terminals? Re-derive the work and space bounds without
   assuming a dense `|V| x d` distance matrix.

## B. SingletonSort approximation

1. Verify all three inequalities
   `g(R_sc) <= sum_{u in R_sc} c_u <= sum_{u in R*} c_u <= k g(R*)`.
   Pay particular attention to whether one row may contain several retained
   candidates and whether self-source contributions are present.
2. Verify `OPT >= k` for directed simple graphs and every feasible retained
   set. State precisely which source contributes one for each retained
   in-neighbor.
3. Verify `g(R_sc) <= h_G(v)` and the minimization approximation-ratio
   convention. Check the algebra yielding
   `min{k, h_G(v)/k} <= sqrt(h_G(v))` for all real `h_G(v) >= k`.
4. Check exactness for `k=1`, including equal singleton costs.
5. Reconstruct the DAG tight family. Prove that retaining all `B` candidates
   is globally optimal and that every mixed retained set is worse for the
   stated parameter range; then recompute the limiting ratio.
6. Compare the theorem line by line with the formal WWW 2024 A1 theorem. Confirm
   that `h_G(v)`, the budget convention, and runtime model are identical enough
   for the claimed constant-factor sharpening.
7. Search for the singleton-cost ranking or the same inequality in weighted
   Minimum k-Union, cardinality-constrained monotone submodular minimization,
   facility-location/coverage objectives, and centrality hiding. If it is an
   immediate named result, identify the earliest citable source and recommend
   a narrower positioning.
8. Re-derive BlockMatch: normalized submodularity implies subadditivity; the
   selected pair/one-triple partition has no larger surrogate than a partition
   of the optimum; and each optimum block costs at most OPT. Check exactness
   at `k=1,2,3`, the odd-cardinality minimum-triple argument, and the algebra for
   `min{floor(k/2),h/k} <= sqrt(h/2)`.
9. Reconstruct the BlockMatch DAG family for even and odd `k`. Prove both that
   the minimum block surrogate chooses all A candidates and that all B is the
   true LCM optimum. Compare the theorem directly with Chen et al., JCSS 2026,
   including their full text rather than only the `2 sqrt(d)` abstract claim.

## C. Lagrangian min-cut certificate

1. Re-derive the telescoping prefix objective with base
   `B = sum_s a_{s,b+1}` and `y_sj = OR_{l<=j} x_{u_sl}`. Confirm it equals the
   graph objective at exactly `k=d-b` retained candidates.
2. Starting from `g_b(x) + lambda(k-sum x)`, derive every source/candidate,
   implication, chain, and sink capacity and confirm the constant
   `B + C_lambda - lambda d + lambda k`.
3. Verify the lower-bound direction for minimization for every `lambda >= 0`.
   Check what changes if the cut returns fewer or more than `k` candidates.
4. Prove that rounding every positive objective capacity downward preserves a
   rigorous lower bound after all constants are included. Check integer scale,
   zero weights, infinite capacities, and possible negative reported values.
5. Verify that exact rational reconstruction covers both reciprocals and the
   multiplier. Establish that a minimum cut retaining exactly `k` candidates
   gives a feasible solution whose value equals the lower bound, including
   ties among multiple minimum cuts.
6. Identify which parts follow directly from maximum-weight closure,
   Lagrangian cardinality relaxation, or prior nested-monomial formulations.
   Recommend citations or wording wherever the paper currently sounds broader
   than the LCM specialization supports.

## D. Empirical design and inference

1. Audit the revised blind split and confirm that every inspected calibration
   target is excluded. Confirm that stale runner rows cannot enter summaries.
2. Check that all methods use exactly `b` distinct deletions and that recorded
   objectives are recomputed by the independent original-graph BFS oracle.
3. Verify the denominators and direction of every reported improvement and
   certified-gap percentage. Recompute the 197/1/0, 22/176/0, nine exact hits,
   and budget-stratified gap summaries from filtered logs.
4. Check that target-clustered bootstrap resamples targets while keeping their
   three budgets together. State what population the intervals do and do not
   cover.
5. Judge whether the four-graph strict-search test plus the four-graph,
   five-test-target scalability extension support the claims actually made.
   Flag any sentence that generalizes to all Web graphs, users, diffusion,
   exposure, or real interventions.
6. Check the profile benchmark as a mechanism study. Ensure one-target
   measurements, Python allocation tracing, the omitted Twitter reference, and
   the high-budget slowdown are visible wherever the speed claim appears.
7. Audit the separately frozen large-graph extension. Verify its pre-result
   implementation/config/target hashes, pilot gate, exclusion of 24 pilot
   method cells from the primary 60-pair aggregate, and the reported 6/52/2
   W/T/L. Flag any wording that turns a zero median and 52 ties into an
   empirical dominance claim.

## E. Novelty and WWW fit

1. Trace all papers citing Miyauchi et al. (WWW 2024), plus 2025--2026 arXiv
   work using the exact title, model, or authors. Report the query date and
   databases used.
2. Compare the profile builder with Har-Peled's all-vertices nearest-terminal
   algorithm; the prefix formulation with Chen--Dash--Günlük; and the
   Lagrangian network with parametric-flow, maximum-closure, and
   precedence-constrained-knapsack literature.
3. Decide whether the sharper SingletonSort factor is enough for a WWW long
   paper when combined with exact profile search, rigorous instance
   certificates, and the frozen evaluation. Give the strongest likely reviewer
   objection in one paragraph.
4. Check that the first-page Web relevance defines a specific structural audit
   task arising from incoming links on Web graphs. Flag arguments that rely
   only on the use of social-network data.
5. Suggest no more than three additional comparisons or analyses. Each must
   name the claim it could change; avoid open-ended experiment expansion after
   the frozen protocol.

## Review record

Reviewer declaration (store the completed copy privately):

- Reviewer name and affiliation:
- Review date:
- Independent of this project's design, implementation, experiments, and
  writing before receiving this packet: [yes/no; explain]
- Conflict or relationship with the author that affects independence:
- Reviewed PDF SHA-256 matches the frozen value above: [yes/no]

| Section | Reviewer | Date | Verdict | Blocking issue or required edit |
|---|---|---|---|---|
| A. Reduction/profile |  |  |  |  |
| B. Singleton theorem |  |  |  |  |
| C. Certificate |  |  |  |  |
| D. Experiments |  |  |  |  |
| E. Novelty/fit |  |  |  |  |

A submission-ready verdict requires no blocking item, a documented disposition
for every repairable item, and a final cross-check that `CLAIM_EVIDENCE.md`
matches the revised paper.

## October 15 update

The current proof map includes the marginal-floor theorem and full parity proof,
modern curvature/MUB positioning, exact integer blossom implementation, and
48-cell low-degree exact-optimum supplement. Earlier page or source locations
in historical notes are superseded by `REVIEWER_PROOF_MAP.md`. No reviewer
contact or email dispatch is authorized by this packet.
