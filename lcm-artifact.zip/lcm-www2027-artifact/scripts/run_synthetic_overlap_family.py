"""Generate a reproducible set-cover graph family exposing multi-edge synergy."""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lcm.algorithms import (  # noqa: E402
    algorithm1,
    brute_force_optimum,
    greedy_deletion,
    multi_start_one_swap,
    overlap_search,
    singleton_sort,
)
from lcm.graph import from_integer_edges  # noqa: E402
from lcm.objective import harmonic_after_deletions  # noqa: E402
from lcm.profile import build_budget_profile  # noqa: E402


# Candidate indices in each tuple define one group of sources that can reach
# exactly those candidates in one step.  Counts are multiplied by ``scale``.
BASE_COUNTS = {
    (10, 11): 4, (2, 8, 11): 3, (0, 3, 4): 3, (5, 7, 8): 3,
    (2, 4, 6, 11): 3, (7, 9): 3, (2, 4, 8): 3, (3, 10): 3,
    (7, 8, 9, 10): 3, (3, 5): 2, (0, 2, 6, 10): 2,
    (1, 2, 6, 7): 2, (4, 5): 1, (2, 3, 8, 11): 1,
    (2, 6, 7, 10): 1, (1, 3, 10, 11): 1, (1, 5): 1,
    (0, 4, 7): 1, (8, 9): 1,
}


def make_graph(scale):
    degree = 12
    edges = [(candidate + 1, 0) for candidate in range(degree)]
    source = degree + 1
    for subset, count in BASE_COUNTS.items():
        for _ in range(count * scale):
            edges.extend((source, candidate + 1) for candidate in subset)
            source += 1
    return from_integer_edges(source, edges)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scales", type=int, nargs="+", default=[1, 2, 4, 8, 16])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args(argv)
    records = []
    for scale in args.scales:
        graph = make_graph(scale)
        profile = build_budget_profile(graph, 0, 6)
        a1 = algorithm1(graph, profile)
        greedy = greedy_deletion(profile)
        singleton, _ = singleton_sort(graph, profile)
        local = multi_start_one_swap(
            profile, [a1, greedy, singleton], max_rounds=100
        )
        overlap = overlap_search(
            profile, [a1, greedy, singleton],
            swap_rounds=100, exchange_rounds=10,
        )
        optimum, optimum_deleted, combinations = brute_force_optimum(profile)
        for result in (a1, greedy, singleton, local, overlap):
            exact = harmonic_after_deletions(graph, 0, result.deleted)
            if abs(exact - result.objective) > 1e-10:
                raise AssertionError("profile/oracle mismatch")
        if abs(overlap.objective - optimum) > 1e-10:
            raise AssertionError("overlap did not attain the expected optimum")
        records.append({
            "scale": scale,
            "n": graph.n,
            "m": graph.m,
            "sources": 41 * scale,
            "degree": 12,
            "budget": 6,
            "algorithm1": a1.objective,
            "greedy": greedy.objective,
            "singleton_sort": singleton.objective,
            "multi_start_one_swap": local.objective,
            "overlap_search": overlap.objective,
            "optimum": optimum,
            "combinations": combinations,
            "multi_to_overlap_improvement": (
                (local.objective - overlap.objective) / local.objective
            ),
            "multi_deleted_candidate_indices": [u - 1 for u in local.deleted],
            "overlap_deleted_candidate_indices": [u - 1 for u in overlap.deleted],
            "optimum_deleted_candidate_indices": [u - 1 for u in optimum_deleted],
            "prefix_rounds": overlap.diagnostics["prefix_diagnostics"]["rounds"],
            "prefix_evaluations": overlap.diagnostics["prefix_diagnostics"]["evaluations"],
        })
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("".join(
        json.dumps(record, sort_keys=True) + "\n" for record in records
    ))
    lines = [
        "# Synthetic Overlap Mechanism",
        "",
        "The target has 12 in-neighbors and budget 6. Each auxiliary source reaches one listed candidate subset in one step; duplicating all source groups by `scale` changes their weight without changing the set system. Candidate self-contributions remain one. Exact enumeration checks all 924 strict-budget deletion sets.",
        "",
        "| Scale | Sources | A1 / Greedy / Singleton | Multi-start 1-swap | Prefix exchange | OPT | Improvement over 1-swap |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in records:
        lines.append(
            "| %d | %d | %.1f | %.1f | %.1f | %.1f | %.2f%% |" % (
                row["scale"], row["sources"], row["algorithm1"],
                row["multi_start_one_swap"], row["overlap_search"],
                row["optimum"], 100.0 * row["multi_to_overlap_improvement"],
            )
        )
    lines += [
        "",
        "For scale t, the three one-shot starts have value 6+15.5t, one-swap reaches 6+13.5t, and one prefix exchange reaches the optimum 6+13t. The strict-budget improvement over the 1-swap local optimum is 0.5t/(6+13.5t), approaching 1/27. This is a controlled mechanism example, not a worst-case guarantee for prefix exchange.",
    ]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text("\n".join(lines) + "\n")
    print(args.report)


if __name__ == "__main__":
    main()
