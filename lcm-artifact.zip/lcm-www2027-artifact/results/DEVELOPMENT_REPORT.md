# Development Results

Generated from 12 JSONL suites. These are development-set observations, not frozen test results.

## Strict-budget solution quality

| Graph (n/m/hash) | Target index / ID | b/d | A1 | Greedy | Parametric repair | 1-swap | Overlap | Hybrid | Best | Valid LB | Conflict Δ | Gap | Exact? |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| 1224/19022/10f296b6 | 0 / 669 | 0.25 (84) | 533.4167 | 517.5500 | 502.9000 | 514.3167 | 513.4000 | 502.9000 | 502.9000 | 502.9000 | — | 0.000 | yes |
| 1224/19022/10f296b6 | 0 / 669 | 0.50 (168) | 426.4762 | 400.2357 | 394.6024 | 393.6024 | 393.6024 | 393.6024 | 393.6024 | 393.0735 | 0.0333 | 0.001 | no |
| 1224/19022/10f296b6 | 0 / 669 | 0.75 (252) | 261.9262 | 331.4190 | 255.9833 | 255.9833 | 255.9833 | 255.9833 | 255.9833 | 255.7045 | 0.0000 | 0.001 | no |
| 1224/19022/10f296b6 | 1 / 201 | 0.25 (69) | 513.6762 | 491.3595 | 489.8595 | 488.4929 | 488.4929 | 488.4929 | 488.4929 | 488.4929 | — | 0.000 | yes |
| 1224/19022/10f296b6 | 1 / 201 | 0.50 (138) | 435.6429 | 411.3429 | 399.6869 | 404.1869 | 403.7536 | 399.1036 | 399.1036 | 399.1036 | — | 0.000 | yes |
| 1224/19022/10f296b6 | 1 / 201 | 0.75 (207) | 351.6595 | 330.5702 | 330.5702 | 323.7464 | 323.7464 | 323.7464 | 323.7464 | 304.0661 | 2.8704 | 0.061 | no |
| 465017/834797/b152b5b9 | 0 / 425352 | 0.25 (49) | 603.5325 | 585.0139 | 585.0139 | 585.0139 | — | 582.8385 | 582.8385 | 581.8366 | 0.0000 | 0.002 | no |
| 465017/834797/b152b5b9 | 0 / 425352 | 0.50 (99) | 489.2358 | 491.6727 | 476.3425 | 482.2314 | — | 473.5409 | 473.5409 | 462.8869 | 0.0000 | 0.022 | no |
| 465017/834797/b152b5b9 | 0 / 425352 | 0.75 (149) | 364.2037 | 410.5548 | 353.1951 | 354.9438 | — | 350.7526 | 350.7526 | 330.6367 | 0.8086 | 0.057 | no |
| 4658/40133/fa0a8513 | 0 / 4073 | 0.25 (90) | 725.3333 | 703.6167 | 703.6167 | 703.6167 | 702.8667 | 702.8667 | 702.8667 | 691.4632 | 0.0000 | 0.016 | no |
| 4658/40133/fa0a8513 | 0 / 4073 | 0.50 (180) | 640.4000 | 622.2000 | 622.0667 | 622.2000 | 621.6167 | 621.5667 | 621.5667 | 568.9814 | 0.0000 | 0.085 | no |
| 4658/40133/fa0a8513 | 0 / 4073 | 0.75 (270) | 491.5167 | 508.4500 | 485.5333 | 485.3167 | 485.3167 | 485.3167 | 485.3167 | 423.1695 | 3.3738 | 0.128 | no |
| 1224/33430/fa0e6ac9 | 0 / 1113 | 0.25 (87) | 657.8167 | 631.2667 | 629.4333 | 631.1000 | — | 629.3000 | 629.3000 | 628.4135 | 0.0000 | 0.001 | no |
| 1224/33430/fa0e6ac9 | 0 / 1113 | 0.50 (175) | 576.6500 | 560.3000 | 555.0333 | 558.0833 | — | 553.7000 | 553.7000 | 533.5603 | 0.0000 | 0.036 | no |
| 1224/33430/fa0e6ac9 | 0 / 1113 | 0.75 (263) | 486.9167 | 478.3167 | 464.9833 | 470.2333 | — | 464.9833 | 464.9833 | 427.3606 | 0.3333 | 0.081 | no |

The lower bound is the maximum of registered trivial, quantized-flow, exact rational, and separated-conflict bounds. Conflict Δ is the exact additive gain over the zero-conflict flow in the corresponding audit; missing cells were not run.

## Small-instance relaxation audit

- L1 > L0: 33/41 instances; mean additive improvement 1.256019; maximum 3.866667.
- L2 > L1: 14/41 instances; mean additive improvement 0.071184; maximum 0.770833.
- L3 > L2: 3/41 instances; mean additive improvement 0.005259; maximum 0.166667.
- L4 > L3: 0/41 instances; mean additive improvement 0.000000; maximum 0.000000.
- L4 retains a positive numerical gap on 5/41 instances; maximum 0.333333.

## Real-graph pair-cut LP pilot

| Target | b/d | L1 | L1 + pair cuts | Improvement | Cuts | Seconds |
|---|---:|---:|---:|---:|---:|---:|
| 0 | 0.25 | 502.900000 | 502.900000 | 0.000000 | 0 | 1.16 |
| 0 | 0.50 | 393.041178 | 393.288722 | 0.247544 | 54 | 20.91 |
| 0 | 0.75 | 255.704506 | 255.737554 | 0.033047 | 20 | 113.32 |
| 1 | 0.25 | 488.492857 | 488.492857 | 0.000000 | 0 | 0.80 |
| 1 | 0.50 | 399.103571 | 399.103571 | 0.000000 | 0 | 4.51 |
| 1 | 0.75 | 301.196190 | 303.983593 | 2.787402 | 2000 | 244.82 |

These SciPy LP values are numerical comparisons. They are not reported as rigorous certificates.

## Interpretation

- This report uses development targets only; it cannot establish generalization.
- Multi-start local search is an empirical strong baseline/candidate component, not a novelty claim by itself.
- The cross-source cuts are worth retaining only if their gain survives stronger single-source baselines and frozen real-graph tests.
- Negative and zero-improvement cases remain in the report.
