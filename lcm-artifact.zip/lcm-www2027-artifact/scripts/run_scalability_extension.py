"""Run the preregistered A1-vs-SingletonSort scalability extension."""
import argparse
import hashlib
import json
import resource
import sys
import traceback
from pathlib import Path
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scalability.compact_graph import (  # noqa: E402
    BFSWorkspace, ReverseCSR, build_reverse_csr, sha256,
)


RUNNER_VERSION = "2026-09-26-scalability-v1"


def append(path, record):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")
        handle.flush()


def load_target_ids(path):
    return [int(value) for value in Path(path).read_text().split()]


def record_key(record):
    return (record.get("target_index"), record.get("budget_ratio"),
            record.get("method"), record.get("config_hash"),
            record.get("runner_version"))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--target-index", type=int, action="append",
                        help="override config target_indices; may be repeated")
    args = parser.parse_args(argv)
    config_bytes = args.config.read_bytes()
    config = json.loads(config_bytes)
    config_hash = hashlib.sha256(config_bytes).hexdigest()
    graph_path = ROOT / config["graph"]
    cache_path = ROOT / config["reverse_csr_cache"]
    build_started = perf_counter()
    build_reverse_csr(
        graph_path, cache_path,
        expected_sha256=config["graph_sha256"],
        expected_n=config["n"], expected_m=config["m"],
    )
    cache_build_seconds = perf_counter() - build_started
    targets = load_target_ids(ROOT / config["targets_file"])
    completed = set()
    if args.output.exists():
        for line in args.output.read_text().splitlines():
            row = json.loads(line)
            if row.get("status") == "ok":
                completed.add(record_key(row))

    with ReverseCSR(cache_path) as graph:
        workspace = BFSWorkspace(graph)
        target_indices = (args.target_index if args.target_index is not None
                          else config["target_indices"])
        for target_index in target_indices:
            target = targets[target_index]
            candidates = sorted(int(value) for value in graph.incoming(target))
            d = len(candidates)
            if d < 1:
                raise ValueError("target has zero indegree")
            score_started = perf_counter()
            a1_scores = [workspace.harmonic_without_target_inedges(u, target)
                         for u in candidates]
            a1_score_seconds = perf_counter() - score_started
            score_started = perf_counter()
            singleton_scores = [workspace.singleton_cost(u, target)
                                for u in candidates]
            singleton_score_seconds = perf_counter() - score_started
            empty_started = perf_counter()
            empty = workspace.lcm_objective(target)
            empty_seconds = perf_counter() - empty_started
            base = {
                "suite": config["name"],
                "runner_version": RUNNER_VERSION,
                "protocol_version": config["protocol_version"],
                "config_hash": config_hash,
                "graph_sha256": config["graph_sha256"],
                "n": graph.n,
                "m": graph.m,
                "cache_build_seconds": cache_build_seconds,
                "target_index": target_index,
                "target_internal_id": target,
                "target_original_label": str(graph.original_label(target)),
                "indegree": d,
                "empty_objective": empty,
                "empty_evaluation_seconds": empty_seconds,
                "a1_score_seconds": a1_score_seconds,
                "singleton_score_seconds": singleton_score_seconds,
            }
            for ratio in config["budget_ratios"]:
                budget = int(d * ratio)
                k = d - budget
                rankings = {
                    "algorithm1": set(sorted(
                        range(d), key=lambda i: (-a1_scores[i], candidates[i])
                    )[:budget]),
                    "singleton_sort": set(range(d)) - set(sorted(
                        range(d), key=lambda i: (singleton_scores[i], candidates[i])
                    )[:k]),
                }
                for method, deleted_indices in rankings.items():
                    key = (target_index, ratio, method, config_hash, RUNNER_VERSION)
                    if key in completed:
                        continue
                    deleted = tuple(candidates[i] for i in sorted(deleted_indices))
                    started = perf_counter()
                    try:
                        objective = workspace.lcm_objective(target, deleted)
                        record = {
                            **base,
                            "budget_ratio": ratio,
                            "budget": budget,
                            "method": method,
                            "deleted_count": len(deleted),
                            "deleted_internal_ids": list(deleted),
                            "objective_exact": objective,
                            "remaining_fraction": objective / empty if empty else None,
                            "evaluation_seconds": perf_counter() - started,
                            "peak_process_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                            "status": "ok",
                        }
                    except Exception as error:
                        record = {
                            **base, "budget_ratio": ratio, "budget": budget,
                            "method": method, "status": "error",
                            "error": repr(error), "traceback": traceback.format_exc(),
                        }
                    append(args.output, record)
                    completed.add(record_key(record))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
