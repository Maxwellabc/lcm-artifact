"""Run profile builders in isolated subprocesses with resumable JSONL logs."""
import argparse
import json
import subprocess
import sys
from pathlib import Path


def key(row):
    return (
        row.get("dataset"), row.get("target_index"),
        row.get("budget_ratio"), row.get("mode"),
    )


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    config = json.loads(args.config.read_text())
    completed = set()
    if args.output.exists():
        for line in args.output.read_text().splitlines():
            row = json.loads(line)
            if row.get("status") == "ok":
                completed.add(key(row))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    worker = Path(__file__).with_name("profile_benchmark_worker.py")
    with args.output.open("a", encoding="utf-8") as handle:
        for case in config["cases"]:
            for mode, ratios in case["modes"].items():
                for ratio in ratios:
                    context = {
                        "dataset": case["dataset"],
                        "target_index": case["target_index"],
                        "budget_ratio": ratio,
                        "mode": mode,
                    }
                    if key(context) in completed:
                        continue
                    command = [
                        sys.executable, str(worker),
                        "--graph", case["graph"],
                        "--targets", case["targets"],
                        "--target-index", str(case["target_index"]),
                        "--budget-ratio", str(ratio),
                        "--mode", mode,
                    ]
                    try:
                        process = subprocess.run(
                            command, capture_output=True, text=True,
                            timeout=config.get("timeout_seconds", 900),
                        )
                        if process.returncode:
                            row = {
                                **context, "status": "error",
                                "returncode": process.returncode,
                                "stderr": process.stderr[-4000:],
                            }
                        else:
                            row = {**json.loads(process.stdout), **context}
                    except subprocess.TimeoutExpired as error:
                        row = {
                            **context, "status": "timeout",
                            "timeout_seconds": config.get("timeout_seconds", 900),
                            "stderr": (error.stderr or "")[-4000:],
                        }
                    handle.write(json.dumps(row, sort_keys=True) + "\n")
                    handle.flush()
                    print(json.dumps(row, sort_keys=True))


if __name__ == "__main__":
    main()
