"""Audit and summarize the preregistered million-scale extension."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scalability.compact_graph import ReverseCSR, build_reverse_csr  # noqa: E402
from scripts.run_scalability_extension import RUNNER_VERSION  # noqa: E402


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def classify(a1, singleton):
    if math.isclose(a1, singleton, rel_tol=1e-12, abs_tol=1e-9):
        return "tie"
    return "win" if singleton < a1 else "loss"


def distribution(values):
    return {
        "count": len(values),
        "mean": statistics.mean(values),
        "median": statistics.median(values),
        "minimum": min(values),
        "maximum": max(values),
    }


def summarize_pairs(pairs):
    outcomes = Counter(pair["outcome"] for pair in pairs)
    improvements = [pair["relative_improvement"] for pair in pairs]
    return {
        "cells": len(pairs),
        "wins": outcomes["win"],
        "ties": outcomes["tie"],
        "losses": outcomes["loss"],
        "relative_improvement": distribution(improvements),
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-markdown", type=Path, required=True)
    parser.add_argument("--latex-output", type=Path)
    args = parser.parse_args(argv)

    protocol = json.loads(args.protocol.read_text())
    for relative, expected in protocol["implementation_sha256"].items():
        actual = sha256(ROOT / relative)
        if actual != expected:
            raise RuntimeError("implementation hash mismatch for %s" % relative)
    for relative, expected in protocol["config_sha256"].items():
        if sha256(ROOT / relative) != expected:
            raise RuntimeError("config hash mismatch for %s" % relative)
    for relative, expected in protocol["target_metadata_sha256"].items():
        if sha256(ROOT / relative) != expected:
            raise RuntimeError("target metadata hash mismatch for %s" % relative)

    rows = [json.loads(line) for line in args.results.read_text().splitlines()
            if line.strip()]
    actual = {}
    for row in rows:
        key = (row["suite"], row["target_index"], row["budget_ratio"],
               row["method"])
        if key in actual:
            raise RuntimeError("duplicate experimental cell: %r" % (key,))
        actual[key] = row

    expected_keys = set()
    target_summaries = []
    pairs = []
    gate = {}
    for config_relative in protocol["configs"]:
        config_path = ROOT / config_relative
        config = json.loads(config_path.read_text())
        config_hash = sha256(config_path)
        targets = json.loads((ROOT / config["target_metadata"]).read_text())
        target_by_index = {row["target_index"]: row for row in targets["targets"]}
        runner_target_ids = [int(value) for value in
                             (ROOT / config["targets_file"]).read_text().split()]
        frozen_target_ids = [row["internal_id"] for row in targets["targets"]]
        if runner_target_ids != frozen_target_ids:
            raise RuntimeError("runner target IDs differ from frozen metadata: %s" %
                               config["targets_file"])
        build_reverse_csr(
            ROOT / config["graph"], ROOT / config["reverse_csr_cache"],
            expected_sha256=config["graph_sha256"],
            expected_n=config["n"], expected_m=config["m"],
        )
        with ReverseCSR(ROOT / config["reverse_csr_cache"]) as graph:
            for target_index in config["target_indices"]:
                metadata = target_by_index[target_index]
                target = metadata["internal_id"]
                candidates = set(int(value) for value in graph.incoming(target))
                timing = {}
                for ratio in config["budget_ratios"]:
                    method_rows = {}
                    for method in config["methods"]:
                        key = (config["name"], target_index, ratio, method)
                        expected_keys.add(key)
                        if key not in actual:
                            raise RuntimeError("missing experimental cell: %r" % (key,))
                        row = actual[key]
                        method_rows[method] = row
                        if row.get("status") != "ok":
                            raise RuntimeError("non-ok cell: %r" % (key,))
                        fixed = {
                            "runner_version": RUNNER_VERSION,
                            "protocol_version": protocol["protocol_version"],
                            "config_hash": config_hash,
                            "graph_sha256": config["graph_sha256"],
                            "n": config["n"], "m": config["m"],
                            "target_internal_id": target,
                            "target_original_label": metadata["original_label"],
                            "indegree": metadata["indegree"],
                        }
                        for field, value in fixed.items():
                            if row.get(field) != value:
                                raise RuntimeError("%s mismatch in %r" % (field, key))
                        budget = int(metadata["indegree"] * ratio)
                        deleted = row["deleted_internal_ids"]
                        if (row["budget"] != budget or row["deleted_count"] != budget
                                or len(deleted) != budget
                                or len(set(deleted)) != budget
                                or not set(deleted).issubset(candidates)):
                            raise RuntimeError("budget/deletion invariant failed in %r" %
                                               (key,))
                        if (not math.isfinite(row["objective_exact"])
                                or row["objective_exact"] < 0):
                            raise RuntimeError("invalid objective in %r" % (key,))
                        expected_fraction = (row["objective_exact"] /
                                             row["empty_objective"])
                        if not math.isclose(row["remaining_fraction"],
                                            expected_fraction,
                                            rel_tol=1e-12, abs_tol=1e-12):
                            raise RuntimeError("remaining fraction mismatch in %r" %
                                               (key,))
                    a1 = method_rows["algorithm1"]["objective_exact"]
                    singleton = method_rows["singleton_sort"]["objective_exact"]
                    pairs.append({
                        "dataset": targets["dataset"],
                        "suite": config["name"],
                        "split": metadata["split"],
                        "target_index": target_index,
                        "target_original_label": metadata["original_label"],
                        "indegree": metadata["indegree"],
                        "budget_ratio": ratio,
                        "budget": method_rows["algorithm1"]["budget"],
                        "algorithm1_objective": a1,
                        "singleton_sort_objective": singleton,
                        "relative_improvement": ((a1 - singleton) / a1
                                                 if a1 else 0.0),
                        "outcome": classify(a1, singleton),
                    })
                    timing["algorithm1"] = method_rows["algorithm1"][
                        "a1_score_seconds"]
                    timing["singleton_sort"] = method_rows["singleton_sort"][
                        "singleton_score_seconds"]
                target_summaries.append({
                    "dataset": targets["dataset"],
                    "n": config["n"], "m": config["m"],
                    "split": metadata["split"],
                    "target_index": target_index,
                    "target_original_label": metadata["original_label"],
                    "indegree": metadata["indegree"],
                    "algorithm1_score_seconds": timing["algorithm1"],
                    "singleton_sort_score_seconds": timing["singleton_sort"],
                    "peak_process_rss_bytes": max(
                        actual[(config["name"], target_index, ratio, method)]
                        ["peak_process_rss_bytes"]
                        for ratio in config["budget_ratios"]
                        for method in config["methods"]),
                })
        pilot = next(row for row in target_summaries
                     if row["dataset"] == targets["dataset"]
                     and row["target_index"] == 0)
        gate[targets["dataset"]] = {
            "passed": (pilot["algorithm1_score_seconds"] <= 3600
                       and pilot["singleton_sort_score_seconds"] <= 3600
                       and pilot["peak_process_rss_bytes"] <= 24 * 1024 ** 3),
            **pilot,
        }

    extras = set(actual) - expected_keys
    if extras:
        raise RuntimeError("unexpected experimental cells: %r" % sorted(extras))
    if len(rows) != len(expected_keys):
        raise RuntimeError("row count differs from expected cell count")
    if not all(entry["passed"] for entry in gate.values()):
        raise RuntimeError("sealed tests exist for a graph that failed its gate")

    tests = [pair for pair in pairs if pair["split"] == "test"]
    pilots = [pair for pair in pairs if pair["split"] == "development"]
    by_dataset = {
        dataset: summarize_pairs([pair for pair in tests
                                  if pair["dataset"] == dataset])
        for dataset in sorted({pair["dataset"] for pair in tests})
    }
    by_budget = {
        str(ratio): summarize_pairs([pair for pair in tests
                                     if pair["budget_ratio"] == ratio])
        for ratio in protocol["budget_ratios"]
    }
    test_targets = [row for row in target_summaries if row["split"] == "test"]
    timing = {
        "algorithm1_score_seconds": distribution(
            [row["algorithm1_score_seconds"] for row in test_targets]),
        "singleton_sort_score_seconds": distribution(
            [row["singleton_sort_score_seconds"] for row in test_targets]),
        "singleton_to_algorithm1_ratio": distribution([
            row["singleton_sort_score_seconds"] /
            row["algorithm1_score_seconds"]
            for row in test_targets]),
        "maximum_peak_process_rss_bytes": max(
            row["peak_process_rss_bytes"] for row in target_summaries),
    }
    report = {
        "protocol_sha256": sha256(args.protocol),
        "results_sha256": sha256(args.results),
        "runner_version": RUNNER_VERSION,
        "audit": {
            "rows": len(rows), "unique_cells": len(actual),
            "expected_cells": len(expected_keys), "all_status_ok": True,
            "all_budget_and_deletion_invariants_ok": True,
            "all_config_and_freeze_hashes_ok": True,
        },
        "resource_gates": gate,
        "pilot_quality": summarize_pairs(pilots),
        "test_quality": summarize_pairs(tests),
        "test_quality_by_dataset": by_dataset,
        "test_quality_by_budget": by_budget,
        "test_timing": timing,
        "target_timing": target_summaries,
        "paired_cells": pairs,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")

    overall = report["test_quality"]
    imp = overall["relative_improvement"]
    lines = [
        "# Million-scale scalability extension",
        "",
        "The four omitted large graphs contribute 20 sealed test targets and "
        "60 paired target-budget cells. Development pilots are reported "
        "separately and excluded from the primary aggregate.",
        "",
        "## Integrity and resource gates",
        "",
        "- Raw results: `%s` (%d/%d successful, unique cells)." % (
            report["results_sha256"], len(rows), len(expected_keys)),
        "- All frozen implementation, configuration, target, graph, budget, "
        "and deletion-set checks passed.",
        "",
        "| Dataset | Pilot indegree | A1 score s | Singleton score s | Peak MiB | Gate |",
        "|---|---:|---:|---:|---:|:---:|",
    ]
    for dataset, row in sorted(gate.items()):
        lines.append("| %s | %d | %.3f | %.3f | %.1f | %s |" % (
            dataset, row["indegree"], row["algorithm1_score_seconds"],
            row["singleton_sort_score_seconds"],
            row["peak_process_rss_bytes"] / 2 ** 20,
            "pass" if row["passed"] else "fail"))
    lines += [
        "", "## Sealed test quality", "",
        "SingletonSort versus Algorithm 1: **%d wins / %d ties / %d losses** "
        "over %d paired cells. Relative improvement `(A1-SS)/A1` has median "
        "%.6f%%, mean %.6f%%, minimum %.6f%%, and maximum %.6f%%." % (
            overall["wins"], overall["ties"], overall["losses"],
            overall["cells"], 100 * imp["median"], 100 * imp["mean"],
            100 * imp["minimum"], 100 * imp["maximum"]),
        "",
        "| Dataset | Cells | W/T/L | Median improvement | Mean improvement | Range |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for dataset, row in sorted(by_dataset.items()):
        d = row["relative_improvement"]
        lines.append("| %s | %d | %d/%d/%d | %.6f%% | %.6f%% | %.6f%% to %.6f%% |" % (
            dataset, row["cells"], row["wins"], row["ties"], row["losses"],
            100 * d["median"], 100 * d["mean"], 100 * d["minimum"],
            100 * d["maximum"]))
    lines += [
        "", "| Budget ratio | Cells | W/T/L | Median improvement | Mean improvement |",
        "|---:|---:|---:|---:|---:|",
    ]
    for ratio, row in by_budget.items():
        d = row["relative_improvement"]
        lines.append("| %s | %d | %d/%d/%d | %.6f%% | %.6f%% |" % (
            ratio, row["cells"], row["wins"], row["ties"], row["losses"],
            100 * d["median"], 100 * d["mean"]))
    ratio = timing["singleton_to_algorithm1_ratio"]
    lines += [
        "", "## Timing", "",
        "Across the 20 sealed targets, the SingletonSort/A1 score-time ratio "
        "has median %.3f and mean %.3f (range %.3f--%.3f). Peak process RSS "
        "over all pilot and test runs is %.1f MiB." % (
            ratio["median"], ratio["mean"], ratio["minimum"], ratio["maximum"],
            timing["maximum_peak_process_rss_bytes"] / 2 ** 20),
        "",
        "The extension compares only the two same-asymptotic sorting rules. "
        "It does not claim that the certificate or local-search components "
        "were run on these four large graphs.",
        "",
    ]
    args.output_markdown.write_text("\n".join(lines))
    if args.latex_output:
        display = {
            "citeseer": "CiteSeer", "youtube-links": "YouTube",
            "higgs-twitter-social": "Higgs", "soc-pokec-relationships": "Pokec",
        }
        slash = "\\"
        latex = [
            slash + "begin{tabular}{lrrrrr}", slash + "toprule",
            "Graph & $|V|$ & $|E|$ & W/T/L & Mean & Range " + slash * 2,
            slash + "midrule",
        ]
        for dataset, row in sorted(by_dataset.items()):
            d = row["relative_improvement"]
            meta = gate[dataset]
            latex.append(
                "%s & %s & %s & %d/%d/%d & %.3f\\%% & %.3f--%.3f\\%% %s" % (
                    display[dataset], f"{meta['n']:,}", f"{meta['m']:,}",
                    row["wins"], row["ties"], row["losses"],
                    100 * d["mean"], 100 * d["minimum"],
                    100 * d["maximum"], slash * 2))
        latex += [slash + "bottomrule", slash + "end{tabular}"]
        args.latex_output.parent.mkdir(parents=True, exist_ok=True)
        args.latex_output.write_text("\n".join(latex) + "\n")
    print(args.output_json)
    print(args.output_markdown)
    if args.latex_output:
        print(args.latex_output)


if __name__ == "__main__":
    main()
