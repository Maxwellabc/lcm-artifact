"""Budget-aware exact distance profiles."""
from collections import deque
from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Tuple

from .graph import DirectedGraph
from .objective import reverse_distances


@dataclass(frozen=True)
class ProfileRow:
    source: int
    candidate_indices: Tuple[int, ...]
    values: Tuple[float, ...]


@dataclass(frozen=True)
class BudgetProfile:
    target: int
    budget: int
    candidates: Tuple[int, ...]
    rows: Tuple[ProfileRow, ...]
    accepted_labels: int
    propagation_attempts: int

    @property
    def d(self) -> int:
        return len(self.candidates)

    @property
    def k(self) -> int:
        return self.d - self.budget

    def objective(self, deleted_tails: Iterable[int]) -> float:
        deleted_vertices = frozenset(deleted_tails)
        candidate_to_index = {u: i for i, u in enumerate(self.candidates)}
        try:
            deleted = {candidate_to_index[u] for u in deleted_vertices}
        except KeyError as error:
            raise ValueError("deletion set contains a non-candidate") from error
        if len(deleted) > self.budget:
            raise ValueError("profile is exact only for deletion sets within budget")
        total = 0.0
        for row in self.rows:
            for candidate_index, value in zip(row.candidate_indices, row.values):
                if candidate_index not in deleted:
                    total += value
                    break
        return total

    def base_lower_bound(self) -> float:
        """Return B_b = sum_s a_{s,b+1}, padding missing labels with zero."""
        position = self.budget
        return sum(row.values[position] for row in self.rows
                   if len(row.values) > position)

    def relaxation_objective_indices(self, deleted: Iterable[int]) -> float:
        """Evaluate the budget-truncated extension g_b on any binary set.

        ``deleted`` contains candidate indices, not graph vertex IDs.  This
        agrees with the original objective when at most ``budget`` candidates
        are deleted, and remains the min-cut objective outside that domain.
        """
        removed = frozenset(deleted)
        total = 0.0
        for row in self.rows:
            prefix_count = min(self.budget, len(row.candidate_indices))
            contribution = (row.values[self.budget]
                            if len(row.values) > self.budget else 0.0)
            for position in range(prefix_count):
                if row.candidate_indices[position] not in removed:
                    contribution = row.values[position]
                    break
            total += contribution
        return total


def build_budget_profile(
    graph: DirectedGraph, target: int, budget: int
) -> BudgetProfile:
    """Construct each source's nearest ``budget+1`` incoming neighbors.

    Labels are accepted when enqueued.  Multi-source FIFO order guarantees
    nondecreasing distance; accepting at most ``budget+1`` labels per vertex
    bounds accepted label states and the queue by O(n(b+1)).
    """
    candidates = tuple(graph.in_neighbors[target])
    d = len(candidates)
    if budget < 0 or budget > d:
        raise ValueError("budget must lie in [0, indegree(target)]")
    if d == 0:
        return BudgetProfile(target, budget, candidates, tuple(), 0, 0)
    # When b=d there is no (b+1)-st candidate, but all d labels are needed to
    # evaluate intermediate deletion sets; deleting all candidates yields 0.
    limit = min(budget + 1, d)
    accepted: List[List[Tuple[int, int]]] = [[] for _ in range(graph.n)]
    accepted_keys = set()
    queue = deque()
    for label, vertex in enumerate(candidates):
        key = vertex * d + label
        accepted_keys.add(key)
        accepted[vertex].append((label, 0))
        queue.append((vertex, label, 0))
    propagation_attempts = 0
    while queue:
        current, label, distance = queue.popleft()
        next_distance = distance + 1
        for predecessor in graph.in_neighbors[current]:
            if predecessor == target:
                continue
            propagation_attempts += 1
            if len(accepted[predecessor]) >= limit:
                continue
            key = predecessor * d + label
            if key in accepted_keys:
                continue
            accepted_keys.add(key)
            accepted[predecessor].append((label, next_distance))
            queue.append((predecessor, label, next_distance))
    rows = []
    for source, labels in enumerate(accepted):
        if source == target or not labels:
            continue
        rows.append(ProfileRow(
            source=source,
            candidate_indices=tuple(label for label, _ in labels),
            values=tuple(1.0 / (distance + 1) for _, distance in labels),
        ))
    return BudgetProfile(
        target=target,
        budget=budget,
        candidates=candidates,
        rows=tuple(rows),
        accepted_labels=len(accepted_keys),
        propagation_attempts=propagation_attempts,
    )


def singleton_costs(
    graph: DirectedGraph, target: int, candidates: Sequence[int]
) -> Tuple[float, ...]:
    """Compute c_u=sum_s 1/(1+dist_{G-v}(s,u)) exactly for every u."""
    costs = []
    for candidate in candidates:
        distances = reverse_distances(graph, candidate, omit_vertex=target)
        costs.append(sum(1.0 / (distance + 1) for source, distance in enumerate(distances)
                         if source != target and distance >= 0))
    return tuple(costs)
