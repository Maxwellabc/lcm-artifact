"""Summarize the declared post-summary conflict-certificate sensitivity audit."""
import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate", type=Path, action="append", required=True)
    parser.add_argument("--suite", type=Path, action="append", required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--audit-protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    protocol = json.loads(args.protocol.read_text())
    audit = json.loads(args.audit_protocol.read_text())
    code_hash = protocol["implementation_hash"]
    if audit["implementation_hash"] != code_hash:
        raise RuntimeError("audit/frozen implementation mismatch")

    hybrid = {}
    for path in args.suite:
        for line in path.read_text().splitlines():
            row = json.loads(line)
            if (row.get("implementation_hash") == code_hash
                    and row.get("runner_version") == protocol["runner_version"]
                    and row.get("method") == "certified_hybrid"
                    and row.get("status") == "ok"):
                hybrid[(row["graph_sha256"], row["target_index"], row["budget"])] = row

    rows = []
    for path in args.certificate:
        if path.exists():
            rows.extend(json.loads(line) for line in path.read_text().splitlines()
                        if line.strip())
    rows = [row for row in rows if row.get("implementation_hash") == code_hash]
    latest = {}
    for row in rows:
        latest[(row["graph_sha256"], row["target_index"], row["budget"])] = row
    rows = list(latest.values())
    errors = [row for row in rows if row.get("status") != "ok"]
    valid = [row for row in rows if row.get("status") == "ok"]
    joined = []
    for row in valid:
        key = (row["graph_sha256"], row["target_index"], row["budget"])
        frozen = hybrid.get(key)
        if frozen is None:
            raise RuntimeError("missing frozen upper bound for %r" % (key,))
        upper = frozen["objective_exact"]
        base = row["base_lower_bound_float"]
        strengthened = row["lower_bound_float"]
        tolerance = 1e-8 * max(1.0, upper)
        if strengthened + tolerance < base:
            raise RuntimeError("separation weakened a base certificate")
        if strengthened > upper + tolerance:
            raise RuntimeError("conflict lower bound exceeds feasible upper bound")
        base_gap = (upper - base) / upper if upper else 0.0
        strengthened_gap = (upper - strengthened) / upper if upper else 0.0
        joined.append({
            **row,
            "suite": frozen["suite"],
            "upper": upper,
            "base_gap": base_gap,
            "strengthened_gap": strengthened_gap,
            "gap_reduction": base_gap - strengthened_gap,
        })

    by_suite = defaultdict(list)
    for row in joined:
        by_suite[row["suite"]].append(row)
    lines = [
        "# Conflict-Certificate Sensitivity Audit",
        "",
        audit["selection_timing"],
        "",
        "| Dataset | Cells | Improved | Median LB increase | Median gap before | Median gap after | Median audit sec |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for suite in sorted(by_suite):
        group = by_suite[suite]
        improved = sum(row["improvement"] > 1e-12 for row in group)
        lines.append(
            "| %s | %d | %d | %.4f | %.2f%% | %.2f%% | %.2f |" % (
                suite, len(group), improved,
                statistics.median(row["improvement"] for row in group),
                100.0 * statistics.median(row["base_gap"] for row in group),
                100.0 * statistics.median(
                    row["strengthened_gap"] for row in group
                ),
                statistics.median(row["seconds"] for row in group),
            )
        )
    if joined:
        improved = [row for row in joined if row["improvement"] > 1e-12]
        lines += [
            "",
            "Across %d cells, conflicts improve %d certificates. The median gap reduction over all cells is %.3f percentage points; the maximum is %.3f points. Median total audit time is %.2f seconds." % (
                len(joined), len(improved),
                100.0 * statistics.median(row["gap_reduction"] for row in joined),
                100.0 * max(row["gap_reduction"] for row in joined),
                statistics.median(row["seconds"] for row in joined),
            ),
            "",
            "This is a post-summary, systematically selected sensitivity analysis. It quantifies an established conflict/closure adaptation and its cost; it is not part of the blind primary comparison and is not presented as a new general inequality.",
        ]
    if errors:
        lines += ["", "Errors: %d." % len(errors)]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n")
    print(args.output)


if __name__ == "__main__":
    main()
