"""Freeze deterministic targets directly from a compact reverse CSR."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scalability.compact_graph import ReverseCSR  # noqa: E402


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--graph-sha256", required=True)
    parser.add_argument("--minimum-indegree", type=int, default=100)
    parser.add_argument("--count", type=int, default=6)
    parser.add_argument("--development-count", type=int, default=1)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-ids", type=Path, required=True)
    args = parser.parse_args(argv)
    with ReverseCSR(args.cache) as graph:
        eligible = [vertex for vertex in range(graph.n)
                    if graph.indegree(vertex) >= args.minimum_indegree]
        if len(eligible) < args.count:
            raise ValueError("only %d eligible targets" % len(eligible))
        eligible.sort(key=lambda vertex: (
            hashlib.sha256((args.dataset + ":" + args.graph_sha256 + ":" +
                            str(graph.original_label(vertex))).encode()).hexdigest(),
            vertex,
        ))
        sampled = eligible[:args.count]
        maximum = min(sampled, key=lambda vertex: (-graph.indegree(vertex), vertex))
        selected = [maximum] + [vertex for vertex in sampled if vertex != maximum]
        records = [{
            "target_index": index,
            "split": "development" if index < args.development_count else "test",
            "internal_id": vertex,
            "original_label": str(graph.original_label(vertex)),
            "indegree": int(graph.indegree(vertex)),
        } for index, vertex in enumerate(selected)]
        n, m = graph.n, graph.m
    payload = {
        "dataset": args.dataset,
        "graph_sha256": args.graph_sha256,
        "node_mapping": "positive external integer labels mapped densely in numeric order",
        "n": n,
        "m": m,
        "minimum_indegree": args.minimum_indegree,
        "eligible_count": len(eligible),
        "count": args.count,
        "selection_rule": "take the first count eligible vertices ordered by SHA256(dataset:graph_sha256:original_label); designate the largest-indegree sampled vertex as development target 0 and retain hash order for the test targets",
        "selected_before_algorithm_evaluation": True,
        "targets": records,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_ids.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    args.output_ids.write_text(" ".join(str(row["internal_id"]) for row in records) + "\n")
    print(args.output_json)


if __name__ == "__main__":
    main()
