"""Validate exact-certificate audits and compare hits with frozen solutions."""
import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate", type=Path, action="append", required=True)
    parser.add_argument("--suite", type=Path, action="append", required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    protocol = json.loads(args.protocol.read_text())
    code_hash = protocol["implementation_hash"]
    runner = protocol["runner_version"]

    certificate_rows = []
    for path in args.certificate:
        if path.exists():
            certificate_rows.extend(
                json.loads(line) for line in path.read_text().splitlines()
                if line.strip()
            )
    certificate_rows = [
        row for row in certificate_rows
        if row.get("implementation_hash") == code_hash
    ]
    latest = {}
    for row in certificate_rows:
        latest[(row["graph_sha256"], row["target_index"], row["budget"])] = row
    certificate_rows = list(latest.values())

    frozen_hybrid = {}
    for path in args.suite:
        if not path.exists():
            continue
        for line in path.read_text().splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            if (row.get("implementation_hash") == code_hash
                    and row.get("runner_version") == runner
                    and row.get("method") == "certified_hybrid"
                    and row.get("status") == "ok"):
                frozen_hybrid[(
                    row["graph_sha256"], row["target_index"], row["budget"]
                )] = row

    errors = [row for row in certificate_rows if row.get("status") != "ok"]
    valid = [row for row in certificate_rows if row.get("status") == "ok"]
    joined = []
    for row in valid:
        key = (row["graph_sha256"], row["target_index"], row["budget"])
        hybrid = frozen_hybrid.get(key)
        if hybrid is None:
            raise RuntimeError("missing frozen hybrid row for %r" % (key,))
        lower = row["numerical_lower_bound"]
        upper = hybrid["objective_exact"]
        if lower > upper + 1e-8 * max(1.0, upper):
            raise RuntimeError("numerical lower bound exceeds upper bound")
        joined.append({
            **row,
            "suite": hybrid["suite"],
            "frozen_hybrid_objective": upper,
            "numerical_gap": (upper - lower) / upper if upper else 0.0,
        })

    by_group = defaultdict(list)
    for row in joined:
        by_group[(row["suite"], row["budget_ratio"])].append(row)
    lines = [
        "# Exact Certificate Audit on Frozen Test Targets",
        "",
        "Implementation hash: `%s`. Certificate cells: %d; errors: %d." % (
            code_hash, len(joined), len(errors)
        ),
        "",
        "| Dataset | b/d | Cells | Exact hits | Frozen hybrid optimal on hits | Median numerical gap | Median audit sec |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    total_hits = 0
    total_hybrid_hits = 0
    for key in sorted(by_group):
        group = by_group[key]
        hits = [row for row in group if row["exact_cardinality_hit"]]
        hybrid_hits = [
            row for row in hits
            if abs(row["frozen_hybrid_objective"] - row["exact_lower_bound_float"])
            <= 1e-8 * max(1.0, row["exact_lower_bound_float"])
        ]
        total_hits += len(hits)
        total_hybrid_hits += len(hybrid_hits)
        lines.append(
            "| %s | %.2f | %d | %d | %d | %.4f | %.2f |" % (
                key[0], key[1], len(group), len(hits), len(hybrid_hits),
                statistics.median(row["numerical_gap"] for row in group),
                statistics.median(row["seconds"] for row in group),
            )
        )
    lines += [
        "",
        "Across audited cells, %d/%d had an exact cardinality hit; the frozen hybrid matched the proved optimum in %d/%d hits." % (
            total_hits, len(joined), total_hybrid_hits, total_hits
        ),
    ]
    if errors:
        lines += ["", "## Errors", ""]
        for row in errors:
            lines.append("- target %s budget %s: `%s`" % (
                row.get("target_index"), row.get("budget"), row.get("error")
            ))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n")
    print(args.output)


if __name__ == "__main__":
    main()
