"""Small, deterministic directed-graph backend.

The loader deliberately sorts original node labels as strings.  This matches
the public WWW 2024 implementation, whose NetworkX loader leaves labels as
strings before ``convert_node_labels_to_integers(ordering='sorted')``.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple


@dataclass(frozen=True)
class DirectedGraph:
    labels: Tuple[str, ...]
    label_to_id: Dict[str, int]
    out_neighbors: Tuple[Tuple[int, ...], ...]
    in_neighbors: Tuple[Tuple[int, ...], ...]
    m: int

    @property
    def n(self) -> int:
        return len(self.labels)

    def indegree(self, vertex: int) -> int:
        return len(self.in_neighbors[vertex])

    def outdegree(self, vertex: int) -> int:
        return len(self.out_neighbors[vertex])


def from_integer_edges(n: int, edges: Iterable[Tuple[int, int]]) -> DirectedGraph:
    """Build a deterministic simple graph for tests and generated instances."""
    labels = tuple(str(i) for i in range(n))
    unique = {(int(u), int(v)) for u, v in edges if u != v}
    if any(u < 0 or u >= n or v < 0 or v >= n for u, v in unique):
        raise ValueError("edge endpoint outside [0,n)")
    out: List[List[int]] = [[] for _ in range(n)]
    incoming: List[List[int]] = [[] for _ in range(n)]
    for u, v in sorted(unique):
        out[u].append(v)
        incoming[v].append(u)
    return DirectedGraph(
        labels=labels,
        label_to_id={label: i for i, label in enumerate(labels)},
        out_neighbors=tuple(tuple(row) for row in out),
        in_neighbors=tuple(tuple(row) for row in incoming),
        m=len(unique),
    )


def load_edgelist(path: Path, *, lexical_labels: bool = True) -> DirectedGraph:
    """Load a two-column directed edge list, dropping loops and duplicates."""
    raw_edges: Set[Tuple[str, str]] = set()
    labels: Set[str] = set()
    with Path(path).open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            stripped = line.strip()
            if not stripped or stripped.startswith(("#", "%")):
                continue
            fields = stripped.split()
            if len(fields) < 2:
                raise ValueError("%s:%d: expected at least two fields" % (path, line_number))
            u, v = fields[0], fields[1]
            labels.add(u)
            labels.add(v)
            if u != v:
                raw_edges.add((u, v))
    if lexical_labels:
        ordered = tuple(sorted(labels))
    else:
        ordered = tuple(str(value) for value in sorted(int(label) for label in labels))
    mapping = {label: i for i, label in enumerate(ordered)}
    out: List[List[int]] = [[] for _ in ordered]
    incoming: List[List[int]] = [[] for _ in ordered]
    for source_label, target_label in raw_edges:
        u, v = mapping[source_label], mapping[target_label]
        out[u].append(v)
        incoming[v].append(u)
    return DirectedGraph(
        labels=ordered,
        label_to_id=mapping,
        out_neighbors=tuple(tuple(sorted(row)) for row in out),
        in_neighbors=tuple(tuple(sorted(row)) for row in incoming),
        m=len(raw_edges),
    )


def load_author_targets(path: Path) -> Tuple[int, ...]:
    """Load the internal integer target IDs shipped by the original code."""
    fields = Path(path).read_text(encoding="utf-8").split()
    return tuple(int(field) for field in fields)

