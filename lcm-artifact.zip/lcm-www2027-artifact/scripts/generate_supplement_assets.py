"""Deterministic vector assets from exact post-freeze comparisons (no tuning)."""
import json
import math
import statistics
from pathlib import Path
from reportlab.lib.colors import HexColor, Color
from reportlab.pdfgen import canvas
from generate_extended_paper_assets import register_fonts, label, axes, map_point, draw_polyline, BLUE, ORANGE, GREEN, GRID, INK
ROOT = Path(__file__).resolve().parents[1]
METHODS = [('algorithm1','A1',HexColor('#666666')),('singleton_sort','SC',BLUE),
           ('greedy','Greedy',HexColor('#CC79A7')),('blockmatch','BM',ORANGE),('overlap_search','Overlap',GREEN)]

def exact_figure(rows, bound_rows, path):
    width,height=508,155
    c=canvas.Canvas(str(path),pagesize=(width,height),invariant=1,pageCompression=1)
    label(c,4,145,'(a) Exact-optimum hits / 12 cells',7,bold=True)
    graph_names=[('moreno','Moreno'),('ciaodvd','CiaoDVD'),('polblogs','PolBlogs'),('twitter','Twitter')]
    for j,(_key,name,_color) in enumerate(METHODS):
        label(c,53+j*22,126,name if len(name)<=3 else ('GR' if name=='Greedy' else 'OS'),6,align='center')
    for i,(g,name) in enumerate(graph_names):
        y=104-20*i
        label(c,4,y+4,name,6)
        for j,(key,_,_) in enumerate(METHODS):
            hits=sum(r['methods'][key]['optimal'] for r in rows if r['graph']==g)
            c.setFillColor(Color(.97-.45*(hits-8)/4,.98-.27*(hits-8)/4,1))
            c.rect(43+22*j,y,20,17,fill=1,stroke=0)
            label(c,53+22*j,y+5,str(hits),7,align='center',bold=hits==12)
    label(c,4,17,'SC: SingletonSort; BM: BlockMatch',5.7)
    label(c,4,7,'GR: greedy; OS: overlap search',5.7)
    xr,yr=(0,2.5),(0,12)
    l,b,pw,ph=axes(c,170,0,169,height-14,[(0,'0'),(.5,'0.5'),(1,'1'),(2,'2')],[(0,'0'),(4,'4'),(8,'8'),(12,'12')],xr,yr,'excess over OPT (%)','cells exceeding threshold (%)','')
    label(c,173,height-9,'(b) Error survival',7,bold=True)
    for key,name,color in METHODS:
        errors=[100*(r['methods'][key]['ratio_to_optimum']-1) for r in rows]
        xs=sorted({0,2.5,*[x for x in errors if x>0]})
        points=[]
        for x in xs:
            before=sum(e>=x and e>0 for e in errors)/len(errors)*100
            after=sum(e>x+1e-10 for e in errors)/len(errors)*100
            points.extend([map_point(l,b,pw,ph,x,before,xr,yr),map_point(l,b,pw,ph,x,after,xr,yr)])
        draw_polyline(c,points,color,.9)
    for i,(_,name,color) in enumerate(METHODS):
        label(c,l+pw-35,140-i*8,name,5.4,color)
    nontrivial=[r for r in bound_rows if r['k']>=4]
    xr=yr=(1,4.2)
    l,b,pw,ph=axes(c,339,0,169,height-14,[(1,'1'),(2,'2'),(3,'3'),(4,'4')],[(1,'1'),(2,'2'),(3,'3'),(4,'4')],xr,yr,'earlier BM factor','refined BM factor','')
    label(c,342,height-9,'(c) Guarantees: 24 cells',7,bold=True)
    c.setDash(2,2);draw_polyline(c,[map_point(l,b,pw,ph,1,1,xr,yr),map_point(l,b,pw,ph,4.2,4.2,xr,yr)],GRID,.8);c.setDash()
    for r in nontrivial:
        x,y=map_point(l,b,pw,ph,r['blockmatch_old_bound'],r['blockmatch_new_bound'],xr,yr)
        c.setFillColor(ORANGE);c.circle(x,y,1.8,fill=1,stroke=0)
    label(c,l+4,133,'all 24 bounds improve',5.7)
    label(c,l+4,125,'median reduction: 1.87%',5.7)
    c.showPage();c.save()


def envelope(path):
    width,height=244,128
    c=canvas.Canvas(str(path),pagesize=(width,height),invariant=1,pageCompression=1)
    xr,yr=(math.log10(4),math.log10(4096)),(0,2)
    l,b,pw,ph=axes(c,0,0,width,height-14,[(math.log10(x),str(x)) for x in (4,16,64,256,1024,4096)],[(math.log10(x),str(x)) for x in (1,2,5,10,20,50,100)],xr,yr,'original harmonic centrality h (log scale)','factor (log scale)','')
    label(c,3,height-9,'Universal envelopes, k >= 4',7,bold=True)
    funcs=[('A1',lambda h:math.sqrt(2*h),HexColor('#777777')),
           ('BM: earlier',lambda h:math.sqrt(h/2),BLUE),
           ('BM: refined',lambda h:h/(2*math.sqrt(h)-1),ORANGE)]
    for name,f,color in funcs:
        points=[]
        for i in range(101):
            x=xr[0]+(xr[1]-xr[0])*i/100;h=10**x
            points.append(map_point(l,b,pw,ph,x,math.log10(f(h)),xr,yr))
        draw_polyline(c,points,color)
    for i,(name,_,color) in enumerate(funcs):label(c,l+6,107-i*8,name,5.7,color)
    c.showPage();c.save()


def table(rows,path):
    text=['\\begin{tabular}{lrrrrrr}','\\toprule',
          'Method & Moreno & CiaoDVD & PolBlogs & Twitter & Max ratio & Median ms \\\\', '\\midrule']
    for key,name,_ in METHODS:
        hits=[sum(r['methods'][key]['optimal'] for r in rows if r['graph']==g) for g in ['moreno','ciaodvd','polblogs','twitter']]
        maxratio=max(r['methods'][key]['ratio_to_optimum'] for r in rows)
        ms=1000*statistics.median(r['methods'][key]['solver_seconds_including_preprocess'] for r in rows)
        display={'SC':'SingletonSort','BM':'BlockMatch'}.get(name,name)
        text.append(display+' & '+' & '.join(f'{n}/12' for n in hits)+f' & {maxratio:.6f} & {ms:.2f} \\\\')
    text.extend(['\\bottomrule','\\end{tabular}',''])
    path.write_text('\n'.join(text))


def main():
    register_fonts()
    rows=[json.loads(s) for s in (ROOT/'results/blockmatch_real_graph.jsonl').read_text().splitlines()]
    bounds=[json.loads(s) for s in (ROOT/'results/structural_real_graph.jsonl').read_text().splitlines()]
    exact_figure(rows,bounds,ROOT/'paper/figures/exact_comparison.pdf')
    envelope(ROOT/'paper/figures/theoretical_envelope.pdf')
    table(rows,ROOT/'paper/generated/exact_comparison.tex')
if __name__=='__main__':main()
