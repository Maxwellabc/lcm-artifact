"""Create a compact Markdown development report from raw JSONL results."""
import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path


def fmt(value, digits=4):
    return "—" if value is None else ("%%.%df" % digits) % value


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite", type=Path, action="append", required=True)
    parser.add_argument("--small-lp", type=Path)
    parser.add_argument("--real-lp", type=Path)
    parser.add_argument("--certificate-audit", type=Path, action="append", default=[])
    parser.add_argument("--conflict-audit", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    rows = []
    for suite in args.suite:
        rows.extend(json.loads(line) for line in suite.read_text().splitlines()
                    if line.strip())
    # Resumable suites append a fresh record after implementation/config
    # changes.  Later inputs and later lines deliberately supersede earlier
    # observations for the same experimental cell.
    latest = {}
    for row in rows:
        key = (
            row.get("graph_sha256"), row.get("target_index"), row.get("budget"),
            row.get("method"), row.get("trial"),
        )
        latest[key] = row
    ok = [row for row in latest.values() if row.get("status") == "ok"]
    groups = defaultdict(list)
    for row in ok:
        groups[(row["graph_sha256"], row["n"], row["m"],
                row["target_index"], row["target_internal_id"],
                row["budget_ratio"], row["budget"])].append(row)
    certificate_audit = defaultdict(list)
    for path in args.certificate_audit:
        for line in path.read_text().splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            certificate_audit[(
                row.get("graph_sha256"), row["target_index"],
                row["target_internal_id"], row["budget"], row["indegree"],
            )].append(row)
    conflict_audit = defaultdict(list)
    for path in args.conflict_audit:
        for line in path.read_text().splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            conflict_audit[(
                row["graph_sha256"], row["target_index"],
                row["target_internal_id"], row["budget"], row["indegree"],
            )].append(row)
    lines = [
        "# Development Results",
        "",
        "Generated from %d JSONL suites. These are development-set observations, not frozen test results." % len(args.suite),
        "",
        "## Strict-budget solution quality",
        "",
        "| Graph (n/m/hash) | Target index / ID | b/d | A1 | Greedy | Parametric repair | 1-swap | Overlap | Hybrid | Best | Valid LB | Conflict Δ | Gap | Exact? |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|",
    ]
    for key in sorted(groups):
        graph_hash, n, m, target_index, target, ratio, budget = key
        group = groups[key]
        deterministic = {
            row["method"]: row.get("objective_exact")
            for row in group if row.get("trial") is None
        }
        hybrid_rows = [row for row in group if row["method"] == "certified_hybrid"]
        if hybrid_rows and deterministic.get("parametric_repair") is None:
            deterministic["parametric_repair"] = hybrid_rows[-1].get(
                "diagnostics", {}).get("parametric_objective")
        random_values = [row["objective_exact"] for row in group
                         if row["method"] == "random"]
        certificates = [row for row in group if row["method"] == "lagrangian_certificate"]
        lower = certificates[0]["lower_bound"] if certificates else None
        audits = certificate_audit.get((
            graph_hash, target_index, target, budget, group[0]["indegree"]
        ), [])
        # Backward compatibility for audit rows written before graph metadata
        # was added; the cell identity is still unique in this report.
        audits += certificate_audit.get((
            None, target_index, target, budget, group[0]["indegree"]
        ), [])
        audit_lower = max(
            (row.get("exact_lower_bound_float", row["numerical_lower_bound"])
             for row in audits), default=None
        )
        if audit_lower is not None:
            lower = audit_lower if lower is None else max(lower, audit_lower)
        exact_hit = any(row.get("exact_cardinality_hit") for row in audits)
        conflict_rows = conflict_audit.get((
            graph_hash, target_index, target, budget, group[0]["indegree"]
        ), [])
        conflict_best = max(
            (row for row in conflict_rows if row.get("lower_bound_float") is not None),
            key=lambda row: row["lower_bound_float"], default=None,
        )
        conflict_delta = None
        if conflict_best is not None:
            lower = (conflict_best["lower_bound_float"] if lower is None
                     else max(lower, conflict_best["lower_bound_float"]))
            conflict_delta = conflict_best.get("improvement")
        solution_values = [value for method, value in deterministic.items()
                           if method != "lagrangian_certificate" and value is not None]
        incumbent = min(solution_values) if solution_values else None
        gap = (max(0.0, (incumbent - lower) / incumbent)
               if incumbent is not None and lower is not None and incumbent else None)
        lines.append(
            "| %d/%d/%s | %d / %d | %.2f (%d) | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
                n, m, graph_hash[:8], target_index, target, ratio, budget,
                fmt(deterministic.get("algorithm1")),
                fmt(deterministic.get("greedy")),
                fmt(deterministic.get("parametric_repair")),
                fmt(deterministic.get("multi_start_one_swap")),
                fmt(deterministic.get("overlap_search")),
                fmt(deterministic.get("certified_hybrid")),
                fmt(incumbent),
                fmt(lower), fmt(conflict_delta), fmt(gap, 3),
                "yes" if exact_hit else "no",
            )
        )
    lines += [
        "",
        "The lower bound is the maximum of registered trivial, quantized-flow, exact rational, and separated-conflict bounds. Conflict Δ is the exact additive gain over the zero-conflict flow in the corresponding audit; missing cells were not run.",
    ]
    if args.small_lp and args.small_lp.exists():
        audit = [json.loads(line) for line in args.small_lp.read_text().splitlines()]
        lines += ["", "## Small-instance relaxation audit", ""]
        for field, label in [
            ("improvement_l1_over_l0", "L1 > L0"),
            ("improvement_l2_over_l1", "L2 > L1"),
            ("improvement_l3_over_l2", "L3 > L2"),
            ("improvement_l4_over_l3", "L4 > L3"),
        ]:
            values = [row[field] for row in audit]
            lines.append("- %s: %d/%d instances; mean additive improvement %.6f; maximum %.6f." % (
                label, sum(value > 1e-8 for value in values), len(values),
                statistics.mean(values), max(values)))
        gaps = [row["remaining_gap_l4"] for row in audit]
        lines.append("- L4 retains a positive numerical gap on %d/%d instances; maximum %.6f." % (
            sum(value > 1e-8 for value in gaps), len(gaps), max(gaps)))
    if args.real_lp and args.real_lp.exists():
        audit = [json.loads(line) for line in args.real_lp.read_text().splitlines()]
        lines += [
            "", "## Real-graph pair-cut LP pilot", "",
            "| Target | b/d | L1 | L1 + pair cuts | Improvement | Cuts | Seconds |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ]
        for row in audit:
            lines.append("| %d | %.2f | %.6f | %.6f | %.6f | %d | %.2f |" % (
                row["target_index"], row["budget_ratio"],
                row["l1"]["objective"], row["pair"]["objective"],
                row["improvement"], row["pair"]["diagnostics"]["cuts"],
                row["pair"]["solve_seconds"],
            ))
        lines += [
            "",
            "These SciPy LP values are numerical comparisons. They are not reported as rigorous certificates.",
        ]
    lines += [
        "", "## Interpretation", "",
        "- This report uses development targets only; it cannot establish generalization.",
        "- Multi-start local search is an empirical strong baseline/candidate component, not a novelty claim by itself.",
        "- The cross-source cuts are worth retaining only if their gain survives stronger single-source baselines and frozen real-graph tests.",
        "- Negative and zero-improvement cases remain in the report.",
        "",
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines), encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
