# Local Centrality Minimization Research Workspace

This repository is an independent research implementation and planning workspace for improving the WWW 2024 local harmonic centrality minimization algorithm. The upstream source snapshot is kept unchanged under `external/Local-Centrality-Minimization/`. The current implementation includes a budget-exact top-`b+1` distance profile, strict-budget baselines and local search, integer-flow lower bounds, opportunistic exact optimality certificates, and LP/MILP audits.

## Reproduce the current checks

The core profile/oracle uses the Python 3.9 standard library. The complete
13-test suite additionally uses the locked matching and optional LP dependencies:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-lp-lock.txt
.venv/bin/python -m unittest discover -s tests -v
python3 scripts/validate_structure.py
.venv/bin/python scripts/exhaustive_small_graph_audit.py \
  --output results/EXHAUSTIVE_SMALL_GRAPH_AUDIT.json
python3 -m lcm.cli \
  --graph external/Local-Centrality-Minimization/graph/out.moreno_blogs \
  --targets-file external/Local-Centrality-Minimization/target_id/out.moreno_blogs \
  --target-index 0 --budget-ratio 0.5
```

The LP/MILP audit uses the isolated environment recorded in `requirements-lp-lock.txt`:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-lp-lock.txt
.venv/bin/python -m unittest tests.test_lp -v
.venv/bin/python scripts/run_small_lp_audit.py
```

Run the resumable two-target development suite with:

```bash
python3 scripts/run_suite.py \
  --config configs/development-moreno-v2.json \
  --output results/raw
```

The frozen candidate combines parameterized min-cut repair, exact 1-swap
search, and prefix exchange, then explicitly retains the overlap-search result
as a fallback.  This prevents adding the cut-guided start from degrading that
component.  Its higher-precision development configurations are
`configs/development-hybrid-{moreno,ciaodvd,polblogs,twitter}.json`.
Exact cardinality-hit certificates can be audited independently, for example:

```bash
.venv/bin/python scripts/run_exact_certificate_audit.py \
  --graph external/Local-Centrality-Minimization/graph/out.moreno_blogs \
  --targets external/Local-Centrality-Minimization/target_id/out.moreno_blogs \
  --target-indices 0 1 \
  --output results/exact_certificate_moreno.jsonl
```

Downloaded inputs are accompanied by provenance records under
`data/manifests/`; deterministic development/test target splits live under
`data/targets/`.  The release artifact excludes raw graphs, downloaded
archives, and the unlicensed upstream snapshot.  Fetch or verify them from
their recorded public sources with:

```bash
python3 scripts/fetch_public_inputs.py --check-only  # verify local inputs
python3 scripts/fetch_public_inputs.py               # fetch missing inputs
python3 scripts/fetch_public_inputs.py --include-scalability  # all eight graphs
```

The acquisition policy and provenance limits are documented in
`data/README.md`.

Build the non-redistributing release candidate and its SHA256 sidecar with:

```bash
python3 scripts/build_release_artifact.py
```

The archive contains an internal file-level hash manifest and excludes
`data/raw/`, `external/`, `.venv/`, caches, and its own output directory.

## Reproduce the frozen evaluation

The authoritative split, code hash, runner version, parameters, and config
hashes are in `configs/FROZEN_TEST_PROTOCOL.json`. Each runner is resumable;
older rows remain in the JSONL logs but are excluded by the result generator.

```bash
for name in moreno ciaodvd polblogs twitter; do
  .venv/bin/python scripts/run_suite.py \
    --config "configs/test-${name}.json" --output results/raw
done

.venv/bin/python scripts/summarize_test_results.py \
  --suite results/raw/test-moreno.jsonl \
  --suite results/raw/test-ciaodvd.jsonl \
  --suite results/raw/test-polblogs.jsonl \
  --suite results/raw/test-twitter.jsonl \
  --protocol configs/FROZEN_TEST_PROTOCOL.json \
  --output results/TEST_REPORT.md \
  --latex-output paper/generated/main_results.tex
```

The frozen report contains 198/198 complete target--budget cells with no
errors. Exact profile-construction and synthetic overlap-mechanism audits are
reproduced with:

```bash
.venv/bin/python scripts/run_profile_benchmarks.py \
  --config configs/profile-benchmarks.json \
  --output results/profile_benchmarks.jsonl
.venv/bin/python scripts/summarize_profile_benchmarks.py \
  --input results/profile_benchmarks.jsonl \
  --protocol configs/FROZEN_TEST_PROTOCOL.json \
  --output results/PROFILE_BENCHMARK_REPORT.md
.venv/bin/python scripts/run_synthetic_overlap_family.py \
  --output results/synthetic_overlap_family.jsonl \
  --report results/SYNTHETIC_OVERLAP_REPORT.md
```

The four larger original-study graphs use a separately preregistered compact
reverse-CSR extension.  Rebuild its strict report and paper table with:

```bash
.venv/bin/python scripts/summarize_scalability_extension.py \
  --protocol configs/SCALABILITY_EXTENSION_PROTOCOL.json \
  --results results/scalability-extension.jsonl \
  --output-json results/SCALABILITY_EXTENSION_SUMMARY.json \
  --output-markdown results/SCALABILITY_EXTENSION_REPORT.md \
  --latex-output paper/generated/scalability_results.tex
```

The frozen extension has 144/144 successful method rows. Its 60 sealed
target--budget comparisons give SingletonSort versus A1 a 6/52/2 W/T/L result;
the zero median and two losses are part of the primary report.

The paper source and rendered twelve-page anonymous PDF are under `paper/`: eight
pages of main text followed by references and appendices. Its tables,
bootstrap intervals, and vector figures are generated from frozen logs rather
than transcribed by hand. The dated submission gates and optional independent
proof/novelty review form are `paper/SUBMISSION_CHECKLIST.md` and
`paper/INDEPENDENT_REVIEW_PACKET.md`.

## Correctness boundary

- `harmonic_after_deletions` is the independent original-graph BFS oracle.
- `BudgetProfile` is exact only for deletion sets of size at most its configured budget.
- Every strict-budget algorithm result is re-evaluated with the independent oracle before being recorded.
- `lagrangian_certificate` rounds positive objective capacities down and uses integer max flow, producing a valid lower bound.
- `exact_lagrangian_certificate` reconstructs path reciprocals as rational numbers and scales them to integer capacities. If its optimal cut retains exactly `k=d-b` candidates, the same cut is a globally optimal strict-budget solution.
- SciPy LP values are numerical relaxation results for comparison; they are not labeled rigorous certificates.
- The local-hull LP enumerates all exact-budget deletion patterns and is deliberately restricted to small candidate sets.

The current research status, known novelty risks, experiment protocol, and paper plan are documented in [RESEARCH_PLAN.md](RESEARCH_PLAN.md), [notes/](notes/), and [planning/](planning/).
