import random
import unittest
from fractions import Fraction
from itertools import combinations
from pathlib import Path

from lcm.algorithms import (
    algorithm1,
    brute_force_optimum,
    certified_hybrid,
    degree_deletion,
    greedy_deletion,
    one_swap,
    multi_start_one_swap,
    overlap_search,
    parametric_repair,
    prefix_exchange,
    singleton_sort,
)
from lcm.flow import (
    exact_lagrangian_certificate,
    lagrangian_certificate,
    lagrangian_sweep,
    search_exact_cardinality_certificate,
    search_lagrangian_bound,
)
from lcm.conflict import (
    build_prefix_triggers,
    conflict_lagrangian_certificate,
    separated_conflict_bound,
    search_conflict_lagrangian_bound,
    select_conflict_matching,
)
from lcm.graph import from_integer_edges, load_author_targets, load_edgelist
from lcm.objective import harmonic_after_deletions
from lcm.profile import build_budget_profile


ROOT = Path(__file__).resolve().parents[1]
AUTHOR = ROOT / "external" / "Local-Centrality-Minimization"


class MorenoRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.graph = load_edgelist(AUTHOR / "graph" / "out.moreno_blogs")
        cls.targets = load_author_targets(AUTHOR / "target_id" / "out.moreno_blogs")

    def test_graph_and_mapping(self):
        self.assertEqual((self.graph.n, self.graph.m), (1224, 19022))
        self.assertEqual(len(self.targets), 20)
        self.assertEqual(self.graph.labels[669], "5")
        degrees = [self.graph.indegree(target) for target in self.targets]
        self.assertEqual((max(degrees), min(degrees)), (337, 101))
        self.assertAlmostEqual(sum(degrees) / len(degrees), 158.8)

    def test_author_smoke_values(self):
        target = self.targets[0]
        budget = self.graph.indegree(target) // 2
        profile = build_budget_profile(self.graph, target, budget)
        empty = harmonic_after_deletions(self.graph, target, ())
        self.assertAlmostEqual(empty, 647.3333333333403, places=8)
        a1 = algorithm1(self.graph, profile)
        degree = degree_deletion(self.graph, profile)
        self.assertAlmostEqual(a1.objective, 426.47619047618787, places=8)
        self.assertAlmostEqual(degree.objective, 449.0428571428505, places=8)
        self.assertAlmostEqual(a1.objective,
                               harmonic_after_deletions(self.graph, target, a1.deleted), places=9)


class ExactnessTests(unittest.TestCase):
    def test_singleton_k_factor_is_asymptotically_tight(self):
        for k in (2, 3, 4):
            group_size = 200
            target = 0
            first = list(range(1, k + 1))
            second = list(range(k + 1, 2 * k + 1))
            edges = [(candidate, target) for candidate in (*first, *second)]
            next_source = 2 * k + 1
            for candidate in first:
                for _ in range(group_size):
                    edges.append((next_source, candidate))
                    next_source += 1
            for _ in range(group_size + 1):
                edges.extend((next_source, candidate) for candidate in second)
                next_source += 1
            graph = from_integer_edges(next_source, edges)
            profile = build_budget_profile(graph, target, k)
            singleton, _ = singleton_sort(graph, profile)
            optimum, _, _ = brute_force_optimum(profile)
            self.assertAlmostEqual(
                singleton.objective, k + k * group_size / 2,
            )
            self.assertAlmostEqual(optimum, k + (group_size + 1) / 2)
            self.assertGreater(singleton.objective / optimum, k - 0.5)

    def test_random_profile_and_algorithms(self):
        rng = random.Random(20260925)
        for _ in range(40):
            n = rng.randrange(4, 9)
            edges = [(u, v) for u in range(n) for v in range(n)
                     if u != v and rng.random() < 0.35]
            graph = from_integer_edges(n, edges)
            target = rng.randrange(n)
            d = graph.indegree(target)
            if not d:
                continue
            budget = rng.randrange(d + 1)
            profile = build_budget_profile(graph, target, budget)
            for size in range(budget + 1):
                for deleted in combinations(profile.candidates, size):
                    self.assertAlmostEqual(
                        profile.objective(deleted),
                        harmonic_after_deletions(graph, target, deleted),
                        places=10,
                    )
                    candidate_to_index = {
                        vertex: index for index, vertex in enumerate(profile.candidates)
                    }
                    self.assertAlmostEqual(
                        profile.relaxation_objective_indices(
                            candidate_to_index[vertex] for vertex in deleted
                        ),
                        profile.objective(deleted),
                        places=10,
                    )
            if budget < d:
                greedy = greedy_deletion(profile)
                singleton, _ = singleton_sort(graph, profile)
                optimum, _, _ = brute_force_optimum(profile)
                k = profile.k
                initial = harmonic_after_deletions(graph, target, ())
                self.assertLessEqual(
                    singleton.objective, k * optimum + 1e-9
                )
                self.assertLessEqual(
                    singleton.objective,
                    (initial / k) * optimum + 1e-9,
                )
                current = singleton.objective
                expected = current
                deleted = set(singleton.deleted)
                for restored in deleted:
                    for removed in set(profile.candidates) - deleted:
                        expected = min(expected, profile.objective(
                            (deleted - {restored}) | {removed}))
                one_round = one_swap(profile, singleton.deleted, max_rounds=1)
                self.assertAlmostEqual(one_round.objective, expected, places=9)
                swapped = one_swap(profile, singleton.deleted, max_rounds=2)
                self.assertEqual(len(greedy.deleted), budget)
                self.assertLessEqual(swapped.objective, singleton.objective + 1e-10)
                multi = multi_start_one_swap(profile, [greedy, singleton], max_rounds=2)
                self.assertLessEqual(multi.objective, min(greedy.objective, singleton.objective) + 1e-10)
                exchange = prefix_exchange(
                    profile, multi.deleted, max_prefix=4, max_missing=3,
                    top_bundles=5, restore_pool_size=4, max_rounds=1,
                )
                self.assertEqual(len(exchange.deleted), budget)
                self.assertLessEqual(exchange.objective, multi.objective + 1e-10)
                repaired = parametric_repair(profile, iterations=8, scale=100_000)
                self.assertEqual(len(repaired.deleted), budget)
                self.assertAlmostEqual(
                    repaired.objective,
                    harmonic_after_deletions(graph, target, repaired.deleted),
                    places=10,
                )
                overlap = overlap_search(
                    profile, [greedy, singleton], swap_rounds=2,
                    exchange_rounds=1,
                )
                hybrid = certified_hybrid(
                    profile, [greedy, singleton], parametric_iterations=8,
                    parametric=repaired, fallbacks=[overlap], swap_rounds=2,
                    exchange_rounds=1,
                )
                self.assertEqual(len(hybrid.deleted), budget)
                self.assertLessEqual(
                    hybrid.objective,
                    min(greedy.objective, singleton.objective, repaired.objective) + 1e-10,
                )
                self.assertLessEqual(hybrid.objective, overlap.objective + 1e-10)
                self.assertLessEqual(
                    hybrid.diagnostics["certified_lower_bound"],
                    hybrid.objective + 1e-9,
                )

    def test_quantized_certificate_never_exceeds_optimum(self):
        rng = random.Random(7)
        for _ in range(30):
            n = 7
            edges = [(u, v) for u in range(n) for v in range(n)
                     if u != v and rng.random() < 0.4]
            graph = from_integer_edges(n, edges)
            target = 0
            d = graph.indegree(target)
            if not 1 <= d <= 6:
                continue
            budget = d // 2
            profile = build_budget_profile(graph, target, budget)
            optimum, _, _ = brute_force_optimum(profile)
            for multiplier in (0.0, 0.25, 0.5, 1.0, 2.0):
                certificate = lagrangian_certificate(profile, multiplier, scale=100_000)
                self.assertLessEqual(certificate.lower_bound, optimum + 1e-9)
                exact = exact_lagrangian_certificate(
                    profile, Fraction(str(multiplier))
                )
                self.assertLessEqual(float(exact.lower_bound), optimum + 1e-12)
            best = search_lagrangian_bound(profile, scale=100_000, iterations=10)
            self.assertLessEqual(best.lower_bound, optimum + 1e-9)
            sweep = lagrangian_sweep(profile, scale=100_000, iterations=10)
            self.assertEqual(len({item.retained for item in sweep}), len(sweep))
            for certificate in sweep:
                self.assertLessEqual(certificate.lower_bound, optimum + 1e-9)
            exact_hit, _ = search_exact_cardinality_certificate(
                profile, scale=100_000, iterations=10,
                denominator_limits=(100, 1000),
            )
            if exact_hit is not None:
                self.assertEqual(exact_hit.retained_count, profile.k)
                self.assertAlmostEqual(float(exact_hit.lower_bound), optimum, places=10)
            separated = separated_conflict_bound(
                profile, iterations=8, pool_size=100, max_pairs=10,
            )
            self.assertLessEqual(float(separated.best.lower_bound), optimum + 1e-12)
            self.assertGreaterEqual(
                separated.best.lower_bound, separated.base.lower_bound
            )

    def test_cross_source_gap_instance(self):
        edges = [(u, 0) for u in range(1, 6)]
        edges += [(6, 1), (6, 2), (7, 3), (7, 4)]
        graph = from_integer_edges(8, edges)
        profile = build_budget_profile(graph, 0, 3)
        optimum, _, count = brute_force_optimum(profile)
        self.assertEqual(count, 10)
        self.assertAlmostEqual(optimum, 2.5)
        triggers, _ = build_prefix_triggers(profile)
        penalties = select_conflict_matching(
            profile, triggers, pool_size=100, max_pairs=10
        )
        self.assertGreaterEqual(len(penalties), 1)
        strengthened = search_conflict_lagrangian_bound(
            profile, penalties, iterations=14
        )
        self.assertLessEqual(float(strengthened.lower_bound), optimum + 1e-12)
        exact_strengthened = conflict_lagrangian_certificate(
            profile, Fraction(1), penalties
        )
        self.assertEqual(exact_strengthened.lower_bound, Fraction(5, 2))
        separated = separated_conflict_bound(
            profile, iterations=20, pool_size=100, max_pairs=10
        )
        self.assertGreaterEqual(separated.best.lower_bound, separated.base.lower_bound)
        self.assertAlmostEqual(float(separated.best.lower_bound), optimum, places=3)

    def test_conflict_certificate_matches_base_without_penalties(self):
        graph = from_integer_edges(6, [(1, 0), (2, 0), (3, 0), (4, 1), (5, 2)])
        profile = build_budget_profile(graph, 0, 2)
        for multiplier in (Fraction(0), Fraction(1, 2), Fraction(3, 2)):
            base = exact_lagrangian_certificate(profile, multiplier)
            conflict = conflict_lagrangian_certificate(profile, multiplier, ())
            self.assertEqual(conflict.lower_bound, base.lower_bound)


if __name__ == "__main__":
    unittest.main()
