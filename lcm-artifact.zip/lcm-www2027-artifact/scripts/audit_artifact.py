"""Run deterministic integrity checks over code, data, frozen logs, and paper inputs."""
import hashlib
import json
import re
import subprocess
import sys
import tempfile
import argparse
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def implementation_hash():
    digest = hashlib.sha256()
    for path in sorted((ROOT / "lcm").glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines()
            if line.strip()]


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--skip-release-smoke", action="store_true",
        help="permit the clean-room smoke run that produces the new smoke record",
    )
    args = parser.parse_args(argv)
    protocol = json.loads((ROOT / "configs/FROZEN_TEST_PROTOCOL.json").read_text())
    checks = {}
    failures = []

    code_hash = implementation_hash()
    checks["implementation_hash"] = code_hash
    if code_hash != protocol["implementation_hash"]:
        failures.append("implementation hash mismatch")

    template_expected = {
        "paper/acmart.cls": "784c4f2fb07a70d8a797ee9d1c63f441c10fbd2f915c9c615d28cda35c0b742a",
        "paper/ACM-Reference-Format.bst": "4342d27456645567ef1a027f6474e894715bc31d468f040142fa54540440ad04",
    }
    checks["template_hashes"] = {
        relative: sha256(ROOT / relative)
        for relative in template_expected
    }
    for relative, expected in template_expected.items():
        if checks["template_hashes"][relative] != expected:
            failures.append("pinned ACM template hash mismatch: %s" % relative)

    config_hashes = {}
    for relative, expected in protocol["test_config_sha256"].items():
        actual = sha256(ROOT / relative)
        config_hashes[relative] = actual
        if actual != expected:
            failures.append("config hash mismatch: %s" % relative)
    checks["config_hashes"] = config_hashes

    data_hashes = {}
    for manifest_path in sorted((ROOT / "data/manifests").glob("*.json")):
        manifest = json.loads(manifest_path.read_text())
        relative = manifest.get("graph_path") or manifest.get("processed_graph")
        expected = manifest.get("graph_sha256")
        if relative and expected:
            actual = sha256(ROOT / relative)
            data_hashes[relative] = actual
            if actual != expected:
                failures.append("dataset hash mismatch: %s" % relative)
    checks["data_hashes"] = data_hashes

    upstream = ROOT / "external/Local-Centrality-Minimization"
    upstream_head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=upstream, text=True
    ).strip()
    upstream_status = subprocess.check_output(
        ["git", "status", "--porcelain"], cwd=upstream, text=True
    ).strip()
    checks["upstream_head"] = upstream_head
    checks["upstream_clean"] = not upstream_status
    if upstream_head != "7d2ecb21f1d0f33fe44255171ece10a2a9fbabaa":
        failures.append("upstream commit changed")
    if upstream_status:
        failures.append("upstream checkout is modified")

    frozen_rows = []
    for path in sorted((ROOT / "results/raw").glob("test-*.jsonl")):
        frozen_rows.extend(
            row for row in read_jsonl(path)
            if row.get("implementation_hash") == protocol["implementation_hash"]
            and row.get("runner_version") == protocol["runner_version"]
        )
    frozen_keys = {
        (row["suite"], row["target_index"], row["budget_ratio"],
         row["method"], row.get("trial"))
        for row in frozen_rows if row.get("status") == "ok"
    }
    frozen_errors = [row for row in frozen_rows if row.get("status") != "ok"]
    checks["frozen_rows"] = len(frozen_rows)
    checks["frozen_unique_ok_rows"] = len(frozen_keys)
    checks["frozen_errors"] = len(frozen_errors)
    if len(frozen_keys) != 198 * (8 + 20) or frozen_errors:
        failures.append("frozen row matrix is incomplete or has errors")

    scalability_protocol_path = ROOT / "configs/SCALABILITY_EXTENSION_PROTOCOL.json"
    scalability_protocol = json.loads(scalability_protocol_path.read_text())
    scalability_hashes = {}
    for group in ("implementation_sha256", "config_sha256",
                  "target_metadata_sha256"):
        scalability_hashes[group] = {}
        for relative, expected in scalability_protocol[group].items():
            actual = sha256(ROOT / relative)
            scalability_hashes[group][relative] = actual
            if actual != expected:
                failures.append("scalability freeze hash mismatch: %s" % relative)
    checks["scalability_freeze_hashes"] = scalability_hashes

    scalability_results = ROOT / "results/scalability-extension.jsonl"
    scalability_summary = ROOT / "results/SCALABILITY_EXTENSION_SUMMARY.json"
    scalability_report = ROOT / "results/SCALABILITY_EXTENSION_REPORT.md"
    scalability_latex = ROOT / "paper/generated/scalability_results.tex"
    try:
        with tempfile.TemporaryDirectory() as directory:
            temporary = Path(directory)
            generated_json = temporary / "summary.json"
            generated_markdown = temporary / "report.md"
            generated_latex = temporary / "table.tex"
            subprocess.run([
                sys.executable, str(ROOT / "scripts/summarize_scalability_extension.py"),
                "--protocol", str(scalability_protocol_path),
                "--results", str(scalability_results),
                "--output-json", str(generated_json),
                "--output-markdown", str(generated_markdown),
                "--latex-output", str(generated_latex),
            ], cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
            for generated, committed, label in (
                (generated_json, scalability_summary, "summary"),
                (generated_markdown, scalability_report, "report"),
                (generated_latex, scalability_latex, "paper table"),
            ):
                if generated.read_bytes() != committed.read_bytes():
                    failures.append("stale scalability %s" % label)
        scale = json.loads(scalability_summary.read_text())
        quality = scale["test_quality"]
        checks["scalability_extension"] = {
            "rows": scale["audit"]["rows"],
            "unique_cells": scale["audit"]["unique_cells"],
            "wins": quality["wins"], "ties": quality["ties"],
            "losses": quality["losses"],
            "results_sha256": scale["results_sha256"],
            "resource_gates_passed": all(
                row["passed"] for row in scale["resource_gates"].values()),
        }
        if (scale["audit"]["rows"] != 144
                or scale["audit"]["unique_cells"] != 144
                or (quality["wins"], quality["ties"], quality["losses"])
                != (6, 52, 2)
                or not checks["scalability_extension"]["resource_gates_passed"]):
            failures.append("scalability result matrix or aggregate is invalid")
    except Exception as error:
        checks["scalability_extension_error"] = repr(error)
        failures.append("scalability extension audit failed")

    exact_rows = []
    for path in sorted((ROOT / "results").glob("test_exact_certificate_*.jsonl")):
        exact_rows.extend(
            row for row in read_jsonl(path)
            if row.get("implementation_hash") == protocol["implementation_hash"]
        )
    exact_keys = {
        (row["graph_sha256"], row["target_index"], row["budget"])
        for row in exact_rows if row.get("status") == "ok"
    }
    exact_errors = [row for row in exact_rows if row.get("status") != "ok"]
    exact_hits = sum(row.get("exact_cardinality_hit", False) for row in exact_rows
                     if row.get("status") == "ok")
    checks["exact_certificate_cells"] = len(exact_keys)
    checks["exact_certificate_hits"] = exact_hits
    checks["exact_certificate_errors"] = len(exact_errors)
    if len(exact_keys) != 198 or exact_errors:
        failures.append("exact certificate audit is incomplete or has errors")

    conflict_rows = []
    for path in sorted((ROOT / "results").glob("test_conflict_sensitivity_*.jsonl")):
        conflict_rows.extend(
            row for row in read_jsonl(path)
            if row.get("implementation_hash") == protocol["implementation_hash"]
        )
    conflict_keys = {
        (row["graph_sha256"], row["target_index"], row["budget"])
        for row in conflict_rows if row.get("status") == "ok"
    }
    conflict_errors = [row for row in conflict_rows if row.get("status") != "ok"]
    checks["conflict_sensitivity_cells"] = len(conflict_keys)
    checks["conflict_sensitivity_errors"] = len(conflict_errors)
    if len(conflict_keys) != 12 or conflict_errors:
        failures.append("conflict sensitivity audit is incomplete or has errors")

    profile_rows = read_jsonl(ROOT / "results/profile_benchmarks.jsonl")
    synthetic_rows = read_jsonl(ROOT / "results/synthetic_overlap_family.jsonl")
    checks["profile_benchmark_rows"] = len(profile_rows)
    checks["synthetic_rows"] = len(synthetic_rows)
    if len(profile_rows) != 15 or any(row.get("status") != "ok" for row in profile_rows):
        failures.append("profile benchmark matrix is incomplete or has errors")
    if len(synthetic_rows) != 5:
        failures.append("synthetic mechanism matrix is incomplete")

    block_matching = json.loads(
        (ROOT / "results/BLOCK_MATCHING_CANDIDATE_AUDIT.json").read_text()
    )
    checks["block_matching_candidate_audit"] = block_matching
    exhaustive_coverage = block_matching.get("exhaustive_binary_coverage", {})
    if (block_matching.get("status") != "all_checks_passed"
            or block_matching.get("random_weighted_coverage_cells") != 1476
            or block_matching.get("random_lcm_cells") != 248
            or block_matching.get(
                "polynomial_blossom_reference_agreement_cells") != 120
            or block_matching.get("maximum_polynomial_matching_calls") != 1
            or block_matching.get("networkx_version") != "3.2.1"
            or exhaustive_coverage.get("ordered_set_systems") != 262144
            or exhaustive_coverage.get(
                "ordinary_coverage_cardinality_cells") != 1572864
            or exhaustive_coverage.get(
                "private_element_augmented_cardinality_cells") != 1572864
            or len(block_matching.get("tight_dag_family", [])) != 4):
        failures.append("BlockMatch candidate audit is missing, incomplete, or stale")

    exhaustive = json.loads(
        (ROOT / "results/EXHAUSTIVE_SMALL_GRAPH_AUDIT.json").read_text()
    )
    checks["exhaustive_small_graph_audit"] = {
        key: exhaustive[key] for key in (
            "status", "graphs", "target_budget_cells", "feasible_deletion_sets",
            "lagrangian_checks", "cardinality_hits", "implementation_hash",
        )
    }
    if (exhaustive.get("status") != "ok"
            or exhaustive.get("graphs") != 4096
            or exhaustive.get("implementation_hash") != protocol["implementation_hash"]):
        failures.append("exhaustive n=4 audit is missing, incomplete, or stale")

    # New evidence is separately bound; never revise the primary freeze.
    structural = json.loads((ROOT / "results/STRUCTURAL_BOUND_AUDIT.json").read_text())
    structural_real = json.loads((ROOT / "results/STRUCTURAL_REAL_GRAPH_SUMMARY.json").read_text())
    low_degree = json.loads((ROOT / "results/BLOCKMATCH_REAL_GRAPH_INDEPENDENT_VERIFICATION.json").read_text())
    public_protocol = json.loads((ROOT / "configs/BLOCKMATCH_REAL_GRAPH_PROTOCOL.json").read_text())
    checks["structural_audit"] = structural
    checks["structural_real_graph_audit"] = structural_real
    checks["low_degree_independent_verification"] = low_degree
    if (structural.get("status") != "ok"
            or structural.get("coverage_cardinality_cells") != 49152
            or structural.get("directed_graph_cardinality_cells") != 1293
            or structural.get("script_sha256") != sha256(ROOT / "scripts/audit_structural_bounds.py")):
        failures.append("structural theorem audit missing or stale")
    raw_supplement_sha = sha256(ROOT / "results/blockmatch_real_graph.jsonl")
    if (structural_real.get("status") != "ok"
            or structural_real.get("cells") != 48
            or structural_real.get("source_results_sha256") != raw_supplement_sha
            or structural_real.get("analysis_script_sha256") != sha256(ROOT / "scripts/analyze_structural_real_graph.py")
            or structural_real.get("exact_backend_sha256") != sha256(ROOT / "blockmatch/exact.py")
            or not structural_real.get("all_48_exact_integer_blossom_surrogates_verified")):
        failures.append("structural real-graph analysis missing or stale")
    if (low_degree.get("status") != "ok"
            or low_degree.get("cells") != 48
            or low_degree.get("raw_sha256") != raw_supplement_sha
            or low_degree.get("verifier_sha256") != sha256(ROOT / "scripts/verify_blockmatch_real_graph_audit.py")
            or low_degree.get("method_outputs_verified") != 240
            or low_degree.get("subsets_independently_enumerated_by_rational_original_graph_bfs") != 3239):
        failures.append("low-degree rational BFS verification missing or stale")
    if public_protocol.get("export", {}).get("public_runner_sha256") != sha256(ROOT / "scripts/run_blockmatch_real_graph_audit.py"):
        failures.append("exported supplement runner hash differs")

    release_smoke = json.loads(
        (ROOT / "results/RELEASE_SMOKE_AUDIT.json").read_text()
    )
    checks["release_smoke_audit"] = release_smoke
    if (not args.skip_release_smoke
            and (release_smoke.get("status") != "ok"
                 or release_smoke.get("artifact_audit_status") != "ok"
                 or release_smoke.get("forbidden_archive_members") != 0
                 or release_smoke.get("tests", {}).get("passed") != 13
                 or release_smoke.get("fetch_public_inputs", {}).get(
                     "inputs_verified") != 8)):
        failures.append("clean release smoke audit is missing or failed")

    required_reports = [
        "results/TEST_REPORT.md",
        "results/EXACT_CERTIFICATE_TEST_REPORT.md",
        "results/PROFILE_BENCHMARK_REPORT.md",
        "results/SYNTHETIC_OVERLAP_REPORT.md",
        "results/CONFLICT_SENSITIVITY_REPORT.md",
        "results/SCALABILITY_EXTENSION_REPORT.md",
        "results/SCALABILITY_EXTENSION_SUMMARY.json",
        "results/scalability-extension.jsonl",
        "paper/main.tex",
        "paper/acmart.cls",
        "paper/ACM-Reference-Format.bst",
        "paper/acmart-source/acmart.dtx",
        "paper/acmart-source/acmart.ins",
        "paper/acmart-source/README",
        "paper/TEMPLATE_PROVENANCE.md",
        "paper/references.bib",
        "paper/generated/main_results.tex",
        "paper/generated/component_results.tex",
        "paper/generated/datasets.tex",
        "paper/generated/statistical_summary.tex",
        "paper/generated/scalability_results.tex",
        "paper/generated/budget_results.tex",
        "paper/generated/detailed_results.tex",
        "paper/figures/frozen_results.pdf",
        "paper/figures/comparison_views.pdf",
        "paper/figures/comparison_views.png",
        "paper/figures/profile_tradeoffs.pdf",
        "paper/figures/profile_tradeoffs.png",
        "paper/main.pdf",
        "paper/CLAIM_EVIDENCE.md",
        "paper/SUBMISSION_CHECKLIST.md",
        "paper/INDEPENDENT_REVIEW_PACKET.md",
        "paper/INTERNAL_COLD_REVIEW.md",
        "planning/OPENREVIEW_ENTRY.md",
        "planning/SUBMISSION_METADATA_TEMPLATE.md",
        "ARTIFACT_README.md",
        "data/README.md",
        "scripts/fetch_public_inputs.py",
        "scripts/exhaustive_small_graph_audit.py",
        "scripts/validate_block_matching_candidate.py",
        "scripts/run_scalability_extension.py",
        "scripts/select_scalability_targets.py",
        "scripts/summarize_scalability_extension.py",
        "scalability/compact_graph.py",
        "scripts/build_release_artifact.py",
        "scripts/verify_artifact_manifest.py",
        "results/EXHAUSTIVE_SMALL_GRAPH_AUDIT.json",
        "results/BLOCK_MATCHING_CANDIDATE_AUDIT.json",
        "results/RELEASE_SMOKE_AUDIT.json",
        "notes/REFERENCE_AUDIT_2026-10-15.md",
        "notes/doi_metadata_2026-10-15.json",
        "blockmatch/exact.py",
        "paper/figures/exact_comparison.pdf",
        "paper/figures/theoretical_envelope.pdf",
        "paper/generated/exact_comparison.tex",
    ]
    missing_reports = [relative for relative in required_reports
                       if not (ROOT / relative).exists()]
    checks["required_reports"] = required_reports
    checks["missing_reports"] = missing_reports
    if missing_reports:
        failures.append("required reports are missing")

    text_suffixes = {".tex", ".bib", ".md", ".log", ".bbl", ".blg"}
    paper_text = "\n".join(
        path.read_text(errors="replace") for path in (ROOT / "paper").rglob("*")
        if path.is_file() and path.suffix in text_suffixes
    )
    absolute_user_path_marker = "/" + "Users" + "/"
    checks["paper_contains_absolute_user_path"] = absolute_user_path_marker in paper_text
    if checks["paper_contains_absolute_user_path"]:
        failures.append("paper artifact leaks an absolute user path")

    paper_log = (ROOT / "paper/main.log").read_text(errors="replace")
    bad_log_patterns = (
        "Overfull \\hbox",
        "Overfull \\vbox",
        "undefined references",
        "undefined citations",
        "multiply defined",
    )
    checks["paper_log_errors"] = [pattern for pattern in bad_log_patterns
                                  if pattern in paper_log]
    if checks["paper_log_errors"]:
        failures.append("paper log contains unresolved layout/reference errors")
    pdf_info = subprocess.check_output(
        ["pdfinfo", str(ROOT / "paper/main.pdf")], text=True
    )
    checks["paper_uses_acmart_2_20"] = "acmart 2026/08/16 v2.20" in pdf_info
    if not checks["paper_uses_acmart_2_20"]:
        failures.append("paper PDF was not built with pinned acmart v2.20")
    author_match = re.search(r"^Author:\s*(.*)$", pdf_info, re.MULTILINE)
    checks["paper_pdf_anonymous_metadata"] = (
        author_match is None or not author_match.group(1).strip()
    )
    if not checks["paper_pdf_anonymous_metadata"]:
        failures.append("paper PDF metadata contains an author")
    checks["paper_pdf_sha256"] = sha256(ROOT / "paper/main.pdf")
    page_match = re.search(r"^Pages:\s+(\d+)$", pdf_info, re.MULTILINE)
    checks["paper_pdf_pages"] = int(page_match.group(1)) if page_match else None
    if checks["paper_pdf_pages"] is None or checks["paper_pdf_pages"] > 12:
        failures.append("paper PDF page count is missing or exceeds 12")
    if not args.skip_release_smoke:
        if release_smoke.get("paper_pdf_sha256") != checks["paper_pdf_sha256"]:
            failures.append("clean release smoke audit has a stale paper PDF hash")
        if release_smoke.get("paper_pages") != checks["paper_pdf_pages"]:
            failures.append("clean release smoke audit has a stale paper page count")

    main_tex = (ROOT / "paper/main.tex").read_text()
    openreview_text = (ROOT / "planning/OPENREVIEW_ENTRY.md").read_text()

    def markdown_section(name, next_name):
        start = "## %s\n\n" % name
        end = "\n\n## %s" % next_name
        return openreview_text.split(start, 1)[1].split(end, 1)[0]

    title_match = re.search(r"\\title\{([^{}]+)\}", main_tex)
    paper_title = " ".join(title_match.group(1).split()) if title_match else None
    entry_title = " ".join(markdown_section("Title", "Research track").split())
    checks["openreview_title_matches"] = paper_title == entry_title

    abstract_match = re.search(
        r"\\begin\{abstract\}(.*?)\\end\{abstract\}", main_tex, re.DOTALL
    )
    paper_abstract = abstract_match.group(1) if abstract_match else ""
    substitutions = {
        "$k=d-b$": "k = d - b",
        "$O(d(|V|+|E|))$": "O(d(|V|+|E|))",
        "$\\sqrt{2h_G(v)}$": "sqrt(2h_G(v))",
        "$\\sqrt{h_G(v)}$": "sqrt(h_G(v))",
        "$\\sqrt{h_G(v)/2}$": "sqrt(h_G(v)/2)",
        "$k\\le3$": "k <= 3",
        "$k\\ge4$": "k >= 4",
        "$h_G(v)/(2\\sqrt{h_G(v)}-1)$": "h_G(v)/(2 sqrt(h_G(v))-1)",
        "$d$": "d",
        "$b$": "b",
        "$\\lfloor k/2\\rfloor$": "floor(k/2)",
        "$b+1$": "b+1",
    }
    for source, target in substitutions.items():
        paper_abstract = paper_abstract.replace(source, target)
    paper_abstract = re.sub(r"\\emph\{([^{}]*)\}", r"\1", paper_abstract)
    paper_abstract = paper_abstract.replace(r"\%", "%").replace("--", "-")
    paper_abstract = " ".join(paper_abstract.split())
    entry_abstract = " ".join(markdown_section("Abstract", "Keywords").split())
    checks["openreview_abstract_matches"] = paper_abstract == entry_abstract
    checks["openreview_abstract_words"] = len(entry_abstract.split())

    keywords_match = re.search(r"\\keywords\{(.*?)\}", main_tex, re.DOTALL)
    paper_keywords = ([value.strip() for value in
                       " ".join(keywords_match.group(1).split()).split(",")]
                      if keywords_match else [])
    entry_keywords = [value.strip() for value in
                      " ".join(markdown_section(
                          "Keywords", "ACM CCS concepts").split()).split(";")]
    checks["openreview_keywords_match"] = paper_keywords == entry_keywords
    checks["openreview_track"] = " ".join(
        markdown_section("Research track", "Abstract").split()
    )
    if not all((checks["openreview_title_matches"],
                checks["openreview_abstract_matches"],
                checks["openreview_keywords_match"])):
        failures.append("OpenReview entry does not match paper metadata")
    if checks["openreview_track"] != "Graph Algorithms and Modeling for the Web":
        failures.append("OpenReview entry has the wrong research track")

    result = {
        "status": "ok" if not failures else "failed",
        "failures": failures,
        "checks": checks,
        "optional_quality_checks": [
            "An external specialist proof/novelty review can reduce risk but is not a WWW 2027 submission requirement; internal full-text comparison with Chen et al. (JCSS 2026) is complete.",
        ],
        "known_release_blockers": [
            "The author must complete the final institutional and personal conflict review in the venue's operative COI interface before the abstract deadline.",
            "Before public artifact release, choose an explicit implementation license and publish the exact archive in a DOI-granting repository; the internal archive already excludes raw graphs, downloaded archives, and the unlicensed upstream snapshot.",
        ],
    }
    output = ROOT / "results/ARTIFACT_AUDIT.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(output)
    if failures:
        print("\n".join(failures), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
